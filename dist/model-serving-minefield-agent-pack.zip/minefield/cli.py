"""Command line interface for safe, multi-modal Minefield diagnosis."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .api import plan_checks
from .coverage import build_coverage
from .doctor_adapter import run as run_doctor
from .generator import build, verify
from .inline_system import EvidenceError, classify_manifest, inspect_template, load_manifest
from .log_inspector import inspect_logs
from .matching import diagnose
from .registry import load_registry
from .render import render_diagnosis, render_scan, render_unified_diagnosis
from .scan import scan
from .unified import diagnose_environment
from .static_inspector import inspect_files
from .support_bundle import plan, write_bundle

CONDITION_FLAGS = (
    "gpu-architecture", "device-class", "node-count", "parallelism",
    "topology", "stack-version", "model-family", "exact-checkpoint",
    "quantization", "context-regime", "concurrency-regime",
    "failure-stage", "operating-system",
)


def _emit(value: Any, as_json: bool = True) -> None:
    if as_json:
        print(json.dumps(value, indent=2, sort_keys=True))
    else:
        print(value)


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="minefield")
    sub = ap.add_subparsers(dest="command", required=True)
    quick = sub.add_parser("quick", help="run the existing read-only endpoint doctor")
    quick.add_argument("doctor_args", nargs=argparse.REMAINDER)
    for name in ("inspect-config", "inspect-logs"):
        cmd = sub.add_parser(
            name,
            help="offline read of explicitly named files under an approved root",
        )
        cmd.add_argument("paths", nargs="+")
        cmd.add_argument(
            "--allowed-root", action="append", required=True,
            help="approved filesystem root; repeat for additional roots",
        )
    guide = sub.add_parser(
        "guide",
        help="find the traps that match what you are seeing (also: minefield <symptom>)",
    )
    guide.add_argument("symptom", nargs="+", help="what you observe, in plain words")
    fmt = guide.add_mutually_exclusive_group()
    fmt.add_argument("--json", action="store_true", help="full diagnosis contract as JSON (default when piped)")
    fmt.add_argument("--text", action="store_true", help="readable summary (default in a terminal)")
    guide.add_argument("--limit", type=int, default=5, help="how many matches to show (default 5)")
    guide.add_argument("--log", dest="log_excerpt", help="a short log excerpt to match on as well")
    guide.add_argument("--stack")
    guide.add_argument("--model")
    guide.add_argument("--version")
    for flag in CONDITION_FLAGS:
        guide.add_argument(f"--{flag}")
    guide.add_argument("--direct-probe-trap", action="append", default=[])
    guide.add_argument(
        "--direct-probe-result", action="append", default=[], metavar="TRAP=RESULT",
        help="record confirmed, refuted, or inconclusive for an explicit trap probe",
    )
    guide.add_argument("--mechanism-probe-trap", action="append", default=[])
    scan_cmd = sub.add_parser(
        "scan",
        help="check config files, launch scripts, model folders, logs and eval results for known traps",
    )
    scan_cmd.add_argument("paths", nargs="+", help="files or folders to read (only these are read)")
    scan_fmt = scan_cmd.add_mutually_exclusive_group()
    scan_fmt.add_argument("--json", action="store_true", help="full report as JSON (default when piped)")
    scan_fmt.add_argument("--text", action="store_true", help="readable report (default in a terminal)")
    diag = sub.add_parser(
        "diagnose",
        help="unified diagnosis across symptom matching, supplied files, and an optional live endpoint",
    )
    diag.add_argument("symptom", nargs="*", help="what you observe, in plain words")
    diag.add_argument("--files", nargs="+", default=[], help="configs, model folders, logs, or results to scan")
    diag.add_argument("--base-url", help="optional OpenAI-compatible endpoint for bounded live probes")
    diag.add_argument("--api-key", help="optional endpoint API key; never included in output")
    diag.add_argument("--stack")
    diag.add_argument("--model")
    diag.add_argument("--version")
    diag.add_argument("--hf-repo")
    diag.add_argument("--hf-revision", default="main", help="served HF checkpoint revision, not an inferred family")
    diag.add_argument("--probe", dest="probe_ids", action="append", help="restrict to named probes; repeatable; does not override lite eligibility")
    diag.add_argument("--server-max-tokens", type=int, help="known serving token flag, 1..255")
    diag.add_argument("--benchmark-target-tokens", type=int)
    diag.add_argument("--benchmark-prompt-text", help="exact approved synthetic prompt, at most 8192 characters")
    diag.add_argument("--thinking-budget-marker-ids", help="configured START,END token IDs")
    diag.add_argument("--log", dest="log_excerpt", help="short log excerpt to include in symptom matching")
    diag.add_argument("--limit", type=int, default=5)
    diag.add_argument("--mode", choices=("lite", "doctor"), default="lite",
                      help="lite uses a small live budget; doctor runs the full endpoint catalogue")
    diag.add_argument("--max-requests", type=int,
                      help="hard live request budget; lite defaults to 5, doctor defaults to uncapped")
    diag_fmt = diag.add_mutually_exclusive_group()
    diag_fmt.add_argument("--json", action="store_true")
    diag_fmt.add_argument("--text", action="store_true")
    doctor_plan = sub.add_parser(
        "doctor-plan",
        help="offline preview of selected Doctor checks and chat request budget (zero network calls)",
    )
    doctor_plan.add_argument("--mode", choices=("lite", "doctor"), default="lite")
    doctor_plan.add_argument("--probe", dest="probe_ids", action="append", help="restrict the plan to named probes; repeatable")
    doctor_plan.add_argument(
        "--max-requests", type=int,
        help="max chat-completion calls in the eventual run (lite defaults to 5)",
    )
    doctor_plan.add_argument(
        "--preferred-trap", action="append", default=[], metavar="ID",
        help="prioritise a canonical trap in lite mode; repeatable",
    )
    doctor_plan.add_argument("--model", help="declared model for planning only; not verified")
    doctor_plan.add_argument("--hf-repo", help="declared public HF repository; not fetched")
    doctor_plan.add_argument(
        "--capability", action="append", choices=("streaming", "tools", "multimodal"),
        help="explicit assumed endpoint capability; repeatable, never probed",
    )
    doctor_plan.add_argument("--text", action="store_true", help="compact human-readable preview")
    menu_cmd = sub.add_parser(
        "menu", help="everything Minefield can do, as a numbered menu (also: bare `minefield`)")
    menu_fmt = menu_cmd.add_mutually_exclusive_group()
    menu_fmt.add_argument("--json", action="store_true",
                          help="machine-readable catalogue for harnesses and plugins")
    menu_fmt.add_argument("--markdown", action="store_true", help="the menu as Markdown")
    coverage = sub.add_parser("coverage", help="what the doctor, static and log checks cover")
    coverage.add_argument("--json", action="store_true")
    agent = sub.add_parser("agent-bundle", help="regenerate (or --verify) the shipped registry and agent bundles")
    agent.add_argument("--verify", action="store_true")
    bundle = sub.add_parser("bundle", help="build a redacted support bundle from configs, logs and a doctor report")
    bundle.add_argument("--config", action="append", default=[])
    bundle.add_argument("--log", action="append", default=[])
    bundle.add_argument("--doctor-report")
    bundle.add_argument("--output", default="minefield-support-bundle.zip")
    bundle.add_argument("--no-write", action="store_true")
    inline = sub.add_parser(
        "classify-inline-system",
        help="classify bounded, already-rendered inline-system evidence",
    )
    inline.add_argument("--manifest", required=True)
    inline.add_argument(
        "--template-path",
        help="optional local Jinja/source file to hash; it is never executed",
    )
    # Offline research-integrity tools (no endpoint mutation).
    ep = sub.add_parser(
        "evidence-preflight",
        help="validate an Evidence Packet v1 (offline; no endpoint calls)",
    )
    ep.add_argument(
        "--packet",
        required=True,
        help="path to Evidence Packet JSON (schema docs/evidence-packet.schema.json)",
    )
    ep.add_argument(
        "--artifact-root",
        help="directory used to resolve relative artifact paths for SHA256 checks",
    )
    br = sub.add_parser(
        "blind-review",
        help="derive a blind-review packet (strips proposer verdict/confidence)",
    )
    br.add_argument("--packet", required=True, help="path to full Evidence Packet JSON")
    br.add_argument("--out", help="write blind wrapper JSON to this path")
    ut = sub.add_parser(
        "upstream-triage",
        help="offline map of changed paths to risk surfaces (never NEW_TRAP_FOUND)",
    )
    ut.add_argument(
        "--changes",
        help="file of paths (git diff --name-only); stdin if omitted",
    )
    pr = sub.add_parser(
        "promotion-receipt",
        help="validate a Promotion Receipt (records provenance; does not allocate traps)",
    )
    pr.add_argument("--receipt", required=True, help="path to promotion receipt JSON")
    return ap


def _command_names() -> set[str]:
    # argparse exposes no public accessor for subcommand names.
    for action in parser()._actions:  # noqa: SLF001
        if isinstance(action, argparse._SubParsersAction):  # noqa: SLF001
            return set(action.choices)
    return set()


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        argv = ["menu"]
    if argv[0] == "quick":
        return run_doctor(argv[1:])
    if argv[0] == "menu":
        from . import menu

        margs = parser().parse_args(argv)
        if margs.json:
            _emit(menu.as_dict())
            return 0
        if margs.markdown or not sys.stdin.isatty():
            print(menu.render("markdown" if margs.markdown else "text"))
            return 0
        return menu.interactive(lambda chosen: main(list(chosen)))
    # `minefield empty content when streaming` is shorthand for `minefield guide ...`.
    if argv and argv[0] not in {"-h", "--help"} and argv[0] not in _command_names():
        argv = ["guide", *argv]
    args = parser().parse_args(argv)
    registry = load_registry()
    if args.command == "inspect-config":
        _emit(inspect_files(args.paths, args.allowed_root))
    elif args.command == "inspect-logs":
        _emit(inspect_logs(args.paths, args.allowed_root))
    elif args.command == "guide":
        direct_probe_results = {}
        for item in args.direct_probe_result:
            trap_id, separator, outcome = item.partition("=")
            if not separator or outcome not in {"confirmed", "refuted", "inconclusive"}:
                raise SystemExit(
                    "--direct-probe-result must be TRAP=confirmed|refuted|inconclusive"
                )
            direct_probe_results[trap_id] = outcome
        conditions = {
            flag.replace("-", "_"): getattr(args, flag.replace("-", "_"))
            for flag in CONDITION_FLAGS
            if getattr(args, flag.replace("-", "_")) is not None
        }
        result = diagnose(
            registry, " ".join(args.symptom), stack=args.stack, model=args.model,
            version=args.version, conditions=conditions,
            log_excerpt=args.log_excerpt,
            direct_probe_trap_ids=args.direct_probe_trap,
            direct_probe_results=direct_probe_results,
            mechanism_probe_trap_ids=args.mechanism_probe_trap,
            limit=max(1, args.limit),
        )
        if args.text or (not args.json and sys.stdout.isatty()):
            print(render_diagnosis(result, limit=max(1, args.limit)))
        else:
            _emit(result)
    elif args.command == "scan":
        report = scan(args.paths)
        if args.text or (not args.json and sys.stdout.isatty()):
            titles = {e["id"]: {"title": e["title"], "source_path": e["source_path"]}
                      for e in registry["entries"]}
            print(render_scan(report, titles))
        else:
            _emit(report)
        if not report["accepted_paths"]:
            # Nothing named could be read: a typo or missing path is an error,
            # not a clean scan of zero files.
            return 2
    elif args.command == "diagnose":
        symptom_parts = list(args.symptom)
        # Preserve the old no-argument interactive workflow for humans.
        if not symptom_parts and not args.files and not args.base_url:
            if not sys.stdin.isatty():
                raise SystemExit(
                    "diagnose needs a symptom, --files, or --base-url when stdin is not a terminal"
                )
            symptom_parts = [input("What are you seeing? ").strip()]
            if not args.stack:
                args.stack = input("Serving stack and version? ").strip() or None
            if not args.model:
                args.model = input("Model and revision? ").strip() or None
            print()
        try:
            report = diagnose_environment(
                registry,
                " ".join(part for part in symptom_parts if part).strip(),
                paths=args.files,
                base_url=args.base_url,
                api_key=args.api_key,
                stack=args.stack,
                model=args.model,
                version=args.version,
                hf_repo=args.hf_repo,
                hf_revision=args.hf_revision,
                probe_ids=args.probe_ids,
                server_max_tokens=args.server_max_tokens,
                benchmark_target_tokens=args.benchmark_target_tokens,
                benchmark_prompt_text=args.benchmark_prompt_text,
                thinking_budget_marker_ids=args.thinking_budget_marker_ids,
                log_excerpt=args.log_excerpt,
                limit=max(1, args.limit),
                mode=args.mode,
                max_requests=args.max_requests,
            )
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return 2
        if args.text or (not args.json and sys.stdout.isatty()):
            print(render_unified_diagnosis(report, limit=max(1, args.limit)))
        else:
            _emit(report)
        if args.files and not (report.get("file_scan") or {}).get("accepted_paths"):
            return 2
    elif args.command == "doctor-plan":
        # Do not detect an endpoint or read user infrastructure: this command
        # deliberately never invokes a network path, even when --hf-repo is set.
        if args.max_requests is not None and args.max_requests < 0:
            print("--max-requests must be >= 0", file=sys.stderr)
            return 2
        known_ids = {str(item["id"]).zfill(2) for item in registry["entries"]}
        preferred = [str(value).zfill(2) for value in args.preferred_trap]
        invalid = [value for value in preferred if value not in known_ids]
        if invalid:
            print("unknown canonical trap IDs: " + ", ".join(invalid), file=sys.stderr)
            return 2
        try:
            candidate = plan_checks(
                mode=args.mode,
                max_requests=args.max_requests,
                model=args.model,
                hf_repo=args.hf_repo,
                capabilities=tuple(args.capability) if args.capability else None,
                preferred_trap_ids=preferred,
                probe_ids=args.probe_ids,
                detect=False,
            )
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return 2
        selected_traps = sorted(
            {str(t).zfill(2) for probe in candidate.selected for t in probe.traps},
            key=int,
        )
        unselected_preferred = sorted(set(preferred) - set(selected_traps), key=int)
        report = {
            "kind": "doctor_plan",
            "execution": "NOT_RUN",
            "network_calls_made": 0,
            "generation_requests_made": 0,
            "model_identity_verified": False,
            "capabilities_verified": False,
            "mode": candidate.mode,
            "chat_request_budget": candidate.max_requests,
            "planned_chat_requests_upper_bound": candidate.expected_requests,
            "selected_probe_count": len(candidate.selected),
            "skipped_probe_count": len(candidate.skipped),
            "planned_trap_ids": selected_traps,
            "requested_preferred_trap_ids": preferred,
            "unselected_preferred_trap_ids": unselected_preferred,
            "planned_trap_count": len(selected_traps),
            "registered_doctor_traps": build_coverage(registry)["summary"]["endpoint_checks_implemented"],
            "canonical_trap_count": len(known_ids),
            "selected_probes": [
                {
                    "id": p.id,
                    "traps": list(p.traps),
                    "chat_request_cost": p.request_cost,
                    "reason": p.reason,
                    "requires": list(p.requires),
                }
                for p in candidate.selected
            ],
            "skipped_probes": [
                {
                    "id": p.id,
                    "traps": list(p.traps),
                    "chat_request_cost": p.request_cost,
                    "reason": p.reason,
                }
                for p in candidate.skipped
            ],
            "warnings": [
                "Planning performed no endpoint, network, or Hugging Face requests.",
                "Zero chat-request cost does not mean zero HTTP calls in a later run: GET, render, metrics and public HF metadata checks may still run.",
                "Capabilities and model are assumptions until checked against the actual endpoint.",
                "Selected checks are only planned, never executed or CLEAN; unselected and unimplemented traps remain untested.",
                "A live run requires operator authority and a separately enforced --max-requests budget.",
            ] + ([
                "Preferred trap IDs not selected: "
                + ", ".join(unselected_preferred)
                + ". They may be ineligible for lite mode, require a higher budget, or lack an implemented Doctor check."
            ] if unselected_preferred else []),
        }
        if args.text:
            print(
                f"Doctor plan only (NOT RUN): {report['selected_probe_count']} probes, "
                f"{report['planned_trap_count']}/{report['canonical_trap_count']} trap IDs, "
                f"up to {report['planned_chat_requests_upper_bound']} chat requests "
                f"(budget={report['chat_request_budget']})."
            )
            print("Selected probes: " + ", ".join(p["id"] for p in report["selected_probes"]))
            if unselected_preferred:
                print("Preferred traps NOT selected: " + ", ".join(unselected_preferred))
            print("No network calls. No live verdicts. A budget covers chat calls, not GET/render/HF requests.")
        else:
            _emit(report)
    elif args.command == "coverage":
        value = build_coverage(registry)["summary"]
        _emit(value if args.json else "\n".join(f"{k}: {v}" for k, v in value.items()),
              as_json=args.json)
    elif args.command == "agent-bundle":
        _emit(verify() if args.verify else build())
    elif args.command == "bundle":
        bundle_plan = plan(configs=args.config, logs=args.log, doctor_report=args.doctor_report)
        if args.no_write:
            _emit(bundle_plan["preview"])
        else:
            _emit(write_bundle(args.output, bundle_plan))
    elif args.command == "classify-inline-system":
        try:
            value = classify_manifest(load_manifest(args.manifest))
            if args.template_path:
                value["template_source"] = inspect_template(args.template_path)
            _emit(value)
        except (EvidenceError, OSError) as exc:
            print(json.dumps({
                "classification": "INCONCLUSIVE",
                "error": type(exc).__name__,
                "reason": str(exc),
            }, sort_keys=True), file=sys.stderr)
            return 2
    elif args.command == "evidence-preflight":
        from .evidence_packet import preflight_path

        root = Path(args.artifact_root) if args.artifact_root else None
        report = preflight_path(args.packet, artifact_root=root)
        _emit(report)
        status = report.get("status")
        if status == "PASS":
            return 0
        if status == "FAIL":
            return 2
        return 3
    elif args.command == "blind-review":
        from .blind_review import assert_no_leak, derive_blind_packet
        from .evidence_packet import load_packet

        path = Path(args.packet)
        if not path.is_file():
            _emit({
                "status": "FAIL",
                "error": "packet_not_found",
                "message": f"not a readable file: {path}",
            })
            return 2
        try:
            full = load_packet(path)
        except (OSError, json.JSONDecodeError) as exc:
            _emit({
                "status": "FAIL",
                "error": "packet_json_invalid",
                "message": str(exc),
            })
            return 2
        wrapper = derive_blind_packet(full)
        leaks = assert_no_leak(wrapper)
        if leaks:
            wrapper["leak_check"] = {"status": "FAIL", "leaks": leaks}
        else:
            wrapper["leak_check"] = {"status": "PASS", "leaks": []}
        _emit(wrapper)
        if args.out:
            Path(args.out).write_text(
                json.dumps(wrapper, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        return 0 if not leaks else 2
    elif args.command == "upstream-triage":
        from .upstream_change_triage import triage_file, triage_from_text

        if args.changes:
            cpath = Path(args.changes)
            if not cpath.is_file():
                _emit({
                    "status": "UNKNOWN",
                    "error": "changes_not_found",
                    "message": f"not a readable file: {cpath}",
                    "observed_count": 0,
                    "new_trap_found": False,
                })
                return 3
            report = triage_file(cpath)
        else:
            report = triage_from_text(sys.stdin.read())
        _emit(report)
        return 0 if report.get("observed_count", 0) > 0 else 3
    elif args.command == "promotion-receipt":
        from .promotion_receipt import validate_receipt

        path = Path(args.receipt)
        if not path.is_file():
            _emit({
                "status": "FAIL",
                "error": "receipt_not_found",
                "message": f"not a readable file: {path}",
            })
            return 2
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            _emit({
                "status": "FAIL",
                "error": "receipt_json_invalid",
                "message": str(exc),
            })
            return 2
        report = validate_receipt(doc)
        _emit(report)
        status = report.get("status")
        if status == "PASS":
            return 0
        if status == "FAIL":
            return 2
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
