#!/usr/bin/env python3
"""minefield_doctor.py: point it at your OpenAI-compatible endpoint, get a
diagnosis against the model-serving-minefield registry.

    python3 minefield_doctor.py --base-url http://localhost:8000/v1

WHAT THIS IS: a thinking-stack preflight, not a minefield doctor. Its checks
cluster on reasoning fields, chat templates and history assembly, thinking
control kwargs, tool parsing and token ceilings, because that is what a
read-only request-shaped probe can reach. It says nothing about quantisation
kernel paths, container toolchains, memory allocation, MoE routing, eval-harness
confounds or long-context behaviour, which is most of the registry. A run with
no problems is a statement about the trap ids in its clean count, never a bill
of health. Findings print Core tier first within each bucket (see CORE.md).

Safety, up front:
  - READ-ONLY. Never restarts anything, never changes server state, never
    writes to your server. GET probes plus a small, fixed set of chat
    completions (at most 42 generation requests, each capped at 512 output
    tokens; one uses 512, the rest 16 to 256), plus render or tokenise calls
    that generate nothing.
  - The two multimodal probes send a GENERATED 8x8 PNG built in-process from
    the standard library, and one deliberately non-existent file path. No file
    of yours is read and nothing is uploaded.
  - Sends nothing anywhere except your endpoint (and huggingface.co, only
    if you pass --hf-repo, to read a few public config files).
  - Everything it finds cites the registry trap it comes from.

Output, in this order:
    PROBLEMS         something is wrong, with the fix and the trap
    CHECKED AND CLEAN a probe ran AND its result can only mean "clean"
    INCONCLUSIVE     a probe ran, but the result is consistent with several
                     materially different states, so it is not a clean bill
    COULD NOT CHECK  the probe could not run, or its precondition was missing
    COVERAGE         how much of the registry this run actually touched

The distinction between the last three is the whole point of this tool. A
result only reaches CHECKED AND CLEAN when the observation rules out the
failure mode. If acceptance, silence, or a missing template could equally well
explain what was seen, it goes to INCONCLUSIVE or COULD NOT CHECK, never to
CLEAN. Add --report for a markdown block you can paste into an "I hit a trap"
issue, and --json for the machine-readable form, which carries the exact
assertions that ran, not only the prose.

Stdlib only. jinja2 is used for one extra render path if installed; never
required. Exit codes: 0 ran (read the sections), 1 endpoint unreachable.
"""
import argparse, json, re, sys, urllib.request, urllib.error, zlib

REG = "https://github.com/Blackwellboy/model-serving-minefield/blob/main/traps"

# Total numbered entries in the registry. Verified against the trap files in
# traps/*/ at the tip that ships this file; doctor/tests/test_doctor_verdicts.py
# asserts this constant still matches the tree, so it cannot drift silently.
# Any PR that lands new trap files fails that test until this is bumped and the
# coverage sentences in README.md and doctor/README.md are updated with it.
REGISTRY_TRAP_COUNT = 163

TRAP_PATHS = {
    "01": "reasoning/01-reasoning-field-two-names.md",
    "02": "template/02-orphaned-think-close-tag.md",
    "03": "reasoning/03-enable-thinking-default-drift.md",
    "04": "template/04-history-reasoning-stripping.md",
    "07": "reasoning/07-reasoning-effort-silently-ignored.md",
    "10": "quantization/10-quant-label-is-not-the-kernel-path.md",
    "12": "evaluation/12-empty-content-at-token-ceiling.md",
    "16": "evaluation/16-finish-reason-is-not-a-failure-signal.md",
    "17": "evaluation/17-per-arm-recommended-sampling-confound.md",
    "19": "tools/19-missing-jinja-breaks-tool-parsing.md",
    "20": "reasoning/20-reasoning-write-field-name-diverges.md",
    "21": "versioning/21-no-generation-config-server-defaults-win.md",
    "22": "evaluation/22-family-card-budget-floors-differ-by-size.md",
    "23": "reasoning/23-streaming-answer-lands-in-reasoning-channel.md",
    "25": "template/25-empty-think-blocks-poison-prefix-cache.md",
    "57": "reasoning/57-thinking-kwarg-truthiness-coercion.md",
    "58": "reasoning/58-reasoning-effort-injects-hidden-preamble.md",
    "63": "reasoning/63-reasoning-round-trip-one-correct-shape.md",
    "66": "template/66-in-text-thinking-toggle-mutates-user-text.md",
    "67": "template/67-history-rendered-as-object-repr.md",
    "113": "template/113-inline-system-role-is-not-a-stable-contract.md",
    "82": "template/82-system-prompt-relocates-to-last-user-turn.md",
    "83": "template/83-template-carries-a-baked-default-system-prompt.md",
    "30": "template/30-default-system-message-silently-replaced.md",
    "38": "template/38-template-owns-the-opening-think-tag.md",
    "43": "template/43-tool-args-string-not-mapping.md",
    "69": "template/69-minor-template-defects.md",
    "85": "reasoning/85-enable-thinking-typechecked-though-never-read.md",
    "112": "runtime/112-process-liveness-is-not-model-readiness.md",
    "64": "reasoning/64-answer-lands-in-reasoning-on-toggle-conflict.md",
    "65": "reasoning/65-parser-only-rescue-kwarg.md",
    "149": "evaluation/149-thinking-on-json-schema-can-runaway.md",
    "156": "evaluation/156-exllamav3-requeue-undercounts-output-tokens.md",
    "158": "reasoning/158-empty-thought-markers-count-as-reasoning.md",
    "162": "reasoning/162-thinking-on-short-answer-never-closes-think-block.md",
    "163": "versioning/163-quantized-sibling-repo-ships-stale-processor-metadata.md",
    "24": "template/24-official-template-breaks-cpp-jinja.md",
    "56": "template/56-checkpoint-ships-no-chat-template.md",
    "59": "reasoning/59-reasoning-roundtrip-confabulation.md",
    "93": "template/93-clock-in-system-prompt-is-inert-and-the-mitigation-is-inverted.md",
    "126": "reasoning/126-ling-thinking-false-spills-reasoning-into-content.md",
    "138": "evaluation/138-ngram-prompt-lookup-duplicates-structured-output-tokens.md",
    "148": "template/148-tool-json-ascii-escaping-changes-prompt.md",
    "32": "runtime/32-mlx-server-max-tokens-is-a-default-not-a-cap.md",
    "153": "reasoning/153-thinking-budget-hardcodes-wrong-marker-ids.md",
    "155": "runtime/155-prefix-slot-policy-thrashes-long-conversations.md",
    "157": "runtime/157-ngram-speculation-disables-async-scheduling.md",
    "49": "evaluation/49-prompt-not-tokenized-to-target.md",
    "60": "runtime/60-cold-prefill-and-cache-hit-disagree.md",
    "91": "runtime/91-concurrency-nondeterminism-has-a-prompt-length-floor.md",
    "96": "memory/96-list-devices-reports-host-memory-as-device-free-memory.md",
    "106": "memory/106-kv-occupancy-ceiling-is-not-a-leak.md",
    "117": "runtime/117-fuse-gemm-comms-accepted-then-disabled.md",
    "130": "runtime/130-cudagraph-clamp-runs-top-shape-eager.md",
    "135": "evaluation/135-concurrent-http-clients-are-not-concurrent-model-execution.md",
    "110": "evaluation/110-unscreened-bench-on-a-shared-endpoint.md",
    "84": "template/84-tool-roundtrip-then-user-turn-is-unrenderable.md",
    "86": "template/86-final-assistant-turn-bypasses-the-template-branch.md",
    "87": "runtime/87-llamacpp-props-reports-per-slot-context.md",
    "26": "tools/26-tool-call-inside-unclosed-think.md",
    "78": "tools/78-tool-choice-accepted-and-ignored.md",
    "80": "runtime/80-reasoning-parser-batches-sse-deltas.md",
    "88": "runtime/88-cache-prompt-false-does-isolate-here.md",
    "29": "reasoning/29-server-reasoning-off-is-not-an-off-switch.md",
    "77": "reasoning/77-only-one-request-field-is-validated.md",
    "141": "evaluation/141-sglang-python-chat-model-name-not-validated.md",
    # The multimodal checks below ran under advisory ids (mm-order, mm-errors,
    # mm-usage) until these entries were published; each entry now names this
    # doctor as its check, so they report under their trap numbers.
    "68": "template/68-multimodal-part-order-discarded.md",
    "72": "runtime/72-media-fetch-errors-are-5xx.md",
    "73": "evaluation/73-multimodal-token-cost-not-attributable.md",
    "15": "evaluation/15-no-echo-logprobs-wedges-lm-eval.md",
}

# The registry's Core tier (../CORE.md): the twelve entries selected on
# evidence of what has cost people evenings, rather than on which entries have
# the best data. Findings are ordered Core first within each verdict bucket so
# the first lines an operator reads are the ones most likely to matter.
#
# Three of the twelve (35, 53, 61) have no check in this tool and appear
# here only so the ordering key and the coverage line stay honest about that.
# 77 was the fourth until check_request_validation landed: its own entry names
# the two-minute probe as the fix, so implementing it was reading the entry
# rather than inventing a check.
# Keep this set in sync with CORE.md; it is a reading-order tier, not a claim
# about severity in any individual case.
CORE_TRAP_IDS = {"01", "03", "04", "10", "12", "16", "17", "19",
                 "35", "53", "61", "77"}

# Honest sub-classification of the ids above, printed in the coverage block.
# A trap id in TRAP_PATHS does NOT mean an independent check exists for it.
TRAPS_SHARED_HEURISTIC = {
    # decided by the same single render inspection that decides trap 04
    "25": "shares the trap-04 history-render heuristic; no independent probe",
    # annotation on the single trap-12 ceiling finding, not a separate probe
    "16": "annotation on the trap-12 ceiling finding; no independent probe",
    "22": "linked from the ceiling check so you can find the entry, but never "
          "given a verdict by it; see the label-only note below",
}
TRAPS_NEED_HF_REPO = {"10", "17", "21", "163"}
TRAPS_NEED_RENDER_PATH = {"04", "20", "24", "25", "30", "38", "43", "56", "57", "59", "63", "66", "67", "69", "82", "83", "85", "86", "93", "113", "148", "68"}

# Ids this tool reports on that are NOT numbered registry entries. They are
# advisory: real observations with real fixes, but no trap file, no README row
# and no entry a reader can go and check. Printing them beside numbered traps
# without saying so invites the reader to look up a trap that does not exist.
ADVISORY_IDS = {
    "mm-surface": "multimodal surface (does this lane accept media at all)",
    "mm-audio-video": "audio and video channels, which this tool never probes",
}

# Checks that read a label or a manifest rather than the running engine, so
# they can never reach CLEAN no matter what they find. Declared here so the
# coverage block cannot be read as depth this tool does not have.
TRAPS_NEVER_CLEAN = {
    "10": "the hub check reads the checkpoint's quantisation manifest, which "
          "establishes the LABEL. Trap 10 is about the kernel path the engine "
          "actually took, which needs a runtime tell, so this check can reach "
          "INCONCLUSIVE but never CLEAN",
    "65": "force_nonempty_content can be observed only under a demonstrated "
          "empty-at-cap baseline, so absence of that shape never clears the trap",
    "156": "one bounded request without a retokenized undercount cannot clear "
           "long-running requeue accounting on ExLlamaV3",
    "158": "a single post-tool reply lacking empty markers cannot refute a "
           "probabilistic template branch observed under longer workloads",
    "22": "a budget floor is a distribution across sizes and budgets; this "
          "tool sends one request at one budget, so it never reaches a "
          "trap-22 verdict in either direction",
}

# huggingface.co, overridable so the regression suite can point at a fixture
# instead of the live hub. Not a command-line flag on purpose: the safety
# story says "your endpoint and huggingface.co", and that stays true.
HF_BASE = "https://huggingface.co"


def trap(n):
    """Registry link for a trap id. Ids that are not yet numbered in the
    registry (drafts pending a land) resolve to the traps index."""
    p = TRAP_PATHS.get(n)
    return f"{REG}/{p}" if p else REG


RMARK = "ZQXMARK_REASONING_7734"
TOOLS = [{"type": "function", "function": {
    "name": "get_time", "description": "Get current time in a timezone",
    "parameters": {"type": "object",
                   "properties": {"timezone": {"type": "string"}},
                   "required": ["timezone"]}}}]

# ------------------------------------------------------------- transport

def _req(url, key=None, data=None, timeout=60):
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"} if data else {})
    if key:
        req.add_header("Authorization", f"Bearer {key}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read().decode("utf-8", "replace")
        finally:
            e.close()
    except Exception as e:
        return None, str(e)

def get(url, key=None, timeout=15):
    return _req(url, key, None, timeout)

def post(url, body, key=None, timeout=180):
    return _req(url, key, json.dumps(body).encode(), timeout)

# ------------------------------------------------------------ diagnosis state

def A(claim, observed, held=True):
    """One recorded assertion: what was claimed, what was seen, did it hold.

    Every verdict carries these. A CLEAN with no assertions behind it is a
    bug in this file, and the regression suite fails the build over it.
    """
    return {"assert": claim, "observed": observed,
            "result": "held" if held else "failed"}


class RequestBudgetExceeded(RuntimeError):
    """Raised before an HTTP chat completion that would exceed doc.request_budget."""


class Doc:
    """Verdict accumulator.

    Four levels, borrowed from checks/preflight_template.py so the two tools
    speak one vocabulary:

      PROBLEM       a defect was observed
      OK            observed, and the observation rules out the defect
      INCONCLUSIVE  the probe RAN and returned, but several materially
                    different states produce this same result
      UNKNOWN       the probe could not run, or a precondition was missing
                    (this is preflight_template's NO_RENDER_PATH shape)
    """

    def __init__(self, request_budget=None):
        self.findings = []
        self.requests_made = 0
        # Hard ceiling on chat completions (None = unlimited). Checked before
        # every chat-completion HTTP call via consume_request().
        self.request_budget = request_budget
        self.stack, self.model, self.build = "unknown", None, None
        self.evidence = {}

    def consume_request(self):
        """Reserve one chat-completion request before the HTTP call is issued."""
        if self.request_budget is not None and self.requests_made >= self.request_budget:
            raise RequestBudgetExceeded(
                f"request budget exhausted: made={self.requests_made} "
                f"budget={self.request_budget}"
            )
        self.requests_made += 1

    def _add(self, level, traps, title, code, detail, asserts):
        self.findings.append({"level": level, "code": code, "traps": list(traps),
                              "title": title, "detail": detail,
                              "assertions": list(asserts or [])})

    def problem(self, traps, title, fix, code="PROBLEM", asserts=None):
        self._add("PROBLEM", traps, title, code, fix, asserts)

    def ok(self, traps, title, code="OK", asserts=None):
        self._add("OK", traps, title, code, None, asserts)

    def inconclusive(self, traps, title, why, code="INCONCLUSIVE", asserts=None):
        self._add("INCONCLUSIVE", traps, title, code, why, asserts)

    def skip(self, traps, title, why, code="UNKNOWN", asserts=None):
        self._add("UNKNOWN", traps, title, code, why, asserts)

    # -- views ------------------------------------------------------------
    def by(self, level):
        """Findings at one level, Core-tier first.

        The sort is stable, so within the Core group and within the rest the
        original probe order is preserved. Ordering only; nothing is dropped,
        no verdict changes, and a finding that touches no numbered trap sorts
        with the non-Core group rather than being hidden.
        """
        out = [f for f in self.findings if f["level"] == level]
        out.sort(key=lambda f: 0 if CORE_TRAP_IDS & set(f["traps"]) else 1)
        return out

    @property
    def problems(self): return self.by("PROBLEM")
    @property
    def clean(self): return self.by("OK")
    @property
    def unsure(self): return self.by("INCONCLUSIVE")
    @property
    def blocked(self): return self.by("UNKNOWN")

    def trap_ids(self, level):
        out = set()
        for f in self.by(level):
            out |= {n for n in f["traps"] if n in TRAP_PATHS}
        return out


def chat(doc, base, key, model, messages, **kw):
    body = {"model": model or "default", "messages": messages,
            "temperature": 0, "max_tokens": kw.pop("max_tokens", 128)}
    body.update(kw)
    doc.consume_request()
    st, txt = post(base + "/chat/completions", body, key)
    if st != 200:
        return st, None, txt
    try:
        d = json.loads(txt)
        return st, d["choices"][0], d
    except Exception as e:
        return st, None, f"unparseable: {e}"

def msg_fields(choice):
    m = choice["message"]
    return (m.get("content") or "", m.get("reasoning_content") or "",
            m.get("reasoning") or "", m.get("tool_calls") or [], m)

# ------------------------------------------------------------------ checks

def detect_stack(doc, base, root, key):
    st, txt = get(base + "/models", key)
    if st != 200:
        return False
    models_owner = None
    try:
        model_row = json.loads(txt)["data"][0]
        doc.model = model_row["id"]
        models_owner = model_row.get("owned_by")
    except Exception:
        pass
    st, txt = get(root + "/api/version", key, timeout=8)
    if st == 200 and '"version"' in (txt or ""):
        # Ollama. Worth detecting for one specific reason: it does not read
        # chat_template_kwargs at all, so the vLLM spelling below is accepted,
        # silently ignored, and makes every toggle arm fire.
        doc.stack = "ollama"
        try:
            doc.build = str(json.loads(txt).get("version", ""))[:40]
        except Exception:
            pass
        return True
    st, txt = get(root + "/props", key, timeout=8)
    if st == 200:
        doc.stack = "llama.cpp"
        try:
            props = json.loads(txt)
            doc.evidence["props"] = props
            doc.build = (props.get("build_info") or "")[:40]
        except Exception:
            pass
    else:
        # SGLang 0.5.16 has neither /props nor /version, but identifies its
        # model rows. Check that before falling through to the anonymous
        # OpenAI-compatible bucket.
        if models_owner == "sglang":
            doc.stack = "sglang"
        else:
            # mlx server and vLLM both lack /props; tell them apart cheaply
            st2, _ = get(root + "/version", key, timeout=8)
            doc.stack = ("vllm" if st2 == 200
                         else "openai-compatible (vLLM/MLX/other)")
    return True


# Which request field turns thinking on and off is a property of the SERVING
# STACK, not of the model. This tool used to send vLLM's spelling to every
# lane. On a stack that does not read it the kwarg is accepted, ignored, and
# every arm fires -- which is indistinguishable from an off switch that does
# not work, and was reported as exactly that. Measured on Ollama 0.32.5:
# chat_template_kwargs.enable_thinking=false leaves thinking ON (569 chars of
# reasoning) while reasoning_effort=none turns it OFF (0 chars). The old code
# called that lane a trap-03 PROBLEM and, on the same evidence, emitted a
# trap-29 CLEAN asserting no client kwarg could override. Both were wrong.
VLLM_OFF = ("chat_template_kwargs.enable_thinking=false",
            {"chat_template_kwargs": {"enable_thinking": False}})
VLLM_ON = ("chat_template_kwargs.enable_thinking=true",
           {"chat_template_kwargs": {"enable_thinking": True}})
EFFORT_OFF = ("reasoning_effort=none", {"reasoning_effort": "none"})
EFFORT_ON = ("reasoning_effort=high", {"reasoning_effort": "high"})

# Stacks whose thinking-off spelling we have established first-hand. Only for
# these may "the off switch does not work" be asserted from a firing off arm:
# anywhere else, a firing off arm is equally consistent with having sent a
# name the stack never reads.
STACKS_WITH_KNOWN_OFF_CONTROL = {"vllm", "llama.cpp", "ollama", "sglang"}


def on_control_for(stack):
    return EFFORT_ON if stack == "ollama" else VLLM_ON


def off_controls_for(stack):
    """Off controls to try, the stack's own spelling first.

    The alternates are tried too, because a control that actually suppresses is
    positive evidence about THIS lane no matter which stack we guessed.
    """
    return [EFFORT_OFF, VLLM_OFF] if stack == "ollama" else [VLLM_OFF, EFFORT_OFF]


def check_reasoning_fields(doc, base, key):
    """Traps 01 (read side), 02 (orphan close), 03 (toggle map), 29 (override)."""
    arms = {}
    on_label, on_body = on_control_for(doc.stack)
    off_tries = off_controls_for(doc.stack)
    off_label, off_body = off_tries[0]
    doc.evidence["thinking_controls"] = {
        "stack": doc.stack, "on": on_label,
        "off_tried_in_order": [lbl for lbl, _ in off_tries]}
    for name, body_kw in (("on", on_body),
                          ("off", off_body),
                          ("absent", {})):
        st, choice, raw = chat(doc, base, key, doc.model,
                               [{"role": "user", "content":
                                 "Which is larger, 17*24 or 400? Answer briefly."}],
                               max_tokens=256, **body_kw)
        if st != 200 or choice is None:
            arms[name] = {"error": f"http {st}"}
            continue
        c, rc, rr, _tc, m = msg_fields(choice)
        arms[name] = {
            "content_len": len(c),
            "reasoning_content": len(rc), "reasoning": len(rr),
            "think_in_content": "<think>" in c or "</think>" in c,
            "stray_close": c.lstrip().startswith("</think>"),
            "keys": sorted(m.keys()), "finish": choice.get("finish_reason")}
    doc.evidence["toggle_arms"] = arms
    live = {k: v for k, v in arms.items() if "error" not in v}
    if not live:
        doc.skip(["01", "02", "03", "29"],
                 "reasoning field, orphan-tag, thinking-toggle and gate checks",
                 f"all three probe requests failed ({arms['on'].get('error')})",
                 code="ALL_ARMS_FAILED",
                 asserts=[A("at least one toggle arm returns HTTP 200",
                            {k: v.get("error") for k, v in arms.items()}, held=False)])
        return

    on = arms.get("on", {})
    fields = [k for k in ("reasoning_content", "reasoning") if on.get(k)]
    if fields:
        doc.ok(["01"], f"reasoning exposed under {' and '.join(fields)} "
               f"(read that exact name; the other name may not exist here)",
               code="REASONING_FIELD_IDENTIFIED",
               asserts=[A("thinking-on response carries a non-empty reasoning field",
                          {k: on.get(k) for k in ("reasoning_content", "reasoning")})])
    elif on.get("think_in_content"):
        doc.problem(["01"], "reasoning arrives as <think> tags inside content, "
                    "not as a separate field: any harness reading only a "
                    "reasoning field scores this lane as never thinking",
                    "parse think tags from content on this lane, or enable the "
                    "server's reasoning parser",
                    code="REASONING_IN_CONTENT",
                    asserts=[A("thinking-on content contains think tags",
                               on.get("content_len"))])
    elif "error" not in on:
        # The old code called this CLEAN. It is not. Six materially different
        # states produce "no reasoning field, no think tags, HTTP 200", and
        # this probe cannot tell them apart. Trap 07's own rule (acceptance
        # proves nothing) applies to silence as well.
        doc.skip(["01"], "reasoning read-field identification",
                 "with thinking requested ON the response carried no reasoning "
                 "field and no think tags. That single observation is produced "
                 "by at least six materially different states, and this probe "
                 "distinguishes none of them: (1) a genuinely non-reasoning "
                 "model, (2) the enable_thinking kwarg accepted and ignored, "
                 "(3) the server's reasoning parser not enabled so the trace "
                 "was discarded, (4) the chat template not reading this kwarg "
                 "at all, (5) reasoning emitted on a third channel this tool "
                 "does not read, (6) a genuine server-side gate. Determine "
                 "which before reporting this lane as non-thinking: enumerate "
                 "the kwargs the template reads with "
                 "checks/preflight_template.py --template-file, and check the "
                 "server's reasoning-parser flag.",
                 code="THINKING_ON_NO_REASONING",
                 asserts=[A("thinking-on response carries reasoning_content, "
                            "reasoning, or think tags in content",
                            {"reasoning_content": on.get("reasoning_content"),
                             "reasoning": on.get("reasoning"),
                             "think_in_content": on.get("think_in_content"),
                             "message_keys": on.get("keys")}, held=False)])

    # -- trap 02, scoped to the arms that actually answered ----------------
    stray = [n for n, a in live.items() if a.get("stray_close")]
    if stray:
        doc.problem(["02"], f"response content starts with a stray </think> "
                    f"({', '.join(stray)} arm): parser strips the open tag but "
                    f"not the close",
                    "fix the reasoning-parser pairing; strip the orphan before "
                    "scoring anything",
                    code="ORPHANED_CLOSE_THINK",
                    asserts=[A("no returned arm starts with </think>", stray,
                               held=False)])
    elif len(live) == len(arms):
        doc.ok(["02"], "no orphaned </think> at the start of any of the three "
               "probe responses",
               code="NO_ORPHANED_CLOSE_THINK",
               asserts=[A("no returned arm starts with </think>",
                          sorted(live))])
    else:
        doc.inconclusive(["02"], "orphaned </think> at content start",
                         f"clean in the {len(live)} arm(s) that returned "
                         f"({', '.join(sorted(live))}), but "
                         f"{len(arms) - len(live)} arm(s) failed and were never "
                         f"inspected. An orphan that only appears under the "
                         f"unexamined arm would not have been seen.",
                         code="ORPHAN_CHECK_PARTIAL",
                         asserts=[A("all three arms inspected for a leading "
                                    "</think>", sorted(live), held=False)])

    # -- traps 03 and 29 ---------------------------------------------------
    def fired(a):
        return bool(a.get("reasoning_content") or a.get("reasoning")
                    or a.get("think_in_content"))

    if len(live) < 3:
        doc.skip(["03", "29"], "thinking-toggle map and server-side gate",
                 f"the map needs all three arms (explicit on, explicit off, "
                 f"kwarg absent); {len(arms) - len(live)} failed",
                 code="TOGGLE_ARMS_INCOMPLETE",
                 asserts=[A("all three toggle arms returned", sorted(live),
                            held=False)])
        return

    f_on, f_off, f_abs = fired(on), fired(arms["off"]), fired(arms["absent"])

    # If the primary off control did not suppress, try the other spellings we
    # know before concluding anything. A control that suppresses settles the
    # question by observation and outranks any guess from stack detection.
    working_off = None if f_off else off_label
    alt_results = {}
    if f_off:
        for lbl, body in off_tries[1:]:
            st, choice, _raw = chat(doc, base, key, doc.model,
                                    [{"role": "user", "content":
                                      "Which is larger, 17*24 or 400? Answer briefly."}],
                                    max_tokens=256, **body)
            if st != 200 or choice is None:
                alt_results[lbl] = f"http {st}"
                continue
            c, rc, rr, _tc, _m = msg_fields(choice)
            a_fired = bool(rc or rr or "<think>" in c or "</think>" in c)
            alt_results[lbl] = {"fired": a_fired}
            if not a_fired:
                working_off = lbl
                break
        doc.evidence["off_control_alternates"] = alt_results
    doc.evidence["working_off_control"] = working_off
    # Established = we can name the control this lane reads, either because one
    # demonstrably suppressed, or because the detected stack's own documented
    # spelling is what we sent.
    off_established = bool(working_off) or doc.stack in STACKS_WITH_KNOWN_OFF_CONTROL
    doc.evidence["toggle_fired"] = {"on": f_on, "off": f_off, "absent": f_abs}
    if not (f_on or f_off or f_abs):
        # A toggle map in which nothing ever fires is not a map. Reporting
        # "on=False, off=False, absent lands off-like" as CLEAN told operators
        # their toggle was characterised when in fact no arm produced any
        # observable, so no arm could be told apart from any other.
        doc.skip(["03", "29"], "thinking-toggle map and server-side gate",
                 "no arm produced any reasoning observable at all, so the three "
                 "arms are indistinguishable and the toggle is uncharacterised. "
                 "This is the same silence as the read-field check above and has "
                 "the same six candidate causes; resolve that one first.",
                 code="TOGGLE_MAP_VACUOUS",
                 asserts=[A("at least one toggle arm produces a reasoning "
                            "observable", {"on": f_on, "off": f_off,
                                           "absent": f_abs}, held=False)])
        return

    landing = ("on-like" if f_abs == f_on and f_on else
               ("off-like" if f_abs == f_off else "distinct"))
    if f_off and working_off:
        # The spelling we tried first is not the one this lane reads, but a
        # control that does exist was found. This is NOT trap 03's defect: the
        # lane has a working off switch, under a different name.
        doc.ok(["03"], f"thinking toggle map: {off_label} does NOT turn "
               f"thinking off on this lane, but {working_off} does. "
               f"explicit-on fired, explicit-off under {working_off} did not, "
               f"absent lands {landing}. Use {working_off} here, and treat the "
               f"other spelling as accepted-and-ignored rather than as an off "
               f"switch",
               code="OFF_CONTROL_IS_A_DIFFERENT_KWARG",
               asserts=[A("the explicit-on arm fires", {"on": f_on}),
                        A(f"an off control was found that suppresses reasoning",
                          {"control": working_off, "alternates": alt_results}),
                        A("the first-tried spelling did not suppress",
                          {"tried": off_label, "fired": f_off})])
    elif f_off and not off_established:
        # Every off control we know fired, but the stack was never identified,
        # so we cannot say we sent the name it reads. "The off switch is
        # broken" and "we used the wrong word" produce this identical
        # observation. Calling it a PROBLEM here is the false positive this
        # tool produced against Ollama.
        doc.skip(["03"], "thinking-toggle map",
                 f"reasoning fired on every arm including explicit-off, but "
                 f"the stack behind this endpoint was not identified "
                 f"(detected: {doc.stack!r}), so the off control it reads is "
                 f"unknown. Tried "
                 f"{', '.join(lbl for lbl, _ in off_tries)}; none suppressed. "
                 f"A lane that ignores the kwarg you sent is indistinguishable "
                 f"from a lane whose off switch does not work, and this tool "
                 f"cannot tell them apart without knowing the stack. Enumerate "
                 f"the kwargs the template actually reads with "
                 f"checks/preflight_template.py --template-file, or name the "
                 f"stack, before treating this lane as having no off switch.",
                 code="OFF_CONTROL_NAME_NOT_ESTABLISHED",
                 asserts=[A("the off control this lane reads is known",
                            {"stack": doc.stack,
                             "tried": [lbl for lbl, _ in off_tries],
                             "alternates": alt_results}, held=False)])
        # deliberately NOT a return: trap 29 gets its own verdict below, from
        # its own gate. Returning here made that gate unreachable, and a
        # mutation run proved the test protecting it passed for the wrong
        # reason -- the code it was meant to exercise never ran.
    elif f_off:
        # An explicit off that still produces reasoning is the defect trap 03
        # is about, and the old code reported it as a characterised map. A map
        # is not a clean bill: it described the arms and then filed the
        # description under CHECKED AND CLEAN even when the off arm fired.
        doc.problem(["03"], f"explicit-off still produces reasoning: the arm "
                    f"sent with enable_thinking=false fired anyway "
                    f"(on={f_on}, off={f_off}, absent lands {landing}). The "
                    f"off switch on this lane does not turn thinking off, so "
                    f"every 'non-thinking' budget, latency and cost number "
                    f"taken here was measured on a thinking lane",
                    "do not treat enable_thinking=false as an off state on "
                    "this lane. Find the kwarg the template actually reads "
                    "(checks/preflight_template.py --template-file), or gate "
                    "thinking server-side, and re-take any number that assumed "
                    "the off arm was off",
                    code="EXPLICIT_OFF_STILL_FIRES",
                    asserts=[A("the explicit-off arm produces no reasoning "
                               "observable",
                               {"on": f_on, "off": f_off, "absent": f_abs,
                                "controls_tried": [lbl for lbl, _ in off_tries],
                                "stack": doc.stack},
                               held=False)])
    elif f_on:
        doc.ok(["03"], f"thinking toggle map: explicit-on fired, explicit-off "
               f"did not, absent lands {landing}. The two explicit arms are "
               f"separable and the off arm is genuinely off. Send the kwarg "
               f"explicitly: the absent arm is revision- and server-dependent "
               f"and this run says only where it landed today, not that "
               f"leaving it out is safe",
               code="TOGGLE_MAP_CHARACTERISED",
               asserts=[A("the explicit-on arm fires", {"on": f_on}),
                        A("the explicit-off arm does not fire", {"off": f_off}),
                        A("the kwarg-absent arm was observed and classified",
                          {"absent": f_abs, "lands": landing})])
    else:
        # Something fired (checked above) but not the explicit-on arm, so the
        # toggle has no positive control and the map cannot be read as one.
        doc.inconclusive(["03"], "thinking-toggle map",
                         f"a reasoning observable appeared on this lane, but "
                         f"NOT on the explicit-on arm (on={f_on}, off={f_off}, "
                         f"absent={f_abs}). Without the on arm firing there is "
                         f"no positive control, so which kwarg value produces "
                         f"which state cannot be read off these three arms. "
                         f"Enumerate the kwargs the template actually reads "
                         f"with checks/preflight_template.py --template-file "
                         f"before describing this lane's toggle.",
                         code="TOGGLE_MAP_NO_POSITIVE_CONTROL",
                         asserts=[A("the explicit-on arm fires (positive "
                                    "control)", {"on": f_on, "off": f_off,
                                                 "absent": f_abs}, held=False)])

    if f_on and not f_abs:
        doc.problem(["29"], "server-side default has thinking off, but a "
                    "client kwarg re-enables it per request: the flag is a "
                    "default, not a gate, and thinking requests can blow "
                    "non-thinking token budgets",
                    "strip or deny thinking kwargs at your gateway, or size "
                    "max_tokens for the thinking distribution",
                    code="SERVER_OFF_IS_NOT_A_GATE",
                    asserts=[A("kwarg-absent arm fires whenever explicit-on "
                               "fires", {"on": f_on, "absent": f_abs},
                               held=False)])
    elif f_abs and off_established:
        doc.ok(["29"], f"thinking already fires with no kwarg sent, so there is "
               f"no server-side off state for a client kwarg to override on "
               f"this lane. The client-side control that does work here is "
               f"{working_off or off_label}",
               code="NO_SERVER_SIDE_OFF_STATE",
               asserts=[A("kwarg-absent arm fires", {"absent": f_abs}),
                        A("the client off control this lane reads is known, so "
                          "the claim about client kwargs is not made from "
                          "silence",
                          {"control": working_off or off_label,
                           "stack": doc.stack})])
    elif f_abs:
        # The absent arm firing is a real observation, but the sentence this
        # CLEAN used to make is about CLIENT KWARGS, and we do not know which
        # kwarg this lane reads. Asserting that none can override, having tried
        # only names we guessed, is a clean earned from silence.
        doc.skip(["29"], "server-side thinking gate",
                 f"thinking fires with no kwarg sent, so the server default is "
                 f"on -- but the stack was not identified (detected: "
                 f"{doc.stack!r}) and no off control we tried suppressed, so "
                 f"whether a client kwarg can override cannot be stated. That "
                 f"is a claim about client kwargs and it needs the name this "
                 f"lane reads.",
                 code="SERVER_GATE_CONTROL_UNKNOWN",
                 asserts=[A("the client off control this lane reads is known",
                            {"stack": doc.stack,
                             "tried": [lbl for lbl, _ in off_tries]},
                            held=False)])
    else:
        doc.inconclusive(["29"], "server-side thinking gate",
                         "explicit-on did not fire either, so there is no "
                         "positive control: whether a client kwarg can "
                         "override a server-side off cannot be told from a "
                         "lane where the kwarg never demonstrably worked.",
                         code="GATE_NO_POSITIVE_CONTROL",
                         asserts=[A("explicit-on arm fires (positive control)",
                                    {"on": f_on}, held=False)])


def check_streaming(doc, base, key):
    """Traps 23 and 80: channel placement plus stream-delta batching."""
    body = {"model": doc.model or "default",
            "messages": [{"role": "user", "content": "Capital of Norway? One word."}],
            "stream": True, "stream_options": {"include_usage": True},
            "max_tokens": 64, "temperature": 0,
            "chat_template_kwargs": {"enable_thinking": False}}
    doc.consume_request()
    keys = {}
    text_deltas = 0
    completion_tokens = None
    try:
        req = urllib.request.Request(base + "/chat/completions",
                                     json.dumps(body).encode(),
                                     {"Content-Type": "application/json"})
        if key:
            req.add_header("Authorization", f"Bearer {key}")
        with urllib.request.urlopen(req, timeout=120) as r:
            for line in r:
                line = line.decode("utf-8", "replace").strip()
                if not line.startswith("data: {"):
                    continue
                payload = json.loads(line[6:])
                usage = payload.get("usage") or {}
                if isinstance(usage.get("completion_tokens"), int):
                    completion_tokens = usage["completion_tokens"]
                choices = payload.get("choices") or []
                if not choices:
                    continue
                delta = choices[0].get("delta", {})
                had_text = False
                for k, v in delta.items():
                    if v:
                        keys[k] = keys.get(k, 0) + 1
                        if k in ("content", "reasoning", "reasoning_content") and isinstance(v, str):
                            had_text = True
                if had_text:
                    text_deltas += 1
        doc.evidence["stream_delta_keys"] = keys
        doc.evidence["stream_delta_count"] = text_deltas
        doc.evidence["stream_completion_tokens"] = completion_tokens

        if keys.get("content"):
            doc.ok(["23"], f"streamed answer arrives in content deltas ({keys})",
                   code="STREAM_CONTENT_DELTAS",
                   asserts=[A("at least one non-empty content delta", keys)])
        elif keys.get("reasoning") or keys.get("reasoning_content"):
            doc.problem(["23"], f"streamed answer arrives ONLY in reasoning deltas "
                        f"with thinking off ({keys}): clients that concatenate "
                        f"content see blank replies",
                        "upgrade the engine or read reasoning deltas as a fallback channel",
                        code="STREAM_ANSWER_IN_REASONING",
                        asserts=[A("at least one non-empty content delta", keys,
                                   held=False)])
        else:
            doc.skip(["23"], "streaming delta placement", "no non-empty deltas seen",
                     code="STREAM_NO_DELTAS",
                     asserts=[A("stream produced non-empty deltas", keys, held=False)])

        if not isinstance(completion_tokens, int) or completion_tokens <= 0:
            doc.skip(["80"], "stream delta batching ratio",
                     "the stream did not include usage.completion_tokens, so delta count "
                     "cannot be compared with generated token count",
                     code="STREAM_USAGE_UNAVAILABLE",
                     asserts=[A("stream returned completion_tokens usage",
                                completion_tokens, held=False)])
        else:
            ratio = text_deltas / completion_tokens
            if completion_tokens >= 8 and ratio < 0.5:
                doc.problem(
                    ["80"],
                    f"only {text_deltas} text-bearing SSE deltas carried "
                    f"{completion_tokens} completion tokens (ratio {ratio:.2f}); "
                    "stream arrival timing is parser flush timing, not token timing",
                    "Do not derive TTFT/inter-token/decode speed from SSE delta timing "
                    "on this lane. Use non-stream total wall time plus a prefill control.",
                    code="STREAM_DELTAS_BATCH_TOKENS",
                    asserts=[A("text-bearing delta count is at least half the "
                               "reported completion token count",
                               {"deltas": text_deltas,
                                "completion_tokens": completion_tokens,
                                "ratio": round(ratio, 4)}, held=False)])
            else:
                doc.inconclusive(
                    ["80"], "stream delta batching ratio",
                    f"observed {text_deltas} text-bearing deltas for "
                    f"{completion_tokens} completion tokens (ratio {ratio:.2f}). "
                    "That does not reproduce the strong batching signature, but a "
                    "near-1 ratio is not enough to prove token-per-delta timing.",
                    code="STREAM_BATCHING_NOT_PROVEN",
                    asserts=[A("a single stream ratio can prove absence of parser "
                               "buffering", {"ratio": round(ratio, 4)}, held=False)])
    except Exception as e:
        doc.skip(["23", "80"], "streaming checks", f"stream failed: {e}",
                 code="STREAM_FAILED",
                 asserts=[A("stream request completed", str(e), held=False)])


def _vllm_render(doc, root, key, messages, kwargs, tools=None):
    """vLLM's assembled prompt, via /v1/chat/completions/render + /detokenize.

    vLLM has exposed a render route since 0.20.0. It returns token ids rather
    than text, so it needs a second call to be readable. Without this path the
    doctor reported "no render path on this stack" on every vLLM lane and
    skipped traps 04, 20 and 25, which is where the worst findings on this
    family came from.

    Falls back to /tokenize with per-token strings, which some builds answer
    even when the route listing does not advertise it.
    """
    body = {"model": doc.model, "messages": messages, "max_tokens": 1}
    if tools is not None:
        body["tools"] = tools
    if kwargs:
        body["chat_template_kwargs"] = kwargs
    st, txt = post(root + "/v1/chat/completions/render", body, key, timeout=30)
    if st == 200:
        try:
            ids = json.loads(txt).get("token_ids")
            if ids:
                st2, txt2 = post(root + "/detokenize",
                                 {"model": doc.model, "tokens": ids}, key, timeout=30)
                if st2 == 200:
                    d = json.loads(txt2)
                    prompt = d.get("prompt", d.get("text"))
                    if prompt is not None:
                        return prompt, "server /v1/chat/completions/render + /detokenize"
        except Exception:
            pass
    # fallback: tokenise with per-token strings and reassemble
    tb = {"model": doc.model, "messages": messages,
          "add_generation_prompt": True, "return_token_strs": True}
    if tools is not None:
        tb["tools"] = tools
    if kwargs:
        tb["chat_template_kwargs"] = kwargs
    st, txt = post(root + "/tokenize", tb, key, timeout=30)
    if st == 200:
        try:
            strs = json.loads(txt).get("token_strs")
            if strs:
                # byte-level BPE markers: G-with-dot is a space, C-with-dot a newline
                joined = "".join(strs)
                joined = joined.replace("Ġ", " ").replace("Ċ", "\n")
                return joined, "server /tokenize (token_strs)"
        except Exception:
            pass
    return None, None


def render_paths(doc, root, key, messages, kwargs, tools=None):
    """Return (prompt, how): llama.cpp /apply-template, vLLM render, or jinja2."""
    if doc.stack == "llama.cpp":
        body = {"messages": messages}
        if tools is not None:
            body["tools"] = tools
        if kwargs:
            body["chat_template_kwargs"] = kwargs
        st, txt = post(root + "/apply-template", body, key, timeout=30)
        if st == 200:
            try:
                return json.loads(txt).get("prompt", ""), "server /apply-template"
            except Exception:
                pass
    else:
        prompt, how = _vllm_render(doc, root, key, messages, kwargs, tools=tools)
        if prompt is not None:
            return prompt, how
    tpl = (doc.evidence.get("props") or {}).get("chat_template")
    if tpl:
        try:
            from jinja2 import Environment, BaseLoader
            env = Environment(loader=BaseLoader())
            env.globals["raise_exception"] = lambda m: ""
            env.globals["strftime_now"] = lambda fmt: ""
            return env.from_string(tpl).render(
                messages=messages, tools=tools or [], add_generation_prompt=True,
                bos_token="", eos_token="", **(kwargs or {})), "local jinja2"
        except Exception:
            pass
    return None, None


def check_thinking_string_false(doc, root, key):
    """Trap 57: JSON string "false" must not behave like boolean true."""
    messages = [{"role": "user", "content": "Reply with OK."}]
    arms = {}
    for label, value in (("true", True), ("bool_false", False), ("string_false", "false")):
        rendered, how = render_paths(
            doc, root, key, messages, {"enable_thinking": value}
        )
        arms[label] = rendered
        if rendered is not None:
            doc.evidence.setdefault("trap57_render_path", how)
    doc.evidence["trap57_render_arms"] = {
        name: None if value is None else len(value)
        for name, value in arms.items()
    }
    if any(value is None for value in arms.values()):
        doc.skip(
            ["57"], 'string "false" thinking coercion',
            "the check needs all three server/template renders (true, boolean false, "
            'string "false"); at least one render path was unavailable',
            code="STRING_FALSE_RENDER_INCOMPLETE",
            asserts=[A("all three render arms returned",
                       {name: value is not None for name, value in arms.items()},
                       held=False)])
        return

    on = arms["true"]
    off = arms["bool_false"]
    string_false = arms["string_false"]
    if on == off:
        doc.inconclusive(
            ["57"], 'string "false" thinking coercion',
            "boolean true and boolean false render identically, so the lane did not "
            "establish that enable_thinking controls this prompt. Without a working "
            'typed control, the string "false" arm cannot be interpreted.',
            code="STRING_FALSE_NO_TYPED_CONTROL",
            asserts=[A("boolean true and boolean false render differently",
                       {"identical": True}, held=False)])
        return
    if string_false == on:
        doc.problem(
            ["57"],
            'enable_thinking="false" renders exactly like boolean true, while JSON '
            "boolean false renders differently: the string is truthy and turns thinking on",
            'normalise caller values to real booleans before they reach the template; reject '
            'string booleans instead of passing them through',
            code="STRING_FALSE_TURNS_THINKING_ON",
            asserts=[
                A("boolean true and boolean false render differently",
                  {"identical": False}),
                A('string "false" renders like boolean false',
                  {"string_matches_true": True, "string_matches_false": False},
                  held=False),
            ])
        return
    if string_false == off:
        doc.ok(
            ["57"],
            'string "false" renders exactly like JSON boolean false and unlike boolean true; '
            "the truthiness-coercion failure is not present on this render path",
            code="STRING_FALSE_PARSED_AS_FALSE",
            asserts=[
                A("boolean true and boolean false render differently",
                  {"identical": False}),
                A('string "false" renders like boolean false',
                  {"string_matches_false": True}),
            ])
        return
    doc.inconclusive(
        ["57"], 'string "false" thinking coercion',
        'the string "false" render differs from both boolean arms. The value is doing '
        "something, but this is not the trap-57 truthiness shape and is not clean.",
        code="STRING_FALSE_DISTINCT_RENDER",
        asserts=[A('string "false" matches either established boolean arm',
                   {"matches_true": False, "matches_false": False}, held=False)])





def check_in_text_thinking_toggle(doc, root, key):
    """Trap 66: compare magic substring paths against a non-magic control."""
    paths = (
        ("control", "src/reason/main.py", False),
        ("think", "src/think/main.py", False),
        ("no_think", "src/no_think/util.py", True),
    )
    output = {}
    for label, path, thinking in paths:
        text, how = render_paths(
            doc, root, key, [{"role": "user", "content": "Read " + path}],
            {"enable_thinking": thinking})
        output[label] = text
        if text is not None:
            doc.evidence.setdefault("trap66_render_path", how)
    intact = {label: output[label] is not None and path in output[label]
              for label, path, _ in paths}
    doc.evidence["trap66_paths_intact"] = intact
    if any(v is None for v in output.values()) or not intact["control"]:
        doc.skip(["66"], "user path thinking-toggle substring preservation",
                 "render path or unaffected control is unavailable",
                 code="THINK_PATH_CONTROL_UNAVAILABLE",
                 asserts=[A("all render controls available", intact, held=False)])
        return
    stripped = {
        "think": not intact["think"] and "src/main.py" in output["think"],
        "no_think": not intact["no_think"] and "src/util.py" in output["no_think"],
    }
    if any(stripped.values()):
        doc.problem(["66"], "the rendered user path lost a literal /think "
                    "or /no_think directory component",
                    "inspect the served chat template for substring-based "
                    "thinking mode switches and message rewriting",
                    code="THINK_PATH_SUBSTRING_DELETED",
                    asserts=[A("thinking-toggle path remains verbatim",
                               {"intact": intact, "stripped": stripped},
                               held=False)])
    elif intact["think"] and intact["no_think"]:
        doc.ok(["66"], "both magic-substring paths and the control path "
               "survived this rendered-prompt check",
               code="THINK_PATHS_PRESERVED",
               asserts=[A("three submitted paths survived exactly", intact)])
    else:
        doc.inconclusive(["66"], "user path thinking-toggle substrings",
                         "a path changed, but not into the documented deletion shape",
                         code="THINK_PATH_UNCLASSIFIED",
                         asserts=[A("paths intact or specific deletion observed",
                                    {"intact": intact, "stripped": stripped},
                                    held=False)])


def check_history_object_repr(doc, root, key):
    """Trap 67: detect normalized content-part lists printed as Python repr."""
    markers = ("MF67_SYS_4A2", "MF67_ASSIST_4A2", "MF67_USER_4A2")
    messages = [
        {"role": "system", "content": markers[0]},
        {"role": "user", "content": "MF67 starting query"},
        {"role": "assistant", "content": markers[1]},
        {"role": "user", "content": markers[2]},
    ]
    output, how = render_paths(doc, root, key, messages, {})
    if output is None or any(output.count(m) != 1 for m in markers):
        doc.skip(["67"], "Python representation in rendered chat history",
                 "multi-turn render missing or markers not preserved uniquely",
                 code="HISTORY_REPR_RENDER_UNAVAILABLE",
                 asserts=[A("three unique markers preserved",
                            {m: None if output is None else output.count(m)
                             for m in markers}, held=False)])
        return
    doc.evidence["trap67_render_path"] = how
    has_repr = bool(re.search(
        r"\[\{\s*['\"]type['\"]\s*:\s*['\"]text['\"]\s*,\s*['\"]text['\"]\s*:",
        output))
    doc.evidence["trap67_object_repr_seen"] = has_repr
    if has_repr:
        doc.problem(["67"], "rendered history includes Python dictionary/list "
                    "syntax from an unhandled text-part content list",
                    "inspect server normalization and the template's "
                    "content-is-string branches",
                    code="HISTORY_PYTHON_REPR",
                    asserts=[A("no Python content-part repr in rendered history",
                               {"found": True}, held=False)])
    else:
        doc.ok(["67"], "no Python text-part object representation appeared in "
               "this complete marked history render",
               code="HISTORY_NO_PYTHON_REPR",
               asserts=[A("content-part object repr absent",
                          {"found": False})])


def check_inline_system_role(doc, root, key):
    """Trap 113: classify inline system role using exact rendered controls."""
    early = "MF113_EARLY_4D9"
    late = "MF113_LATE_4D9"
    q, q2 = "MF113_Q_4D9", "MF113_Q2_4D9"
    cases = {
        "plain": [{"role": "user", "content": q},
                  {"role": "user", "content": q2}],
        "leading": [{"role": "system", "content": early},
                    {"role": "user", "content": q}],
        "inline": [{"role": "user", "content": q},
                   {"role": "system", "content": late},
                   {"role": "user", "content": q2}],
    }
    arms = {}
    for name, messages in cases.items():
        output, how = render_paths(doc, root, key, messages, {})
        arms[name] = output
        if output is not None:
            doc.evidence.setdefault("trap113_render_path", how)
    valid = all(v is not None for v in arms.values())
    if valid:
        valid = (arms["plain"].count(q) == 1 and arms["plain"].count(q2) == 1
                 and arms["leading"].count(early) == 1
                 and arms["inline"].count(q) == 1
                 and arms["inline"].count(q2) == 1)
    if not valid:
        doc.skip(["113"], "inline system message role contract",
                 "baseline, leading-system and inline-system renders must all "
                 "retain their independent markers",
                 code="INLINE_SYSTEM_CONTROL_UNAVAILABLE",
                 asserts=[A("three complete controlled renders", {
                     k: v is not None for k, v in arms.items()}, held=False)])
        return
    # Never call unrecognized template delimiter dialects clean.
    spans = lambda s: re.findall(
        r"<\|im_start\|>(system|user)\s*\n([\s\S]*?)<\|im_end\|>", s)
    lead_ok = any(role == "system" and early in body
                  for role, body in spans(arms["leading"]))
    inline_sys = any(role == "system" and late in body
                     for role, body in spans(arms["inline"]))
    inline_usr = any(role == "user" and late in body
                     for role, body in spans(arms["inline"]))
    count = arms["inline"].count(late)
    doc.evidence["trap113_role_checks"] = {
        "leading_system_marked": lead_ok,
        "inline_system_marked": inline_sys,
        "inline_user_marked": inline_usr,
        "inline_marker_count": count,
        "identical_to_plain": arms["inline"] == arms["plain"],
    }
    if count == 0 and arms["inline"] == arms["plain"]:
        doc.problem(["113"], "inline system content disappeared and the render "
                    "became byte-identical to a no-system control",
                    "do not trust inline system roles without a pinned "
                    "constructor; reject or explicitly normalize the message list",
                    code="INLINE_SYSTEM_DROPPED",
                    asserts=[A("inline system marker must survive",
                               {"count": count}, held=False)])
    elif lead_ok and count == 1 and inline_usr and not inline_sys:
        doc.problem(["113"], "inline system text is welded into a user span",
                    "do not silently lower a privileged system instruction "
                    "to the user tier",
                    code="INLINE_SYSTEM_WELDED_TO_USER",
                    asserts=[A("inline system marker inside system role",
                               {"under_user": True}, held=False)])
    elif lead_ok and count == 1 and inline_sys and not inline_usr:
        doc.ok(["113"], "inline system marker remains in a distinct system "
               "role span on this rendered constructor",
               code="INLINE_SYSTEM_ROLE_PRESERVED",
               asserts=[A("leading and inline system spans are explicit",
                          {"leading": True, "inline": True})])
    else:
        doc.inconclusive(["113"], "inline system role render contract",
                         "role boundaries are absent, conflicting, or "
                         "unclassifiable in this template dialect",
                         code="INLINE_SYSTEM_AMBIGUOUS",
                         asserts=[A("unambiguous system role classification",
                                    doc.evidence["trap113_role_checks"], held=False)])



def check_default_system_replacement(doc, root, key):
    """Trap 30: three-arm omission/empty/explicit-system render experiment."""
    marker, own = "MF30_USER_8C1", "MF30_OWN_SYSTEM_8C1"
    arms = {}
    for label, messages in (
        ("omitted", [{"role": "user", "content": marker}]),
        ("empty", [{"role": "system", "content": ""},
                   {"role": "user", "content": marker}]),
        ("explicit", [{"role": "system", "content": own},
                      {"role": "user", "content": marker}]),
    ):
        rendered, how = render_paths(doc, root, key, messages, {})
        arms[label] = rendered
        if rendered is not None:
            doc.evidence.setdefault("trap30_render_path", how)
    if any(x is None or x.count(marker) != 1 for x in arms.values()) or (
            arms["explicit"] is not None and arms["explicit"].count(own) != 1):
        doc.skip(["30"], "default-system replacement three-arm render",
                 "the omitted, empty and explicit-system controls must all "
                 "render and preserve unique user/system markers",
                 code="DEFAULT_REPLACE_CONTROLS_MISSING",
                 asserts=[A("all marked render arms complete",
                            {k: v is not None for k, v in arms.items()},
                            held=False)])
        return
    # Scoped to an explicit ChatML-style system span. An unmatched template
    # dialect cannot be called CLEAN merely because a regex misses it.
    def system_body(rendered):
        m = re.search(r"<\|im_start\|>system\s*\n(.*?)<\|im_end\|>",
                      rendered, re.S)
        return m.group(1) if m else None

    default = system_body(arms["omitted"])
    empty = system_body(arms["empty"])
    explicit = system_body(arms["explicit"])
    doc.evidence["trap30_system_span"] = {
        "omitted_nonempty": bool(default and default.strip()),
        "empty_has_content": bool(empty and empty.strip()),
        "explicit_has_marker": bool(explicit and own in explicit),
    }
    if (default is not None and default.strip() and
            empty is not None and not empty.strip() and
            explicit is not None and own in explicit and
            default not in explicit):
        doc.problem(["30"],
                    "omitting a system turn inserts non-empty default instructions; "
                    "an explicit empty system turn suppresses them and a caller "
                    "system turn replaces rather than preserves them",
                    "treat absent-system, empty-system and explicit-system "
                    "prompts as different experimental conditions",
                    code="DEFAULT_SYSTEM_REPLACED",
                    asserts=[A("caller system preserves the template default",
                               doc.evidence["trap30_system_span"], held=False)])
    else:
        doc.inconclusive(["30"], "default-system replacement experiment",
                         "the observed three-arm renders do not prove the "
                         "specific default-identity replacement mechanism; "
                         "absence of a recognizable span is not CLEAN",
                         code="DEFAULT_REPLACE_NOT_ESTABLISHED",
                         asserts=[A("paired system-span replacement proof",
                                    doc.evidence["trap30_system_span"], held=False)])


def check_template_owned_think_open(doc, root, key):
    """Trap 38: inspect opening think tag supplied by the template, not generation."""
    messages = [{"role": "user", "content": "MF38 checking template-owned prefill"}]
    on, how = render_paths(doc, root, key, messages, {"enable_thinking": True})
    off, _ = render_paths(doc, root, key, messages, {"enable_thinking": False})
    if on is None or off is None or "MF38 checking template-owned prefill" not in on:
        doc.skip(["38"], "thinking tag ownership in generation prefix",
                 "matched thinking-on/off render controls are not available",
                 code="THINK_PREFILL_RENDER_UNAVAILABLE",
                 asserts=[A("thinking-on and -off renders available",
                            {"on": on is not None, "off": off is not None},
                            held=False)])
        return
    # No inference generated. This finds a template-level contract, not proof
    # that an external rollout parser actually dropped the prefix.
    pattern = r"<think>\s*$"
    template_opens = bool(re.search(pattern, on))
    changed = on != off and not bool(re.search(pattern, off))
    doc.evidence["trap38_prefill"] = {
        "path": how, "thinking_on_ends_with_open": template_opens,
        "thinking_off_different": changed,
    }
    doc.inconclusive(
        ["38"], "template-owned opening think delimiter",
        ("thinking-on rendering visibly ends with an open <think> tag "
         "that thinking-off does not: offline raw-completion parsers must "
         "preserve this prefill, but no offline rollout was supplied"
         if template_opens and changed else
         "the paired render did not establish an opening think prefix owned "
         "by this template; alternate dialects or offline pipelines remain unknown"),
        code=("THINK_PREFILL_OWNED_BY_TEMPLATE" if template_opens and changed
              else "THINK_PREFILL_NOT_CHARACTERISED"),
        asserts=[A("an offline rollout's opening-tag handling was observed",
                   doc.evidence["trap38_prefill"], held=False)])


def check_tool_argument_dialect(doc, root, key):
    """Trap 43: identical tool call in object and JSON-string wire shapes."""
    marker = "MF43_ARG_VALUE_6E1"
    base = [{"role": "user", "content": "Find a city"}]
    def history(arguments):
        return base + [{
            "role": "assistant", "content": "",
            "tool_calls": [{"id": "callabc12", "type": "function",
                            "function": {"name": "lookup",
                                         "arguments": arguments}}],
        }, {"role": "tool", "tool_call_id": "callabc12",
            "name": "lookup", "content": "done"},
           {"role": "user", "content": "Continue"}]
    arms = {}
    for name, value in (
        ("object", {"city": marker}),
        ("string", json.dumps({"city": marker})),
    ):
        text, how = render_paths(doc, root, key, history(value), {})
        arms[name] = text
        if text is not None:
            doc.evidence.setdefault("trap43_render_path", how)
    present = {k: v is not None and marker in v for k, v in arms.items()}
    doc.evidence["trap43_argument_marker"] = present
    if arms["object"] is None or arms["string"] is None or not present["object"]:
        doc.skip(["43"], "tool arguments object/string render dialect",
                 "string/object controls or the positive object-arguments "
                 "marker were not available on this template",
                 code="TOOL_ARGS_DIALECT_CONTROL_MISSING",
                 asserts=[A("object control renders and contains parameter value",
                            present, held=False)])
    elif not present["string"]:
        doc.problem(["43"], "replayed tool argument string silently loses "
                    "the parameter value that object-form arguments preserve",
                    "support both JSON strings and mapping objects in the "
                    "template's tool-call arguments branch",
                    code="TOOL_ARGS_STRING_DROPPED",
                    asserts=[A("JSON-string arguments preserve parameter value",
                               present, held=False)])
    else:
        doc.ok(["43"], "tool parameter marker survives both object-form and "
               "JSON-string-form replay in the assembled prompt",
               code="TOOL_ARGS_BOTH_FORMS_PRESERVED",
               asserts=[A("both argument forms preserve the tool parameter value",
                          present)])


def check_minor_template_boundaries(doc, root, key):
    """Trap 69: empty system header and tool-first malformed control tags."""
    no_sys, how = render_paths(
        doc, root, key, [{"role": "user", "content": "MF69 plain"}], {})
    tool_first, _ = render_paths(
        doc, root, key, [
            {"role": "tool", "name": "lookup", "tool_call_id": "callabc12",
             "content": "MF69_TOOL_RESULT"},
            {"role": "user", "content": "MF69 next user"},
        ], {})
    if no_sys is None or tool_first is None or "MF69 plain" not in no_sys:
        doc.skip(["69"], "template boundary hygiene",
                 "both no-system and tool-first rendered controls are required",
                 code="TEMPLATE_BOUNDARY_CONTROLS_MISSING",
                 asserts=[A("no-system and tool-first renders available",
                            {"no_sys": no_sys is not None,
                             "tool_first": tool_first is not None}, held=False)])
        return
    empty_system = bool(re.search(
        r"<\|im_start\|>system\s*\n\s*<\|im_end\|>", no_sys))
    # Only call the tool-first malformed branch when we see a specific
    # closing-tag surplus in the same template dialect. Do not infer errors
    # from an unsupported/non-ChatML dialect.
    starts = tool_first.count("<|im_start|>")
    ends = tool_first.count("<|im_end|>")
    unbalanced = ends > starts and "MF69_TOOL_RESULT" in tool_first
    doc.evidence["trap69_boundary"] = {
        "path": how, "no_system_empty_header": empty_system,
        "tool_first_open": starts, "tool_first_close": ends,
    }
    if empty_system or unbalanced:
        doc.problem(["69"], "template emits " +
                    ("an unrequested empty system block" if empty_system
                     else "unbalanced role delimiters after a tool-first history"),
                    "audit the template's always-defined system variable "
                    "or tool-first wrapper guard; do not attribute these "
                    "render artifacts to the model",
                    code="TEMPLATE_BOUNDARY_ARTIFACT",
                    asserts=[A("no redundant empty-system or malformed tool boundary",
                               doc.evidence["trap69_boundary"], held=False)])
    else:
        # Entry 69 also contains whitespace artifacts. These two negative
        # checks cannot rule out the whole numbered entry.
        doc.inconclusive(["69"], "template boundary hygiene",
                         "the two inspected boundary signatures were absent; "
                         "the entry also includes whitespace defects which "
                         "this bounded probe cannot adjudicate",
                         code="TEMPLATE_BOUNDARY_NOT_ESTABLISHED",
                         asserts=[A("all three Trap 69 submechanisms were tested",
                                    doc.evidence["trap69_boundary"], held=False)])


def check_thinking_kwarg_type_gate(doc, root, key):
    """Trap 85: llama.cpp template route rejects typed string while bool passes."""
    if doc.stack != "llama.cpp":
        doc.skip(["85"], "enable_thinking kwarg type gate",
                 "Trap 85 documents a llama.cpp-specific argument type gate",
                 code="THINK_TYPE_STACK_NOT_LLAMA",
                 asserts=[A("llama.cpp detected", doc.stack, held=False)])
        return
    tpl = (doc.evidence.get("props") or {}).get("chat_template")
    if not isinstance(tpl, str) or "enable_thinking" in tpl:
        doc.inconclusive(["85"], "enable_thinking kwarg type gate",
                         "the template is unavailable or reads enable_thinking; "
                         "this does not demonstrate rejection of an unused knob",
                         code="THINK_TYPE_TEMPLATE_DEPENDENT",
                         asserts=[A("template demonstrably never reads enable_thinking",
                                    bool(tpl) and "enable_thinking" not in tpl,
                                    held=False)])
        return
    url = root + "/apply-template"
    msgs = [{"role": "user", "content": "MF85 type check"}]
    statuses = {}
    texts = {}
    for name, value in (("boolean", False), ("string", "false")):
        status, body = post(
            url, {"messages": msgs,
                  "chat_template_kwargs": {"enable_thinking": value}},
            key, timeout=30)
        statuses[name], texts[name] = status, body or ""
    doc.evidence["trap85_statuses"] = statuses
    if statuses["boolean"] != 200:
        doc.inconclusive(["85"], "enable_thinking kwarg type gate",
                         "the real-boolean control did not render successfully",
                         code="THINK_TYPE_BOOLEAN_CONTROL_FAILED",
                         asserts=[A("real boolean baseline accepted", statuses,
                                    held=False)])
    elif (statuses["string"] == 400 and
          re.search(r"invalid\s+type.*enable_thinking|enable_thinking.*expected\s+boolean",
                    texts["string"], re.I)):
        doc.problem(["85"], "unused enable_thinking rejects string 'false' "
                    "while the boolean form renders successfully",
                    "normalise client settings to JSON booleans; audit whether "
                    "this particular route's type gate also applies to chat",
                    code="THINK_STRING_TYPE_REJECTED",
                    asserts=[A("unused thinking kwarg string is accepted",
                               statuses, held=False)])
    elif statuses["string"] == 200:
        doc.ok(["85"], "this llama.cpp template-render route accepts both "
               "real-boolean and string-form enable_thinking, ruling out "
               "the specific string-type rejection here (not its runtime effect)",
               code="THINK_STRING_TYPE_ACCEPTED",
               asserts=[A("both kwarg types are accepted by render route", statuses)])
    else:
        doc.inconclusive(["85"], "enable_thinking kwarg type gate",
                         "string-form kwarg failed but the rejection was not "
                         "the expected type-check diagnostic",
                         code="THINK_STRING_REJECTED_OTHER",
                         asserts=[A("rejection attributable to type gate",
                                    statuses, held=False)])


def check_shared_endpoint_contention(doc, root, key):
    """Trap 110: read-only immediate contention screening, not a benchmark."""
    status, body = get(root + "/metrics", key, timeout=8)
    if status != 200:
        doc.skip(["110"], "shared endpoint benchmark interference screen",
                 "Prometheus /metrics unavailable; no interference claim made",
                 code="BENCH_METRICS_UNAVAILABLE",
                 asserts=[A("Prometheus metrics available", status, held=False)])
        return
    series = {}
    for line in (body or "").splitlines():
        if not line or line.startswith("#"):
            continue
        match = re.match(
            r"(?:vllm:)?num_requests_running(?:\{[^}]*\})?\s+"
            r"(-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*$",
            line)
        if match:
            series.setdefault("num_requests_running", []).append(float(match.group(1)))
    if not series:
        doc.inconclusive(["110"], "shared endpoint interference screen",
                         "metrics responded but no compatible running-request "
                         "gauge was present; a generic HTTP 200 is not a measurement",
                         code="BENCH_RUNNING_GAUGE_MISSING",
                         asserts=[A("named running-request gauge recorded",
                                    {"gauge_found": False}, held=False)])
        return
    peak = max(series["num_requests_running"])
    doc.evidence["trap110_running_requests_snapshot"] = peak
    # One snapshot, even zero, does not prove the timed experiment was isolated.
    doc.inconclusive(
        ["110"], "shared endpoint interference screen",
        (f"{peak:g} running request(s) on the endpoint at inspection; "
         "do not start a single-stream benchmark until the lane is idle"
         if peak > 0 else
         "running requests were zero at this snapshot, but a valid timed "
         "benchmark also needs before/after counters for its entire window"),
        code=("BENCH_CONTENDED_AT_SNAPSHOT" if peak > 0
              else "BENCH_SNAPSHOT_IDLE_NOT_PROOF"),
        asserts=[A("entire timed benchmark had no neighbouring work",
                   {"snapshot_running": peak,
                    "time_window_verified": False}, held=False)])



def check_generation_readiness(doc, base, key):
    """Trap 112: authenticated model-list success is not model generation."""
    if not doc.model:
        doc.skip(["112"], "authenticated model readiness",
                 "the model list did not provide a served-model identity",
                 code="READINESS_MODEL_UNKNOWN",
                 asserts=[A("model identity known", None, held=False)])
        return
    st, choice, payload = chat(
        doc, base, key, doc.model,
        [{"role": "user", "content": "MF112 say READY."}], max_tokens=16)
    if st != 200:
        doc.problem(["112"], "model list was available but a bounded "
                    "first-forward generation returned an HTTP/transport failure",
                    "classify HTTP/auth/model-list and generation separately; "
                    "do not report a live wrapper as ready",
                    code="READINESS_GENERATION_FAILED",
                    asserts=[A("bounded first forward returns HTTP 200",
                               {"http_status": st}, held=False)])
        return
    if not isinstance(choice, dict):
        doc.inconclusive(["112"], "authenticated model readiness",
                         "the generation envelope was malformed or missing a choice",
                         code="READINESS_ENVELOPE_UNUSABLE",
                         asserts=[A("response contains a completion choice",
                                    str(payload)[:100], held=False)])
        return
    msg = choice.get("message") or {}
    text = msg.get("content")
    returned_model = payload.get("model") if isinstance(payload, dict) else None
    good = (isinstance(text, str) and bool(text.strip())
            and choice.get("finish_reason") in ("stop", "length")
            and returned_model == doc.model)
    doc.evidence["trap112_readiness"] = {
        "status": st, "expected_model": doc.model,
        "response_model": returned_model,
        "finish_reason": choice.get("finish_reason"),
        "content_present": isinstance(text, str) and bool(text.strip()),
    }
    if good:
        doc.ok(["112"], "authenticated model identity and one bounded "
               "generation are both verified on this lane, not just HTTP liveness",
               code="READINESS_GENERATION_CONFIRMED",
               asserts=[A("expected model generated nonempty content",
                          doc.evidence["trap112_readiness"])])
    else:
        doc.inconclusive(["112"], "authenticated model readiness",
                         "the response did not prove expected-model content "
                         "generation; a 200 alone is not readiness",
                         code="READINESS_GENERATION_UNPROVEN",
                         asserts=[A("expected model completed usable generation",
                                    doc.evidence["trap112_readiness"], held=False)])


def check_toggle_conflict_routing(doc, base, key):
    """Trap 64: a /no_think substring must not move answer to reasoning."""
    if doc.stack not in ("vllm", "sglang"):
        doc.skip(["64"], "thinking-toggle answer-field conflict",
                 "requires a tested template/parser stack; skip generic and "
                 "llama.cpp routes rather than interpreting their field dialect",
                 code="TOGGLE_CONFLICT_STACK_UNSUPPORTED",
                 asserts=[A("supported vLLM/SGLang-like stack",
                            doc.stack, held=False)])
        return
    arms = {}
    for label, suffix in (("baseline", ""), ("conflict", " /no_think")):
        st, choice, raw = chat(
            doc, base, key, doc.model,
            [{"role": "user", "content": "Name the largest planet." + suffix}],
            max_tokens=96, chat_template_kwargs={"enable_thinking": True})
        arms[label] = (st, choice, raw)
    base_st, baseline, _ = arms["baseline"]
    bad_st, conflicted, _ = arms["conflict"]
    if base_st != 200 or not isinstance(baseline, dict):
        doc.skip(["64"], "thinking-toggle answer-field conflict",
                 "a usable baseline response was not obtained",
                 code="TOGGLE_CONFLICT_BASELINE_MISSING",
                 asserts=[A("baseline response usable", base_st, held=False)])
        return
    answer = (baseline.get("message") or {}).get("content") or ""
    if not isinstance(answer, str) or not answer.strip() or bad_st != 200 or not isinstance(conflicted, dict):
        doc.inconclusive(["64"], "thinking-toggle answer-field conflict",
                         "the paired baseline/conflict responses could not be "
                         "compared for answer-field movement",
                         code="TOGGLE_CONFLICT_PAIR_INCOMPLETE",
                         asserts=[A("both responses have usable comparison content",
                                    {"baseline": bool(answer), "conflict_status": bad_st},
                                    held=False)])
        return
    msg = conflicted.get("message") or {}
    content = msg.get("content")
    reasoning = msg.get("reasoning_content") or msg.get("reasoning") or ""
    moved = (conflicted.get("finish_reason") == "stop" and
             not content and isinstance(reasoning, str) and
             answer.strip().casefold() in reasoning.casefold())
    doc.evidence["trap64_field_pair"] = {
        "base_content_present": bool(answer),
        "conflict_content_present": bool(content),
        "conflict_reasoning_present": bool(reasoning),
        "baseline_answer_found_in_reasoning": moved,
    }
    if moved:
        doc.problem(["64"], "baseline answer reappeared only inside the "
                    "reasoning field after the /no_think user-text marker",
                    "treat 200 with null content as a failure for agent clients; "
                    "do not silently score an empty answer",
                    code="TOGGLE_CONFLICT_ANSWER_MOVED",
                    asserts=[A("answer remains in content after text toggle",
                               doc.evidence["trap64_field_pair"], held=False)])
    elif isinstance(content, str) and content.strip():
        doc.ok(["64"], "paired short request retained nonempty assistant "
               "content with and without the text toggle",
               code="TOGGLE_CONFLICT_CONTENT_PRESERVED",
               asserts=[A("both paired response contents nonempty",
                          doc.evidence["trap64_field_pair"])])
    else:
        doc.inconclusive(["64"], "thinking-toggle answer-field conflict",
                         "content was empty but the baseline answer was not "
                         "proven to have moved into the reasoning field",
                         code="TOGGLE_CONFLICT_UNATTRIBUTED_EMPTY",
                         asserts=[A("answer movement attributable to parser/template disagreement",
                                    doc.evidence["trap64_field_pair"], held=False)])


def check_parser_nonempty_rescue(doc, base, key):
    """Trap 65: only test the parser rescue when the baseline actually caps empty."""
    messages = [{"role": "user", "content": "Explain the detailed steps to solve a puzzle."}]
    st, original, _ = chat(
        doc, base, key, doc.model, messages, max_tokens=48,
        chat_template_kwargs={"enable_thinking": True})
    if st != 200 or not isinstance(original, dict):
        doc.skip(["65"], "parser-only force_nonempty_content rescue",
                 "the bounded control request was unavailable",
                 code="PARSER_RESCUE_BASELINE_UNAVAILABLE",
                 asserts=[A("control completion succeeds", st, held=False)])
        return
    msg = original.get("message") or {}
    reason = msg.get("reasoning_content") or msg.get("reasoning") or ""
    if original.get("finish_reason") != "length" or msg.get("content") or not reason:
        doc.inconclusive(["65"], "parser-only force_nonempty_content rescue",
                         "the baseline did not exhibit empty-content-at-cap; "
                         "a second request cannot establish the rescue semantics",
                         code="PARSER_RESCUE_PRECONDITION_ABSENT",
                         asserts=[A("control has empty content and nonempty "
                                    "reasoning at a length cap", False, held=False)])
        return
    st2, rescued, _ = chat(
        doc, base, key, doc.model, messages, max_tokens=48,
        chat_template_kwargs={
            "enable_thinking": True, "force_nonempty_content": True})
    if st2 == 200 and isinstance(rescued, dict):
        m2 = rescued.get("message") or {}
        resc = m2.get("content") or ""
        if (rescued.get("finish_reason") == "length" and
                isinstance(resc, str) and resc.strip()
                and not (m2.get("reasoning_content") or m2.get("reasoning"))):
            doc.problem(["65"], "empty-content-at-cap occurred in the "
                        "control and force_nonempty_content moved text into "
                        "the content field on the matched rescue arm",
                        "this makes truncated reasoning visible but does not "
                        "make it a complete answer or prove the parser source",
                        code="PARSER_RESCUE_OBSERVED",
                        asserts=[A("control does not lose content at cap",
                                   {"control_empty": True, "rescue_content": True},
                                   held=False)])
            return
    doc.inconclusive(["65"], "parser-only force_nonempty_content rescue",
                     "the control capped empty but the rescue arm did not "
                     "establish the described field relocation",
                     code="PARSER_RESCUE_NOT_ESTABLISHED",
                     asserts=[A("rescue arm moves truncated content",
                                {"status": st2}, held=False)])


def check_thinking_json_schema(doc, base, key):
    """Trap 149: paired off/on strict JSON schema with a minimal fixed contract."""
    schema = {"type": "object", "properties": {
                  "answer": {"type": "string", "enum": ["OK"]}},
              "required": ["answer"], "additionalProperties": False}
    fmt = {"type": "json_schema", "json_schema": {
        "name": "minefield_149", "strict": True, "schema": schema}}
    results = {}
    for name, flag in (("off", False), ("on", True)):
        st, choice, payload = chat(
            doc, base, key, doc.model,
            [{"role": "user", "content": "Output JSON with answer exactly OK."}],
            max_tokens=256, response_format=fmt,
            chat_template_kwargs={"enable_thinking": flag})
        results[name] = (st, choice)
    def classify(pair):
        st, choice = pair
        if st != 200 or not isinstance(choice, dict):
            return "unavailable"
        content = (choice.get("message") or {}).get("content")
        try:
            parsed = json.loads(content) if isinstance(content, str) else None
        except (ValueError, TypeError):
            parsed = None
        if (choice.get("finish_reason") == "stop" and
                isinstance(parsed, dict) and parsed == {"answer": "OK"}):
            return "valid_stop"
        if choice.get("finish_reason") == "length" and parsed is None:
            return "invalid_at_cap"
        return "other"
    off = classify(results["off"])
    on = classify(results["on"])
    doc.evidence["trap149_arms"] = {"off": off, "on": on}
    if off != "valid_stop":
        doc.inconclusive(["149"], "thinking-mode strict JSON-schema control",
                         "thinking-off did not establish schema enforcement; "
                         "mode-dependent failure cannot be attributed",
                         code="JSON_SCHEMA_OFF_CONTROL_NOT_VALID",
                         asserts=[A("strict schema off-mode returns valid JSON and stop",
                                    doc.evidence["trap149_arms"], held=False)])
    elif on == "invalid_at_cap":
        doc.problem(["149"], "strict JSON schema passes thinking-off but "
                    "thinking-on emits invalid JSON at the explicit token cap",
                    "gate structured-output mode per serving stack; do not "
                    "infer thinking-on correctness from thinking-off success",
                    code="JSON_SCHEMA_THINKING_ON_RUNAWAY",
                    asserts=[A("matched strict JSON works in both thinking modes",
                               doc.evidence["trap149_arms"], held=False)])
    elif on == "valid_stop":
        doc.ok(["149"], "both thinking-on and thinking-off produced valid "
               "schema-conformant JSON with finish_reason=stop on matched requests",
               code="JSON_SCHEMA_BOTH_MODES_VALID",
               asserts=[A("both strict-schema render modes valid",
                          doc.evidence["trap149_arms"])])
    else:
        doc.inconclusive(["149"], "thinking-mode strict JSON-schema control",
                         "thinking-off passed, but thinking-on was neither a "
                         "valid stop nor the documented invalid-at-cap shape",
                         code="JSON_SCHEMA_ON_OTHER",
                         asserts=[A("thinking-on clean or exact runaway signature",
                                    doc.evidence["trap149_arms"], held=False)])


def check_output_token_accounting(doc, base, root, key):
    """Trap 156: bounded retokenization cross-check, never assume requeue cause."""
    cap = 256
    st, choice, payload = chat(
        doc, base, key, doc.model,
        [{"role": "user", "content":
          "Generate a long numbered list of 100 consecutive integers."}],
        max_tokens=cap)
    if st != 200 or not isinstance(choice, dict) or not isinstance(payload, dict):
        doc.skip(["156"], "completion-token usage consistency",
                 "generation body or usage was not available",
                 code="OUTPUT_ACCOUNTING_RESPONSE_UNAVAILABLE",
                 asserts=[A("completion and usage present", st, held=False)])
        return
    usage = payload.get("usage") or {}
    reported = usage.get("completion_tokens")
    message = choice.get("message") or {}
    text = (message.get("reasoning_content") or message.get("reasoning") or "") + (
        message.get("content") or "")
    if (choice.get("finish_reason") != "length" or
            not isinstance(reported, int) or reported >= cap // 2 or
            not text.strip()):
        doc.inconclusive(["156"], "completion-token usage consistency",
                         "this bounded request did not exhibit the low-count "
                         "at-length precondition for the requeue undercount shape",
                         code="OUTPUT_ACCOUNTING_PRECONDITION_ABSENT",
                         asserts=[A("length-stop plus low reported count",
                                    {"finish": choice.get("finish_reason"),
                                     "reported": reported}, held=False)])
        return
    retok_st, retok_raw = post(
        root + "/tokenize",
        {"model": doc.model, "prompt": text, "return_token_strs": True},
        key, timeout=30)
    try:
        retok = json.loads(retok_raw) if retok_st == 200 else {}
        counted = retok.get("count")
        if not isinstance(counted, int):
            counted = len(retok.get("tokens") or retok.get("token_ids") or [])
    except (TypeError, ValueError):
        counted = None
    doc.evidence["trap156_usage"] = {
        "reported": reported, "retokenized": counted, "cap": cap}
    if counted is not None and counted > max(reported * 2, cap // 2):
        doc.problem(["156"], "returned text retokenizes to far more tokens "
                    "than the API reports after a length stop",
                    "preserve raw text and usage separately; suspected "
                    "requeue accounting must be confirmed in source or a soak",
                    code="OUTPUT_USAGE_UNDERCOUNT_OBSERVED",
                    asserts=[A("reported usage consistent with returned tokens",
                               doc.evidence["trap156_usage"], held=False)])
    else:
        doc.inconclusive(["156"], "completion-token usage consistency",
                         "retokenization was absent or did not establish the "
                         "reported-versus-observed undercount",
                         code="OUTPUT_USAGE_NOT_SETTLED",
                         asserts=[A("retokenization proves the requeue undercount",
                                    doc.evidence["trap156_usage"], held=False)])


def check_post_tool_empty_reasoning_usage(doc, base, key):
    """Trap 158: differentiate empty reasoning markers from actual thought."""
    messages = [
        {"role": "user", "content": "Call a helper then continue."},
        {"role": "assistant", "content": None, "tool_calls": [{
            "id": "callabc12", "type": "function",
            "function": {"name": "lookup", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "callabc12",
         "name": "lookup", "content": "done"},
        {"role": "user", "content": "Reply OK."},
    ]
    st, choice, payload = chat(
        doc, base, key, doc.model, messages, max_tokens=64,
        chat_template_kwargs={"enable_thinking": False})
    if st != 200 or not isinstance(choice, dict) or not isinstance(payload, dict):
        doc.skip(["158"], "empty-thought reasoning-token usage after tools",
                 "post-tool request was not supported on this lane",
                 code="POST_TOOL_REASONING_PROBE_UNAVAILABLE",
                 asserts=[A("post-tool reply returned usable envelope",
                            st, held=False)])
        return
    usage = payload.get("usage") or {}
    count = (usage.get("completion_tokens_details") or {}).get("reasoning_tokens")
    if count is None:
        count = (usage.get("output_tokens_details") or {}).get("reasoning_tokens")
    msg = choice.get("message") or {}
    reason = msg.get("reasoning_content") or msg.get("reasoning") or ""
    doc.evidence["trap158_post_tool"] = {
        "reasoning_tokens": count,
        "reasoning_text_present": bool(reason)}
    if count == 2 and not reason:
        doc.problem(["158"], "thinking-off post-tool response reports exactly "
                    "two reasoning tokens while its reasoning text is empty",
                    "check raw thought markers before treating nonzero token "
                    "count as substantive reasoning; this observation alone "
                    "does not prove which two token IDs were emitted",
                    code="POST_TOOL_EMPTY_REASONING_TWO_TOKENS",
                    asserts=[A("thinking-off empty reasoning reports zero tokens",
                               doc.evidence["trap158_post_tool"], held=False)])
    else:
        doc.inconclusive(["158"], "empty-thought reasoning-token usage after tools",
                         "no exact two-token/empty-text mismatch on this single "
                         "tool-turn sample; lack of counters or one negative "
                         "sample cannot refute a probabilistic template branch",
                         code="POST_TOOL_REASONING_NOT_SETTLED",
                         asserts=[A("post-tool template branch characterized",
                                    doc.evidence["trap158_post_tool"], held=False)])



def check_tool_schema_render(doc, root, key):
    """Trap 24: detect schema fields silently omitted by the served template."""
    fields = ("mf24_alpha_781", "mf24_beta_614")
    tool = {"type": "function", "function": {"name": "mf24_lookup_429",
            "description": "Probe whether tool schemas survive prompt assembly",
            "parameters": {"type": "object", "properties": {
                fields[0]: {"type": "string"}, fields[1]: {"type": "integer"}},
                "required": [fields[0]]}}}
    message = [{"role": "user", "content": "MF24 query"}]
    ctrl, how = render_paths(doc, root, key, message, {}, tools=[])
    text, how2 = render_paths(doc, root, key, message, {}, tools=[tool])
    if not isinstance(text, str) or not isinstance(ctrl, str) or "MF24 query" not in text:
        doc.skip(["24"], "served tool-schema render",
                 "tool-defined and empty-tool rendered controls are unavailable",
                 code="TOOL_SCHEMA_RENDER_UNAVAILABLE",
                 asserts=[A("two server renders available", {"control": ctrl is not None,
                          "with_tool": text is not None}, held=False)])
        return
    seen = {x: x in text for x in (tool["function"]["name"],) + fields}
    doc.evidence["trap24_schema_seen"] = seen
    # Only the actual server render supports a claim about runtime Jinja behavior.
    if all(seen.values()):
        doc.inconclusive(["24"], "tool-schema Jinja portability",
                         "all distinctive schema strings survived the served "
                         "render, but Python versus C++ reference parity and "
                         "parameter delimiters were not established",
                         code="TOOL_SCHEMA_FIELDS_PRESERVED_NOT_PARITY",
                         asserts=[A("server and reference Python-Jinja render compared",
                                    {"server_path": how2}, held=False)])
    elif how2 and how2.startswith("server") and tool["function"]["name"] not in ctrl:
        doc.problem(["24"], "served template omitted a named function or "
                    "parameter key from the supplied tool schema",
                    "compare this runtime's assembled prompt with a pinned "
                    "Python-Jinja reference before swapping templates",
                    code="TOOL_SCHEMA_FIELD_DROPPED",
                    asserts=[A("all named tool schema fields survive render",
                               seen, held=False)])
    else:
        doc.inconclusive(["24"], "tool-schema Jinja portability",
                         "missing keys were not tied to an authenticated server "
                         "render with a discriminating no-tools control",
                         code="TOOL_SCHEMA_COMPARISON_UNCERTAIN",
                         asserts=[A("server path and controls establish omission",
                                    seen, held=False)])


def check_python_encoder_role_welding(doc, root, key):
    """Trap 56: compare inline-system rendering against a marked leading control."""
    q, q2, late, early = ("MF56_Q_12", "MF56_Q2_12",
                          "MF56_LATE_12", "MF56_HEAD_12")
    arms = {}
    for name, msgs in (
        ("plain", [{"role": "user", "content": q}, {"role": "user", "content": q2}]),
        ("head", [{"role": "system", "content": early}, {"role": "user", "content": q}]),
        ("late", [{"role": "user", "content": q}, {"role": "system", "content": late},
                  {"role": "user", "content": q2}]),
    ):
        rendered, how = render_paths(doc, root, key, msgs, {})
        arms[name] = rendered
        if rendered is not None:
            doc.evidence.setdefault("trap56_render_path", how)
    if any(not isinstance(x, str) for x in arms.values()) or (
            q not in arms["late"] or q2 not in arms["late"] or early not in arms["head"]):
        doc.skip(["56"], "Python-encoder system-role boundary",
                 "leading and inline role controls failed to render with markers",
                 code="ENCODER_ROLE_CONTROLS_UNAVAILABLE",
                 asserts=[A("all render arms preserve markers",
                            {k: v is not None for k, v in arms.items()}, held=False)])
        return
    glued = q + late in arms["late"]
    doc.evidence["trap56_late_system_glued"] = glued
    if glued and arms["plain"].count(q) == 1:
        doc.problem(["56"], "inline system text is concatenated immediately "
                    "after a user marker with no structural role separator",
                    "inspect the checkpoint-specific encoder and compare its "
                    "pinned implementation with the server's actual render",
                    code="ENCODER_INLINE_SYSTEM_WELDED",
                    asserts=[A("inline system retains an independent boundary",
                               {"concatenated": glued}, held=False)])
    else:
        doc.inconclusive(["56"], "Python-encoder template provenance",
                         "the direct welding signature was absent; the live "
                         "render alone cannot establish whether a checkpoint "
                         "ships Jinja template data or a Python encoder",
                         code="ENCODER_PROVENANCE_UNVERIFIED",
                         asserts=[A("checkpoint template absence and Python "
                                    "encoder source were independently inspected",
                                    {"late_glued": glued}, held=False)])


def check_reasoning_replay_visibility(doc, root, key):
    """Trap 59: verify replayed reasoning is visible before trusting recollection."""
    marker = "MF59_PRIVATE_TRACE_8B7"
    msgs = [
        {"role": "user", "content": "MF59 first user"},
        {"role": "assistant", "content": "MF59 first answer",
         "reasoning_content": marker, "reasoning": marker},
        {"role": "user", "content": "MF59 second user"},
    ]
    real, how = render_paths(doc, root, key, msgs, {})
    plain = [dict(x) for x in msgs]
    plain[1]["content"] = marker
    plain[1].pop("reasoning", None)
    plain[1].pop("reasoning_content", None)
    ctrl, _ = render_paths(doc, root, key, plain, {})
    if not isinstance(real, str) or not isinstance(ctrl, str) or marker not in ctrl:
        doc.skip(["59"], "replayed reasoning visibility",
                 "server/template render or positive content-marker control unavailable",
                 code="REPLAY_REASONING_CONTROL_UNAVAILABLE",
                 asserts=[A("content marker visible in render control",
                            {"render": real is not None, "control": ctrl is not None,
                             "visible": bool(ctrl and marker in ctrl)}, held=False)])
        return
    doc.evidence["trap59_reasoning_visible"] = marker in real
    if marker not in real:
        doc.inconclusive(["59"], "prior-turn reasoning not in assembled prompt",
                         "distinctive replayed reasoning disappeared while identical "
                         "text supplied as content survived; a model's later "
                         "claim to remember it would require a separate witness",
                         code="REPLAY_REASONING_STRIPPED_NOT_CONFABULATION_PROOF",
                         asserts=[A("replayed reasoning visible to model", False,
                                    held=False)])
    else:
        doc.inconclusive(["59"], "replayed reasoning present in prompt",
                         "the marker reached the prompt on this history field "
                         "shape, but the separate confabulated-recall mechanism "
                         "cannot be cleared from one render",
                         code="REPLAY_REASONING_VISIBLE_NOT_GENERAL",
                         asserts=[A("every reasoning field and reply-claim shape tested",
                                    False, held=False)])


def check_clock_prompt_prefix(doc, root, key):
    """Trap 93: compare relative positions, not infer actual cached tokens."""
    clock = "MF93_CLOCK_01"
    system = "MF93_SYS_START_" + clock
    m1 = [{"role": "system", "content": system},
          {"role": "user", "content": "MF93_U1"}]
    m2 = m1 + [{"role": "assistant", "content": "MF93_A1"},
               {"role": "user", "content": "MF93_U2"}]
    a, how = render_paths(doc, root, key, m1, {})
    b, _ = render_paths(doc, root, key, m2, {})
    if not isinstance(a, str) or not isinstance(b, str) or (
            a.count(clock) != 1 or b.count(clock) != 1):
        doc.skip(["93"], "clock placement and prefix stability",
                 "two marked complete renders are required",
                 code="CLOCK_PREFIX_RENDER_UNAVAILABLE",
                 asserts=[A("clock marker appears in both renders",
                            {"first": bool(a and clock in a),
                             "second": bool(b and clock in b)}, held=False)])
        return
    pos1 = a.index(clock); pos2 = b.index(clock)
    prefix = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y),
                  min(len(a), len(b)))
    doc.evidence["trap93_structure"] = {
        "first_clock_offset": pos1, "second_clock_offset": pos2,
        "shared_prefix_characters": prefix}
    doc.inconclusive(["93"], "clock-prefix caching experiment",
                     "rendered clock marker "
                     + ("moved after growing history; " if pos2 > pos1 else
                        "did not move after growing history; ")
                     + "the observed prefix is structural, not measured "
                     "cached_tokens under controlled fresh-server arms",
                     code="CLOCK_PREFIX_STRUCTURAL_OBSERVATION",
                     asserts=[A("controlled cache metrics and restart arms recorded",
                                doc.evidence["trap93_structure"], held=False)])


def check_ling_thinking_field_placement(doc, base, key):
    """Trap 126: scope to a positively named Ling checkpoint."""
    if "ling" not in (doc.model or "").lower():
        doc.skip(["126"], "Ling free-text versus schema thinking switch",
                 "served model is not identified as Ling",
                 code="LING_MODEL_NOT_IDENTIFIED",
                 asserts=[A("Ling model identity", doc.model, held=False)])
        return
    arms = {}
    for label, flag in (("on", True), ("off", False)):
        st, choice, raw = chat(doc, base, key, doc.model,
            [{"role": "user", "content": "Respond briefly with OK."}],
            max_tokens=96, chat_template_kwargs={"thinking": flag})
        arms[label] = (st, choice, raw)
    if any(v[0] != 200 or not isinstance(v[1], dict) for v in arms.values()):
        doc.inconclusive(["126"], "Ling thinking free-text gate",
                         "one or both matched requests could not be read",
                         code="LING_THINKING_PAIR_INCOMPLETE",
                         asserts=[A("both thinking arms completed",
                                    {k:v[0] for k,v in arms.items()}, held=False)])
        return
    on = arms["on"][1].get("message") or {}
    off = arms["off"][1].get("message") or {}
    on_reason = on.get("reasoning_content") or on.get("reasoning") or ""
    off_text = off.get("content") or ""
    bad = bool(on_reason and "</think>" in off_text)
    doc.evidence["trap126_pair"] = {
        "on_reasoning": bool(on_reason), "off_close_tag": "</think>" in off_text}
    if bad:
        doc.problem(["126"], "Ling thinking:false free-text response contains "
                    "a visible closing reasoning delimiter while the thinking-on "
                    "control uses a separate reasoning field",
                    "run a matched structured-output pair before inferring "
                    "the switch's shape dependence or token-cost advantage",
                    code="LING_OFF_REASONING_LEAKED",
                    asserts=[A("thinking-off content lacks reasoning delimiter",
                               doc.evidence["trap126_pair"], held=False)])
    else:
        doc.inconclusive(["126"], "Ling thinking:false free-text",
                         "the paired free-text responses do not establish "
                         "the specific field-placement defect; structured-JSON "
                         "and repeated token-cost controls remain required",
                         code="LING_THINKING_NOT_CHARACTERIZED",
                         asserts=[A("all schema and cost control arms measured",
                                    doc.evidence["trap126_pair"], held=False)])


def check_structured_json_duplication(doc, base, key):
    """Trap 138: observe structured-output malformedness, not infer n-gram cause."""
    fmt = {"type": "json_object"}
    st, choice, raw = chat(doc, base, key, doc.model,
        [{"role": "user", "content": "Return a JSON object with key answer value OK."}],
        response_format=fmt, max_tokens=128)
    if st != 200 or not isinstance(choice, dict):
        doc.skip(["138"], "n-gram structured-output duplication screen",
                 "JSON-object request unavailable or unsupported",
                 code="NGRAM_JSON_REQUEST_UNAVAILABLE",
                 asserts=[A("JSON-object completion available", st, held=False)])
        return
    c = (choice.get("message") or {}).get("content") or ""
    try:
        json.loads(c)
        parse_ok = True
    except (ValueError, TypeError):
        parse_ok = False
    doc.evidence["trap138_json_parse_ok"] = parse_ok
    doc.inconclusive(["138"], "n-gram speculative structured output",
                     ("response content was not valid JSON; n-gram ownership "
                      "requires a matched spec-on/spec-off serve comparison"
                      if not parse_ok else
                      "the short structured response parsed; this does not "
                      "test whether n-gram speculation duplicates tokens "
                      "under the affected serve configuration"),
                     code=("NGRAM_JSON_MALFORMED_UNATTRIBUTED" if not parse_ok
                           else "NGRAM_JSON_SHORT_CONTROL_ONLY"),
                     asserts=[A("speculation-on/off controlled comparison completed",
                                {"json_valid": parse_ok}, held=False)])


def check_unicode_tool_serialization(doc, root, key):
    """Trap 148: classify live engine Unicode escaping without pretending a cross-engine A/B."""
    symbol = "\u03a9\u4e2d\u00e9"
    field = "mf148_param_6C"
    schema = {"type": "function", "function": {"name": "mf148_tool_6C",
        "description": "Lookup " + symbol,
        "parameters": {"type": "object", "properties": {field: {
            "type": "string", "description": "Text " + symbol}},
            "required": [field]}}}
    msgs = [{"role": "user", "content": "MF148 normal ASCII user marker"}]
    control, how = render_paths(doc, root, key, msgs, {}, tools=[])
    target, source = render_paths(doc, root, key, msgs, {}, tools=[schema])
    if not isinstance(target, str) or not isinstance(control, str) or (
            "mf148_tool_6C" not in target):
        doc.skip(["148"], "cross-engine Unicode tool serialization",
                 "live tool schema render unavailable or missing function-name control",
                 code="UNICODE_TOOL_SCHEMA_UNAVAILABLE",
                 asserts=[A("tool schema serialized on live render path",
                            {"target": target is not None, "source": source},
                            held=False)])
        return
    raw = symbol in target
    escaped = ("\\u03a9" in target or "\\u4e2d" in target or "\\u00e9" in target)
    doc.evidence["trap148_serialization"] = {
        "raw_utf8": raw, "unicode_escape": escaped, "server_path": source}
    doc.inconclusive(["148"], "engine-dependent tool JSON escaping",
                     ("this lane renders raw Unicode; " if raw else
                      "this lane renders escapes or another encoding; ")
                     + "a second pinned engine and tokenizer are required "
                     "to establish cross-engine token cost divergence",
                     code="UNICODE_TOOL_SERIALIZATION_OBSERVED",
                     asserts=[A("two pinned engine token sequences compared",
                                doc.evidence["trap148_serialization"], held=False)])



def check_declared_server_token_cap(doc, base, args):
    """Trap 32: test a caller-declared server default/cap, never infer the launch flag."""
    stated = getattr(args, "server_max_tokens", None)
    if not isinstance(stated, int) or stated < 1 or stated >= 256:
        doc.skip(["32"], "declared server max-tokens cap",
                 "pass --server-max-tokens 1..255 to test a known launch-time "
                 "setting; no default/cap is inferred from the model list",
                 code="SERVER_MAX_TOKENS_UNDECLARED",
                 asserts=[A("declared server max_tokens available",
                            stated, held=False)])
        return
    ask = stated + 16
    st, choice, payload = chat(doc, base, args.api_key, doc.model,
        [{"role": "user", "content":
          "Continue this numbered sequence past 100 items. Do not summarize."}],
        max_tokens=ask)
    usage = payload.get("usage") if isinstance(payload, dict) else None
    observed = usage.get("completion_tokens") if isinstance(usage, dict) else None
    doc.evidence["trap32_cap"] = {"declared": stated, "requested": ask,
                                  "completion_tokens": observed, "status": st}
    if st == 200 and isinstance(observed, int) and observed > stated:
        doc.problem(["32"], "request generated more completion tokens "
                    "than the operator-declared serving flag",
                    "the server setting is a default, not an enforced limit "
                    "on the user-supplied max_tokens request",
                    code="SERVER_FLAG_NOT_HARD_CAP",
                    asserts=[A("server enforces declared output token cap",
                               doc.evidence["trap32_cap"], held=False)])
    else:
        doc.inconclusive(["32"], "server output budget semantics",
                         "response did not exceed the declared cap; a naturally "
                         "short completion or rejected request does not prove "
                         "the server flag is a hard cap",
                         code="SERVER_CAP_NOT_SETTLED",
                         asserts=[A("response demonstrates hard-cap enforcement",
                                    doc.evidence["trap32_cap"], held=False)])


def check_thinking_budget_marker_ids(doc, root, args):
    """Trap 153: compare user-supplied processor marker IDs against live tokenizer."""
    configured = getattr(args, "thinking_budget_marker_ids", None)
    if not configured:
        doc.skip(["153"], "thinking-budget tokenizer marker IDs",
                 "pass --thinking-budget-marker-ids START,END from the "
                 "actual installed budget processor, otherwise no contract "
                 "exists to compare",
                 code="THINK_BUDGET_IDS_UNDECLARED",
                 asserts=[A("processor marker ids supplied",
                            configured, held=False)])
        return
    try:
        expected = [int(x.strip()) for x in configured.split(",")]
        if len(expected) != 2:
            raise ValueError("expected two IDs")
    except (ValueError, AttributeError):
        doc.skip(["153"], "thinking-budget tokenizer marker IDs",
                 "marker ids must be two comma-separated integers",
                 code="THINK_BUDGET_IDS_INVALID",
                 asserts=[A("two integer marker ids", configured, held=False)])
        return
    seen = []
    for marker in ("<think>", "</think>"):
        st, body = post(root + "/tokenize", {"model": doc.model,
            "prompt": marker, "add_special_tokens": False}, args.api_key,
            timeout=20)
        try:
            data = json.loads(body) if st == 200 else {}
            ids = data.get("tokens", data.get("token_ids"))
        except (TypeError, ValueError):
            ids = None
        seen.append(ids if isinstance(ids, list) and
                    all(isinstance(v, int) for v in ids) else None)
    doc.evidence["trap153_ids"] = {"expected": expected, "tokenized": seen}
    if any(ids is None or len(ids) != 1 for ids in seen):
        doc.skip(["153"], "thinking-budget tokenizer marker IDs",
                 "tokenization did not return one unambiguous token ID "
                 "for each marker",
                 code="THINK_BUDGET_TOKENIZER_UNAVAILABLE",
                 asserts=[A("single-token marker ids returned",
                            doc.evidence["trap153_ids"], held=False)])
    elif [ids[0] for ids in seen] != expected:
        doc.problem(["153"], "processor marker IDs disagree with this "
                    "endpoint's tokenizer IDs for thinking delimiters",
                    "derive marker IDs from the checkpoint tokenizer, not "
                    "from a different model family",
                    code="THINK_BUDGET_MARKER_ID_MISMATCH",
                    asserts=[A("installed processor IDs equal live tokenizer IDs",
                               doc.evidence["trap153_ids"], held=False)])
    else:
        doc.inconclusive(["153"], "thinking-budget processor correctness",
                         "two configured marker IDs match the live tokenizer; "
                         "processor counting across current turns and histories "
                         "was not demonstrated",
                         code="THINK_BUDGET_IDS_MATCH_NOT_EFFECT",
                         asserts=[A("budget processor behavioral effect verified",
                                    doc.evidence["trap153_ids"], held=False)])


def check_prefix_slot_residency(doc, base, key):
    """Trap 155: short, bounded prefix-residency screen, not a long-context soak."""
    requests = (
        [{"role": "system", "content": "MF155_SHARED_SYSTEM"},
         {"role": "user", "content": "MF155 A1"}],
        [{"role": "system", "content": "MF155_SHARED_SYSTEM"},
         {"role": "user", "content": "MF155 B1"}],
        [{"role": "system", "content": "MF155_SHARED_SYSTEM"},
         {"role": "user", "content": "MF155 A1"},
         {"role": "assistant", "content": "MF155 previous answer"},
         {"role": "user", "content": "MF155 A2"}],
    )
    values = []
    for msgs in requests:
        st, choice, payload = chat(doc, base, key, doc.model, msgs,
                                   max_tokens=16)
        usage = payload.get("usage") if isinstance(payload, dict) else {}
        details = usage.get("prompt_tokens_details") or {}
        cached = details.get("cached_tokens") if isinstance(details, dict) else None
        if cached is None:
            cached = usage.get("cached_tokens", usage.get("cache_n"))
        values.append({"status": st, "cached_tokens": cached,
                       "prompt_tokens": usage.get("prompt_tokens")})
    doc.evidence["trap155_cache_sequence"] = values
    if any(row["status"] != 200 for row in values) or any(
            not isinstance(row["cached_tokens"], int) for row in values):
        doc.skip(["155"], "long-conversation slot retention",
                 "short cache-control requests or per-request cached-token "
                 "counters are unavailable on this endpoint",
                 code="PREFIX_SLOT_COUNTERS_MISSING",
                 asserts=[A("three cached-token counters available",
                            values, held=False)])
        return
    doc.inconclusive(["155"], "long-conversation slot retention",
                     "three short sequential histories recorded cached-token "
                     "values; a repeated long two-conversation test plus slot "
                     "residency evidence is needed before diagnosing victim-policy thrash",
                     code="PREFIX_SLOT_SHORT_SEQUENCE_ONLY",
                     asserts=[A("long-conversation retention/eviction mechanism verified",
                                values, held=False)])


def check_ngram_async_scheduling(doc, root, key):
    """Trap 157: inspect advertised scheduling flags, never infer throughput."""
    st, raw = get(root + "/props", key, timeout=8)
    if st != 200:
        doc.skip(["157"], "n-gram speculation and asynchronous scheduling",
                 "serving config is not exposed via /props",
                 code="NGRAM_SCHED_CONFIG_UNAVAILABLE",
                 asserts=[A("serving config readable", st, held=False)])
        return
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        data = {}
    config = data.get("speculative_config") or {}
    sched = data.get("scheduler_config") or {}
    if not isinstance(config, dict):
        config = {}
    if not isinstance(sched, dict):
        sched = {}
    kind = str(config.get("method", config.get("type", ""))).lower()
    active = bool(kind == "ngram" or config.get("ngram_prompt_lookup_max"))
    async_flag = sched.get("async_scheduling")
    doc.evidence["trap157_config"] = {
        "ngram_speculation": active, "async_scheduling": async_flag}
    if not active or not isinstance(async_flag, bool):
        doc.skip(["157"], "n-gram speculation and asynchronous scheduling",
                 "no positively identified n-gram config together with "
                 "explicit async-scheduling boolean was exposed",
                 code="NGRAM_SCHED_FLAGS_NOT_CONFIRMED",
                 asserts=[A("both speculation and async fields available",
                            doc.evidence["trap157_config"], held=False)])
        return
    doc.inconclusive(["157"], "n-gram speculation versus async scheduling",
                     ("ngram speculation is configured with async scheduling off"
                      if not async_flag else
                      "ngram speculation is configured with async scheduling on")
                     + "; throughput impact needs matched on/off arms at "
                     "production concurrency",
                     code="NGRAM_ASYNC_CONFIG_OBSERVED",
                     asserts=[A("matched C1/C4 completed-work throughput compared",
                                doc.evidence["trap157_config"], held=False)])



def check_prompt_target_tokens(doc, root, key, args):
    """Trap 49: assert an operator-provided exact benchmark prompt token count."""
    target = getattr(args, "benchmark_target_tokens", None)
    prompt = getattr(args, "benchmark_prompt_text", None)
    if not isinstance(target, int) or target < 1 or not isinstance(prompt, str) or not prompt:
        doc.skip(["49"], "benchmark prompt target token count",
                 "pass --benchmark-target-tokens and --benchmark-prompt-text "
                 "to check the actual prompt; no synthetic prompt stands in "
                 "for the operator's benchmark",
                 code="PROMPT_TARGET_UNDECLARED",
                 asserts=[A("both target token count and benchmark text supplied",
                            {"target": target, "text_supplied": bool(prompt)}, held=False)])
        return
    if len(prompt) > 8192:
        doc.skip(["49"], "benchmark prompt target token count",
                 "inline text exceeds the conservative 8192-character probe limit",
                 code="PROMPT_TARGET_TOO_LARGE",
                 asserts=[A("prompt length within bounded request",
                            {"chars": len(prompt)}, held=False)])
        return
    st, body = post(root + "/tokenize", {
        "model": doc.model, "messages": [{"role": "user", "content": prompt}],
        "add_generation_prompt": True}, key, timeout=20)
    try:
        data = json.loads(body) if st == 200 else {}
        count = data.get("count")
    except (TypeError, ValueError):
        count = None
    if not isinstance(count, int) or count < 1:
        doc.skip(["49"], "benchmark prompt target token count",
                 "this endpoint did not return an authoritative token count",
                 code="PROMPT_TOKEN_COUNT_UNAVAILABLE",
                 asserts=[A("tokenizer returned an integer count",
                            {"status": st, "count": count}, held=False)])
        return
    drift = abs(count - target) / target
    doc.evidence["trap49_count"] = {"target": target, "observed": count,
                                   "relative_error": round(drift, 4)}
    if drift > 0.02:
        doc.problem(["49"], "served tokenization differs by more than 2% "
                    "from the operator's declared benchmark target",
                    "construct and label benchmark rows using the served "
                    "tokenizer's actual prompt count, not text length",
                    code="PROMPT_TARGET_TOKEN_MISMATCH",
                    asserts=[A("served token count agrees with benchmark target",
                               doc.evidence["trap49_count"], held=False)])
    else:
        doc.inconclusive(["49"], "declared benchmark token target checked",
                         "the supplied text tokenizes within 2% of its target "
                         "on this route; the actual benchmark row and cache "
                         "accounting were not independently checked",
                         code="PROMPT_TARGET_TOKENIZER_ONLY",
                         asserts=[A("benchmark's executed prompt and cache "
                                    "accounting independently verified",
                                    doc.evidence["trap49_count"], held=False)])


def _reported_cached_tokens(payload):
    usage = payload.get("usage") if isinstance(payload, dict) else {}
    usage = usage if isinstance(usage, dict) else {}
    details = usage.get("prompt_tokens_details") or {}
    details = details if isinstance(details, dict) else {}
    value = details.get("cached_tokens")
    return value if isinstance(value, int) else usage.get("cached_tokens", usage.get("cache_n"))


def check_cache_hit_answer_consistency(doc, base, key):
    """Trap 60: a same-payload pair can expose cache-correlated divergence."""
    prompt = ("MF60 fact: The access code is GARNET. " * 35 +
              "What is the access code? Respond with the one word only.")
    observations = []
    for _ in range(2):
        st, choice, raw = chat(doc, base, key, doc.model,
            [{"role": "user", "content": prompt}],
            max_tokens=24, seed=42)
        observations.append((st, choice, raw))
    if any(st != 200 or not isinstance(choice, dict)
           for st, choice, _ in observations):
        doc.skip(["60"], "cold-versus-warm identical prompt",
                 "two usable completions are required",
                 code="CACHE_PAIR_UNAVAILABLE",
                 asserts=[A("two identical requests returned choices",
                            [st for st, _, _ in observations], held=False)])
        return
    signatures = [((choice.get("message") or {}).get("content"),
                   choice.get("finish_reason"))
                  for _, choice, _ in observations]
    cached = [_reported_cached_tokens(raw) for _, _, raw in observations]
    doc.evidence["trap60_pair"] = {"cache_tokens": cached,
                                   "output_equal": signatures[0] == signatures[1]}
    if (all(isinstance(x, int) for x in cached) and
            cached[0] <= 5 and cached[1] >= 16 and
            signatures[0] != signatures[1]):
        doc.problem(["60"], "byte-identical greedy seeded prompt returned "
                    "different outputs across a reported cold/cache-hit pair",
                    "record concurrency and cache/slot state before attributing "
                    "the difference to prefix-cache reuse alone",
                    code="CACHE_CORRELATED_OUTPUT_DIVERGENCE",
                    asserts=[A("cold and warm equivalent request outputs agree",
                               doc.evidence["trap60_pair"], held=False)])
    else:
        doc.inconclusive(["60"], "cold/cache-hit response equivalence",
                         "the pair did not show both a verified cold-to-warm "
                         "cache transition and output divergence; a matched "
                         "controlled cache experiment was not established",
                         code="CACHE_PAIR_NOT_DISCRIMINATING",
                         asserts=[A("cold/warm equivalence characterized with "
                                    "positive cache evidence",
                                    doc.evidence["trap60_pair"], held=False)])


def check_greedy_repetition_screen(doc, base, key):
    """Trap 91: serial temperature-zero observations cannot certify C>=2."""
    prompt = ("MF91 concurrency repeatability probe. " * 25 +
              "Reply with the name of the sixth month of the year.")
    output = []
    for _ in range(2):
        st, choice, _ = chat(doc, base, key, doc.model,
            [{"role": "user", "content": prompt}],
            max_tokens=24, seed=7, cache_prompt=False)
        if st != 200 or not isinstance(choice, dict):
            doc.skip(["91"], "single-stream greedy repeatability",
                     "one or both bounded responses failed",
                     code="GREEDY_REPEAT_CONTROL_UNAVAILABLE",
                     asserts=[A("two repeats succeeded", st, held=False)])
            return
        output.append(((choice.get("message") or {}).get("content"),
                       choice.get("finish_reason")))
    doc.evidence["trap91_pair_equal"] = output[0] == output[1]
    doc.inconclusive(["91"], "concurrency-dependent greedy divergence",
                     ("even serial greedy replies differed; "
                      if output[0] != output[1] else
                      "two serial greedy replies matched; ")
                     + "a C1-versus-C2/C4 controlled long-prompt grid "
                     "is required to identify concurrency as the mechanism",
                     code="GREEDY_SERIAL_SCREEN_ONLY",
                     asserts=[A("concurrent batched repeatability measured",
                                {"pair_equal": output[0] == output[1]}, held=False)])


def check_device_memory_reporting(doc, root, key):
    """Trap 96: inspect a populated server device-info surface only."""
    st, raw = get(root + "/props", key, timeout=8)
    try:
        data = json.loads(raw) if st == 200 else {}
    except (TypeError, ValueError):
        data = {}
    devices = data.get("devices") if isinstance(data, dict) else None
    if not isinstance(devices, list) or not devices:
        doc.skip(["96"], "device listing memory arithmetic",
                 "server does not expose a per-device total/free listing",
                 code="DEVICE_LIST_UNAVAILABLE",
                 asserts=[A("live device total/free pairs provided", False,
                            held=False)])
        return
    pairs = []
    for row in devices[:16]:
        if not isinstance(row, dict):
            continue
        total = row.get("total_memory_mib")
        free = row.get("free_memory_mib")
        if isinstance(total, (int, float)) and isinstance(free, (int, float)):
            pairs.append({"total_mib": total, "free_mib": free})
    if not pairs:
        doc.skip(["96"], "device listing memory arithmetic",
                 "device entries contain no comparable total/free MiB fields",
                 code="DEVICE_MEMORY_UNAVAILABLE",
                 asserts=[A("per-device comparable counters present", False,
                            held=False)])
        return
    doc.evidence["trap96_pairs"] = pairs
    if any(p["free_mib"] > p["total_mib"] for p in pairs):
        doc.problem(["96"], "server device listing reports free memory above "
                    "the same device's own total memory",
                    "verify allocation capacity with authoritative GPU accounting; "
                    "do not size based on the contradicted device banner",
                    code="DEVICE_FREE_EXCEEDS_TOTAL",
                    asserts=[A("listed device free memory does not exceed total",
                               pairs, held=False)])
    else:
        doc.inconclusive(["96"], "device listing memory correctness",
                         "no internally contradictory free/total values were "
                         "seen, but independent GPU-memory accounting was absent",
                         code="DEVICE_MEMORY_NEEDS_EXTERNAL_REFERENCE",
                         asserts=[A("server listing independently reconciled "
                                    "with GPU accounting", pairs, held=False)])


def _parse_metric_values(raw, name):
    """Parse only exact Prometheus gauge names, never similarly named variants."""
    result = []
    for line in (raw or "").splitlines():
        if not line or line.startswith("#"):
            continue
        match = re.match(r"(?:vllm:)?" + re.escape(name) +
                         r"(?:\{[^}]*\})?\s+"
                         r"(-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)"
                         r"(?:\s+\S+)?$", line)
        if match:
            try:
                result.append(float(match.group(1)))
            except ValueError:
                pass
    return result


def check_kv_cache_pressure(doc, root, key):
    """Trap 106: a pressure snapshot is not proof of a leak or a plateau."""
    st, raw = get(root + "/metrics", key, timeout=8)
    kv = _parse_metric_values(raw, "kv_cache_usage_perc") if st == 200 else []
    pre = _parse_metric_values(raw, "num_preemptions_total") if st == 200 else []
    waiting = _parse_metric_values(raw, "num_requests_waiting") if st == 200 else []
    if not kv or not pre:
        doc.skip(["106"], "KV-cache occupancy and preemption pressure",
                 "occupancy and preemption metrics are both required",
                 code="KV_PRESSURE_METRICS_UNAVAILABLE",
                 asserts=[A("occupancy plus pressure gauge present",
                            {"kv": bool(kv), "preemptions": bool(pre)},
                            held=False)])
        return
    info = {"occupancy": max(kv), "preemptions_total": sum(pre),
            "waiting": sum(waiting) if waiting else None}
    doc.evidence["trap106_snapshot"] = info
    doc.inconclusive(["106"], "KV-cache leak versus stable occupancy",
                     "snapshot occupancy is not a leak claim; use repeated "
                     "request-count intervals and preemption DELTAS to "
                     "distinguish stable cache use from pressure",
                     code="KV_PRESSURE_SNAPSHOT_ONLY",
                     asserts=[A("occupancy curve and preemption deltas observed",
                                info, held=False)])


def check_compilation_flag_resolution(doc, root, key):
    """Trap 117: explicit requested/resolved fuse flag contradiction."""
    st, raw = get(root + "/props", key, timeout=8)
    try:
        obj = json.loads(raw) if st == 200 else {}
    except (TypeError, ValueError):
        obj = {}
    requested = obj.get("requested_compilation_config") if isinstance(obj, dict) else None
    resolved = obj.get("resolved_compilation_config") if isinstance(obj, dict) else None
    if not isinstance(requested, dict) or not isinstance(resolved, dict):
        doc.skip(["117"], "requested versus resolved compilation settings",
                 "both requested and resolved compilation configs must be exposed",
                 code="COMPILATION_CONFIG_PAIR_UNAVAILABLE",
                 asserts=[A("requested and resolved configs readable",
                            {"requested": isinstance(requested, dict),
                             "resolved": isinstance(resolved, dict)}, held=False)])
        return
    a = (requested.get("pass_config") or {}).get("fuse_gemm_comms")
    b = (resolved.get("pass_config") or {}).get("fuse_gemm_comms")
    doc.evidence["trap117_flags"] = {"requested": a, "resolved": b}
    if a is True and b is False:
        doc.problem(["117"], "fuse_gemm_comms explicitly requested true but "
                    "the engine's resolved pass config disables it",
                    "do not attribute speed to an echoed request flag; "
                    "record the effective pass configuration and its reason",
                    code="FUSE_GEMM_FLAG_OVERRIDDEN",
                    asserts=[A("requested fuse GEMM config survives resolution",
                               doc.evidence["trap117_flags"], held=False)])
    else:
        doc.inconclusive(["117"], "fused GEMM communication activation",
                         "no explicit requested=true/resolved=false pair; "
                         "activation at runtime is not verified from config alone",
                         code="FUSE_GEMM_CONFIG_NOT_SETTLED",
                         asserts=[A("fused pass execution confirmed",
                                    doc.evidence["trap117_flags"], held=False)])


def check_cudagraph_capture_clamp(doc, root, key):
    """Trap 130: compare requested and effective graph shapes if both exposed."""
    st, raw = get(root + "/props", key, timeout=8)
    try:
        obj = json.loads(raw) if st == 200 else {}
    except (TypeError, ValueError):
        obj = {}
    requested = obj.get("requested_cudagraph_capture_size") if isinstance(obj, dict) else None
    sizes = obj.get("cudagraph_capture_sizes") if isinstance(obj, dict) else None
    if not isinstance(requested, int) or not isinstance(sizes, list) or not sizes or (
            not all(isinstance(i, int) and i > 0 for i in sizes)):
        doc.skip(["130"], "CUDA graph requested versus effective capture sizes",
                 "need an explicitly requested capture size plus resolved "
                 "nonempty integer capture-size list",
                 code="CUDAGRAPH_CAPTURE_CONFIG_MISSING",
                 asserts=[A("requested and effective sizes exposed",
                            {"requested": requested, "sizes": sizes}, held=False)])
        return
    effective_max = max(sizes)
    doc.evidence["trap130_capture"] = {"requested": requested,
                                       "effective_max": effective_max}
    if requested > effective_max:
        doc.problem(["130"], "requested CUDA-graph capture size exceeds the "
                    "largest effective capture shape",
                    "ensure the actual decode shape is captured; the "
                    "highest requested shape may be falling back to eager",
                    code="CUDAGRAPH_SIZE_CLAMP_OBSERVED",
                    asserts=[A("requested maximum shape included in capture sizes",
                               doc.evidence["trap130_capture"], held=False)])
    else:
        doc.inconclusive(["130"], "CUDA graph capture effectiveness",
                         "the effective list reaches the requested maximum, "
                         "but actual graph use per decode shape was not observed",
                         code="CUDAGRAPH_EFFECT_NOT_VERIFIED",
                         asserts=[A("runtime CUDA graph path observed",
                                    doc.evidence["trap130_capture"], held=False)])


def check_execution_concurrency_evidence(doc, root, key):
    """Trap 135: a running-request gauge is admission, not GPU concurrency."""
    st, raw = get(root + "/metrics", key, timeout=8)
    running = _parse_metric_values(raw, "num_requests_running") if st == 200 else []
    if not running:
        doc.skip(["135"], "HTTP requests versus real execution concurrency",
                 "no running-request gauge is available",
                 code="CONCURRENCY_GAUGE_UNAVAILABLE",
                 asserts=[A("running-request count exposed", st, held=False)])
        return
    doc.evidence["trap135_running"] = max(running)
    doc.inconclusive(["135"], "client concurrency versus model execution",
                     "the running-request gauge measures admission, not "
                     "completed-work throughput or GPU execution overlap",
                     code="CONCURRENCY_ADMISSION_NOT_EXECUTION",
                     asserts=[A("C1/C2/C4 completed-work and worker-overlap "
                                "comparison recorded",
                                {"running": max(running)}, held=False)])



def check_minicpm_short_answer_channel(doc, base, key):
    """Trap 162: bounded, matched short-answer field placement on MiniCPM V4.7."""
    name = (doc.model or "").lower()
    if "minicpm" not in name or "4.7" not in name:
        doc.skip(["162"], "MiniCPM short-answer thinking channel",
                 "this failure was measured on MiniCPM-V 4.7; do not "
                 "generalise it from an unrelated served model",
                 code="MINICPM_SHORT_ANSWER_MODEL_NOT_MATCHED",
                 asserts=[A("MiniCPM-V 4.7 model identified",
                            doc.model, held=False)])
        return
    q = ("Which planet in our solar system is the largest?\n"
         "A. Mars\nB. Jupiter\nC. Venus\nD. Mercury\n"
         "Answer with only the letter.")
    records = {}
    for label, thinking in (("on", True), ("off", False)):
        st, choice, payload = chat(
            doc, base, key, doc.model,
            [{"role": "user", "content": q}],
            max_tokens=96, chat_template_kwargs={"enable_thinking": thinking})
        message = (choice or {}).get("message") if isinstance(choice, dict) else {}
        message = message if isinstance(message, dict) else {}
        usage = payload.get("usage") if isinstance(payload, dict) else {}
        records[label] = {
            "status": st,
            "finish": choice.get("finish_reason") if isinstance(choice, dict) else None,
            "content": message.get("content"),
            "reasoning": message.get("reasoning") or message.get("reasoning_content"),
            "completion_tokens": usage.get("completion_tokens") if isinstance(usage, dict) else None,
        }
    on, off = records["on"], records["off"]
    viable = all(records[x]["status"] == 200 and
                 records[x]["finish"] in ("stop", "length") for x in ("on", "off"))
    doc.evidence["trap162_fields"] = {
        label: {"status": row["status"], "finish": row["finish"],
                "content_nonempty": bool(row["content"]),
                "reasoning_nonempty": bool(row["reasoning"]),
                "completion_tokens": row["completion_tokens"]}
        for label, row in records.items()
    }
    if not viable:
        doc.skip(["162"], "MiniCPM-V 4.7 short-answer field placement",
                 "thinking-on and thinking-off controls did not both return "
                 "usable completions",
                 code="MINICPM_SHORT_PAIR_UNAVAILABLE",
                 asserts=[A("matched on/off controls both completed",
                            doc.evidence["trap162_fields"], held=False)])
    elif (on["finish"] == "stop" and not on["content"] and
          isinstance(on["reasoning"], str) and
          on["reasoning"].strip().upper() == "B" and
          isinstance(off["content"], str) and
          off["content"].strip().upper() == "B"):
        doc.problem(
            ["162"], "MiniCPM-V 4.7 thinking-on returned stop with null "
            "answer content while the correct answer landed in reasoning; "
            "the matched thinking-off control returned the answer in content",
            "bucket stop-finished reasoning-only answers separately from "
            "length-capped traces; confirm the raw missing-close-tag "
            "mechanism before changing parsers",
            code="MINICPM_SHORT_ANSWER_IN_REASONING",
            asserts=[A("short thinking-on answer delivered in content",
                       doc.evidence["trap162_fields"], held=False)])
    else:
        doc.inconclusive(
            ["162"], "MiniCPM-V 4.7 short-answer thinking channel",
            "this paired item did not reproduce the stop-finished answer "
            "in reasoning field; the documented failure was intermittent "
            "and one negative pair cannot prove the model safe",
            code="MINICPM_SHORT_ANSWER_NOT_REPRODUCED",
            asserts=[A("repeated short-answer sample rules out intermittent "
                       "routing defects", doc.evidence["trap162_fields"], held=False)])


def check_minicpm_processor_metadata(doc, args):
    """Trap 163: check pinned public repo auto_map module references, never execute code."""
    repo = getattr(args, "hf_repo", None)
    revision = getattr(args, "hf_revision", "main")
    if not isinstance(repo, str) or not re.fullmatch(
            r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo) or (
            "minicpm-v-4.7" not in repo.lower()):
        doc.skip(["163"], "MiniCPM-V 4.7 processor metadata",
                 "pass --hf-repo org/MiniCPM-V-4.7... for this "
                 "repository-specific public metadata check",
                 code="MINICPM_METADATA_REPO_UNAVAILABLE",
                 asserts=[A("supported MiniCPM-V 4.7 repo supplied",
                            repo, held=False)])
        return
    if not isinstance(revision, str) or not re.fullmatch(
            r"[A-Za-z0-9_.\-/]{1,128}", revision):
        doc.skip(["163"], "MiniCPM processor metadata revision",
                 "revision must be a plain branch/tag/commit ref",
                 code="MINICPM_METADATA_REVISION_INVALID",
                 asserts=[A("safe repository revision supplied",
                            revision, held=False)])
        return
    st, txt = get(f"{HF_BASE}/api/models/{repo}/revision/{revision}", timeout=20)
    try:
        record = json.loads(txt) if st == 200 else {}
        sha = record.get("sha")
        siblings = record.get("siblings")
    except (TypeError, ValueError):
        sha, siblings = None, None
    if (not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{40}", sha)
            or not isinstance(siblings, list)):
        doc.skip(["163"], "MiniCPM processor metadata revision",
                 "the HF API did not return an immutable revision plus file "
                 "inventory; do not guess module absence from a 404",
                 code="MINICPM_METADATA_INVENTORY_UNAVAILABLE",
                 asserts=[A("pinned revision and sibling inventory received",
                            {"status": st, "revision_pinned": bool(sha),
                             "inventory": isinstance(siblings, list)},
                            held=False)])
        return
    available = {item.get("rfilename") for item in siblings
                 if isinstance(item, dict) and isinstance(item.get("rfilename"), str)}
    refs = set()
    def walk(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if key == "auto_map" and isinstance(value, dict):
                    for target in value.values():
                        for entry in (target if isinstance(target, list) else [target]):
                            if not isinstance(entry, str) or "." not in entry:
                                continue
                            mod = entry.split("--")[-1].rsplit(".", 1)[0]
                            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", mod):
                                refs.add(mod.replace(".", "/") + ".py")
                else:
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    for filename in ("processor_config.json", "preprocessor_config.json",
                     "tokenizer_config.json"):
        if filename not in available:
            continue
        status, body = get(
            f"{HF_BASE}/{repo}/resolve/{sha}/{filename}", timeout=20)
        if status != 200:
            doc.skip(["163"], "MiniCPM processor metadata configuration",
                     "a declared metadata JSON could not be read at the "
                     "pinned revision",
                     code="MINICPM_METADATA_CONFIG_UNREADABLE",
                     asserts=[A("all declared processor configs fetched",
                                {"file": filename, "status": status},
                                held=False)])
            return
        try:
            walk(json.loads(body))
        except (TypeError, ValueError):
            doc.skip(["163"], "MiniCPM processor metadata configuration",
                     "one referenced processor config was malformed JSON",
                     code="MINICPM_METADATA_CONFIG_INVALID",
                     asserts=[A("processor JSON parses", filename, held=False)])
            return
    missing = sorted(refs - available)
    doc.evidence["trap163_modules"] = {
        "repo": repo, "revision": sha[:12],
        "referenced": sorted(refs), "missing": missing}
    if missing:
        doc.problem(
            ["163"], "pinned MiniCPM processor auto_map references "
            "Python modules absent from that same checkpoint repository",
            "do not enable trust_remote_code to bypass absent source; "
            "compare pinned base and quantized processor metadata before "
            "making an explicit, reversible overlay",
            code="MINICPM_AUTOMAP_MODULE_MISSING",
            asserts=[A("every auto_map module exists at pinned revision",
                       doc.evidence["trap163_modules"], held=False)])
    else:
        doc.inconclusive(
            ["163"], "MiniCPM processor metadata provenance",
            "no missing auto_map modules were established on this pinned "
            "revision; this does not compare native processor classes, "
            "base-repo metadata or runtime compatibility",
            code="MINICPM_METADATA_NO_MISSING_MODULE",
            asserts=[A("base/quantized processor compatibility verified",
                       doc.evidence["trap163_modules"], held=False)])


def check_baked_default_system(doc, root, key):
    """Trap 83: compare no-system and explicit empty-system renders."""
    marker = "MF83_USER_8C7A"
    variants = (
        ("omitted", [{"role": "user", "content": marker}]),
        ("empty", [{"role": "system", "content": ""}, {"role": "user", "content": marker}]),
    )
    arms = {}
    for label, messages in variants:
        rendered, how = render_paths(doc, root, key, messages, {})
        arms[label] = rendered
        if rendered is not None:
            doc.evidence.setdefault("trap83_render_path", how)
    if any(v is None for v in arms.values()) or any(
            v is not None and v.count(marker) != 1 for v in arms.values()):
        doc.skip(["83"], "default-system-prompt render comparison",
                 "both renders must be available and preserve the user marker exactly once",
                 code="DEFAULT_SYSTEM_RENDER_UNAVAILABLE",
                 asserts=[A("two complete marked renders", {
                     k: v is not None and v.count(marker) == 1
                     for k, v in arms.items()}, held=False)])
        return
    a, b = arms["omitted"], arms["empty"]
    # A larger no-system arm is a lead, not proof of a baked instruction.
    # Only a literal identifiable system span can substantiate that mechanism.
    if len(a) > len(b) and (
            re.search(r"<\|im_start\|>system\b", a)
            or re.search(r"\[INST\]\s*<<SYS>>", a)):
        doc.problem(["83"],
                    "omitting the system role inserts additional rendered text "
                    "with a recognizable system delimiter",
                    "inspect the resolved template's default/else branch before "
                    "using absent-system prompts as an evaluation control",
                    code="DEFAULT_SYSTEM_INJECTED",
                    asserts=[A("omitted system does not add a system-marked payload",
                               {"omitted_len":len(a),"empty_len":len(b)},
                               held=False)])
    elif a == b:
        doc.inconclusive(["83"], "default system prompt",
                         "the two renders are identical, which does not prove that "
                         "the template has no baked prompt in other role paths",
                         code="DEFAULT_SYSTEM_IDENTICAL",
                         asserts=[A("a differential control identifies the default branch",
                                    {"same":True}, held=False)])
    else:
        doc.inconclusive(["83"], "default system prompt",
                         "the renders differ, but the difference does not establish "
                         "the specific baked-system-prompt failure",
                         code="DEFAULT_SYSTEM_DIFFERENCE_UNATTRIBUTED",
                         asserts=[A("default system payload established",
                                    {"omitted_len":len(a),"empty_len":len(b)},
                                    held=False)])


def check_tool_roundtrip_followup(doc, root, key):
    """Trap 84: a tool round trip must not make the next user turn unrenderable."""
    if doc.stack != "llama.cpp":
        doc.skip(
            ["84"], "tool-roundtrip follow-up render",
            "the published failure is a llama.cpp /apply-template role-alternation case",
            code="TOOL_FOLLOWUP_STACK_NOT_APPLICABLE",
            asserts=[A("llama.cpp /apply-template available", doc.stack, held=False)])
        return
    call = {"id": "callabc12", "type": "function",
            "function": {"name": "lookup", "arguments": '{"city":"Paris"}'}}
    user = {"role": "user", "content": "M84 first user"}
    assistant_call = {"role": "assistant", "content": "", "tool_calls": [call]}
    tool_result = {"role": "tool", "tool_call_id": "callabc12",
                   "name": "lookup", "content": "M84 tool reply"}
    next_user = {"role": "user", "content": "M84 next user"}
    bridge = {"role": "assistant", "content": "M84 bridge"}
    sequences = (
        ("baseline", [user]),
        ("followup", [user, assistant_call, tool_result, next_user]),
        ("bridged", [user, assistant_call, tool_result, bridge, next_user]),
    )
    results = {}
    for name, msgs in sequences:
        status, raw = post(root + "/apply-template", {"messages": msgs}, key, timeout=30)
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            data = {}
        prompt = data.get("prompt") if isinstance(data, dict) else None
        results[name] = (status, prompt if isinstance(prompt, str) else None)
    doc.evidence["trap84_render_statuses"] = {k: v[0] for k, v in results.items()}
    baseline, followup, bridged = (results[n] for n in ("baseline", "followup", "bridged"))
    if (baseline[0] != 200 or baseline[1] is None or
            bridged[0] != 200 or bridged[1] is None or
            "M84 next user" not in bridged[1] or "M84 bridge" not in bridged[1]):
        doc.inconclusive(
            ["84"], "tool-roundtrip follow-up render",
            "baseline or bridged control failed; follow-up status alone cannot "
            "establish the alternation-specific failure",
            code="TOOL_FOLLOWUP_CONTROL_INCOMPLETE",
            asserts=[A("baseline and bridged controls both render with their markers",
                       doc.evidence["trap84_render_statuses"], held=False)])
    elif followup[0] == 400:
        doc.problem(
            ["84"], "four-message tool round trip is rejected while the bridged "
            "five-message control renders correctly",
            "inspect role-alternation/exemption rules in the template; do not "
            "attribute the 400 to model generation or a missing GPU kernel",
            code="TOOL_FOLLOWUP_400_BRIDGED_OK",
            asserts=[A("unbridged tool follow-up renders successfully",
                       doc.evidence["trap84_render_statuses"], held=False)])
    elif (followup[0] == 200 and followup[1] is not None
          and "M84 next user" in followup[1] and "M84 tool reply" in followup[1]):
        doc.ok(
            ["84"], "the tool result and following user turn both survive the "
            "four-message render on this llama.cpp template",
            code="TOOL_FOLLOWUP_RENDERS",
            asserts=[A("unbridged follow-up successfully renders both marker contents",
                       doc.evidence["trap84_render_statuses"])])
    else:
        doc.inconclusive(
            ["84"], "tool-roundtrip follow-up render",
            "follow-up was not the documented 400 shape, but was not proven "
            "to preserve tool and user contents either",
            code="TOOL_FOLLOWUP_OTHER",
            asserts=[A("follow-up render returns 200 with both markers",
                       doc.evidence["trap84_render_statuses"], held=False)])


def check_system_prompt_relocation(doc, root, key):
    """Trap 82: system text must not migrate into the final user-turn region."""
    markers = {
        "system": "MF82_SYSTEM_7F3C",
        "user1": "MF82_USER1_7F3C",
        "assistant1": "MF82_ASSISTANT1_7F3C",
        "user2": "MF82_USER2_7F3C",
    }
    messages = [
        {"role": "system", "content": markers["system"]},
        {"role": "user", "content": markers["user1"]},
        {"role": "assistant", "content": markers["assistant1"]},
        {"role": "user", "content": markers["user2"]},
    ]
    rendered, how = render_paths(
        doc, root, key, messages, {"enable_thinking": False}
    )
    if rendered is None:
        doc.skip(
            ["82"], "system-prompt placement in a multi-turn render",
            "no render path was available, so the doctor cannot observe where the "
            "template placed the system text",
            code="SYSTEM_PROMPT_RENDER_UNAVAILABLE",
            asserts=[A("the multi-turn prompt can be rendered",
                       "all supported render paths returned nothing", held=False)])
        return

    counts = {name: rendered.count(marker) for name, marker in markers.items()}
    doc.evidence["trap82_render_path"] = how
    doc.evidence["trap82_marker_counts"] = counts
    if any(count != 1 for count in counts.values()):
        doc.inconclusive(
            ["82"], "system-prompt placement in a multi-turn render",
            "the render did not preserve every unique marker exactly once, so its "
            "relative positions cannot safely adjudicate system relocation",
            code="SYSTEM_PROMPT_MARKERS_AMBIGUOUS",
            asserts=[A("each system/user/assistant marker appears exactly once",
                       counts, held=False)])
        return

    pos = {name: rendered.index(marker) for name, marker in markers.items()}
    doc.evidence["trap82_marker_positions"] = pos
    if pos["system"] < pos["user1"] < pos["assistant1"] < pos["user2"]:
        doc.ok(
            ["82"],
            f"the system marker stays at the head of the rendered conversation via {how}; "
            "it is not relocated into the last user turn",
            code="SYSTEM_PROMPT_STAYS_AT_HEAD",
            asserts=[A("system marker precedes user1, assistant1 and user2",
                       pos)])
        return

    if (pos["user1"] < pos["assistant1"]
            and pos["system"] > pos["assistant1"]
            and pos["user2"] > pos["assistant1"]):
        doc.problem(
            ["82"],
            f"the system marker appears in the final-user region of the rendered prompt "
            f"via {how}, after the prior assistant turn instead of at the head",
            "treat the template as prefix-unstable across turns; inspect or replace the "
            "template before attributing zero prefix-cache reuse to the cache engine",
            code="SYSTEM_PROMPT_RELOCATED_TO_LAST_USER",
            asserts=[A("system marker remains before the first user turn",
                       pos, held=False)])
        return

    doc.inconclusive(
        ["82"], "system-prompt placement in a multi-turn render",
        "all markers were present, but their order was neither the stable-head control "
        "nor the documented last-user relocation shape",
        code="SYSTEM_PROMPT_PLACEMENT_OTHER",
        asserts=[A("render matches either the stable-head or last-user placement shape",
                   pos, held=False)])


def check_history_assembly(doc, root, key):
    """Traps 04 (stripping), 25 (empty shells), 20 (write field), 02 (tag balance)."""
    def msgs(field):
        turns = [{"role": "system", "content": "You are a coding agent."}]
        for i in (1, 2):
            turns.append({"role": "user", "content": f"Step {i}: what next?"})
            a = {"role": "assistant", "content": f"Doing step {i}."}
            if field:
                a[field] = f"{RMARK} thinking about step {i}."
            turns.append(a)
        turns.append({"role": "user", "content": "Step 3: what next?"})
        return turns

    base_render, how = render_paths(doc, root, key, msgs(None), {"enable_thinking": True})
    if base_render is None:
        doc.skip(["04", "25", "20"], "assembled-prompt inspection at turn 3",
                 "no render path on this stack (tried llama.cpp /apply-template, "
                 "vLLM /v1/chat/completions/render plus /detokenize, vLLM "
                 "/tokenize with token_strs, and a local jinja2 render of a "
                 "server-published template); run the registry's "
                 "checks/preflight_template.py with --template-file instead",
                 code="NO_RENDER_PATH",
                 asserts=[A("a render path returns the assembled prompt",
                            "all four render paths returned nothing",
                            held=False)])
        return
    doc.evidence["render_path"] = how
    empty_pairs = len(re.findall(r"<think>\s*</think>", base_render))
    if empty_pairs:
        doc.problem(["04", "25"], f"history renders {empty_pairs} empty think "
                    f"block(s) for prior turns (via {how}): multi-turn thinking "
                    f"collapse reads as a model property, and equivalent "
                    f"histories cache-miss",
                    "resend prior reasoning under the field this runtime reads, "
                    "or use a template that skips empty wrappers",
                    code="EMPTY_THINK_SHELLS",
                    asserts=[A("assembled turn-3 prompt contains no <think></think> "
                               "pair", empty_pairs, held=False)])
    else:
        # Tagged 25 only. The absence of empty think shells rules out trap 25,
        # which IS about the empty wrappers. It does not rule out trap 04:
        # a lane that drops prior reasoning and emits no wrapper at all leaves
        # exactly this render, and that is the HISTORY_STRIPPED_NO_GATE case
        # decided by the write-field probe below. Trap 04 gets its verdict
        # there, from evidence that can actually settle it.
        doc.ok(["25"], f"no empty think shells in the turn-3 render (via {how})",
               code="NO_EMPTY_THINK_SHELLS",
               asserts=[A("assembled turn-3 prompt contains no <think></think> "
                          "pair", empty_pairs)])

    hits = {}
    for field in ("reasoning_content", "reasoning"):
        r, _ = render_paths(doc, root, key, msgs(field), {"enable_thinking": True})
        hits[field] = (r is not None and RMARK in r)
    doc.evidence["write_field_hits"] = hits
    live = [f for f, h in hits.items() if h]
    if live:
        doc.ok(["20", "04"], f"prior-turn reasoning survives history when resent "
               f"as {' and '.join(live)}; dead write name(s): "
               f"{[f for f, h in hits.items() if not h] or 'none'}. Use the live name",
               code="WRITE_FIELD_IDENTIFIED",
               asserts=[A("a marked prior-turn reasoning string reaches the "
                          "assembled prompt under at least one field name", hits)])
        if len(live) == 1:
            doc.ok(["20"], f"write field on this runtime is {live[0]} only: "
                   f"porting a fix that resends the other name silently does nothing",
                   code="WRITE_FIELD_SINGLE",
                   asserts=[A("exactly one of the two field names survives", hits)])
    else:
        # No field name works on its own, so the template is gating history
        # reasoning behind a kwarg. Try every preservation kwarg shape we have
        # seen in the wild, in both polarities, under both field names. The
        # polarity matters: `preserve_thinking: true` and
        # `truncate_history_thinking: false` are the same switch written two
        # ways, and a pipeline standardised on the first silently no-ops on a
        # family that reads the second.
        gates = [("preserve_thinking", True), ("truncate_history_thinking", False),
                 ("keep_thinking", True), ("include_reasoning", True)]
        found = None
        for gate, val in gates:
            for field in ("reasoning", "reasoning_content"):
                r, _ = render_paths(doc, root, key, msgs(field),
                                    {"enable_thinking": True, gate: val})
                if r is not None and RMARK in r:
                    found = (gate, val, field)
                    break
            if found:
                break
        doc.evidence["preservation_gate"] = found
        if found:
            gate, val, field = found
            doc.problem(["04"], f"history reasoning is stripped by DEFAULT on this "
                        f"lane. The working preservation path is "
                        f"chat_template_kwargs {{{gate!r}: {str(val).lower()}}} "
                        f"WITH prior reasoning resent under {field!r}. Every client "
                        f"that does not set both runs the stripped arm",
                        f"send {gate}={str(val).lower()} and resend reasoning as "
                        f"{field} on every multi-turn call, and record it beside "
                        f"your numbers; do not port a different kwarg name or "
                        f"polarity from another model's writeup",
                        code="HISTORY_STRIPPED_GATE_FOUND",
                        asserts=[A("prior reasoning reaches the prompt with no "
                                   "preservation kwarg", hits, held=False),
                                 A("a known preservation kwarg restores it",
                                   {"gate": gate, "value": val, "field": field})])
        else:
            doc.problem(["04", "20"], "resent prior reasoning under BOTH field "
                        "names, and under four known preservation kwargs, never "
                        "reaches the assembled prompt: this lane strips history "
                        "reasoning with no preservation path this tool knows",
                        "enumerate the kwargs your template actually reads "
                        "(checks/preflight_template.py) before trusting any "
                        "multi-turn number from this lane; the switch may exist "
                        "under a name not in this list",
                        code="HISTORY_STRIPPED_NO_GATE",
                        asserts=[A("prior reasoning reaches the prompt under "
                                   "either field name", hits, held=False),
                                 A("any of four known preservation kwargs "
                                   "restores it",
                                   [g for g, _ in gates], held=False)])

    o, c = base_render.count("<think>"), base_render.count("</think>")
    if c > o:
        doc.problem(["02"], f"assembled prompt has {c} </think> vs {o} <think>: "
                    "orphaned close tags in history",
                    "fix template or history assembly",
                    code="ORPHANED_CLOSE_IN_RENDER",
                    asserts=[A("assembled prompt has no excess </think>",
                               {"open": o, "close": c}, held=False)])


def _tiny_png():
    """An 8x8 grey PNG built from the standard library, base64 encoded.

    Embedding a blob would be shorter, but a constructed one is auditable: you
    can read the chunk assembly and see that nothing is being smuggled into the
    request.
    """
    import base64, struct
    w = h = 8
    raw = b"".join(b"\x00" + bytes([128] * (w * 3)) for _ in range(h))

    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c))

    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw))
           + chunk(b"IEND", b""))
    return base64.b64encode(png).decode()


def _img_part():
    return {"type": "image_url",
            "image_url": {"url": "data:image/png;base64," + _tiny_png()}}


def check_multimodal(doc, base, root, key):
    """Multimodal surface. Traps 12/16 (ceiling with media) plus the multimodal
    family that has no registry numbers yet.

    Before this existed the doctor sent no media at all, so it reported a full
    set of clean checks on a multimodal lane while several multimodal defects
    were live. Reporting clean on a surface you never touched is worse than
    reporting nothing, so this check either exercises the surface or says
    explicitly that it could not.
    """
    txt_part = {"type": "text", "text": "Reply with the single word OK."}
    st, choice, body = chat(doc, base, key, doc.model,
                            [{"role": "user", "content": [txt_part, _img_part()]}],
                            max_tokens=16)
    if st != 200:
        blob = str(body).lower()
        named = [s for s in ("multimodal", "image", "not support", "unsupported",
                             "no multi", "modality") if s in blob]
        if named:
            doc.ok(["mm-surface"], f"text-only lane: the server rejected an inline "
                   f"image part with http {st}, naming the modality, so the "
                   f"multimodal traps do not apply here (this is a checked "
                   f"result, not an assumption)",
                   code="MM_REJECTED_NAMING_MODALITY",
                   asserts=[A("image request rejected with a modality-naming "
                              "error", {"status": st, "matched": named})])
        else:
            doc.skip(["mm-surface"], "multimodal surface",
                     f"an image request failed with http {st} for a reason that "
                     f"does not name multimodality, so whether this lane accepts "
                     f"media is UNKNOWN. Do not read the other clean results as "
                     f"covering media.",
                     code="MM_SURFACE_UNKNOWN",
                     asserts=[A("image-request failure names the modality",
                                {"status": st}, held=False)])
        return

    doc.ok(["mm-surface"], "lane accepts inline image parts (probed with a "
           "generated 8x8 PNG, not assumed from the model name)",
           code="MM_SURFACE_ACCEPTS_IMAGES",
           asserts=[A("inline image part accepted", {"status": st})])

    # ---- usage attribution: can you tell what the media cost you?
    usage = (body or {}).get("usage") if isinstance(body, dict) else None
    if isinstance(usage, dict):
        if usage.get("prompt_tokens_details") in (None, {}):
            doc.problem(["73"], "prompt_tokens_details is null on a request "
                        "that carried an image: media token cost is not "
                        "attributable from the API, and neither are cache hits",
                        "measure media cost by differencing prompt_tokens against "
                        "a text-only control; do not trust a per-modality "
                        "breakdown you did not measure",
                        code="MM_USAGE_UNATTRIBUTABLE",
                        asserts=[A("usage.prompt_tokens_details is populated",
                                   usage.get("prompt_tokens_details"), held=False)])
        else:
            doc.ok(["73"], "prompt_tokens_details is populated: media token "
                   "cost is attributable from the usage block",
                   code="MM_USAGE_ATTRIBUTABLE",
                   asserts=[A("usage.prompt_tokens_details is populated",
                              usage.get("prompt_tokens_details"))])
    else:
        doc.skip(["73"], "media token attribution",
                 "the response carried no usage block at all, so whether media "
                 "cost is attributable could not be determined",
                 code="MM_USAGE_NO_BLOCK",
                 asserts=[A("response carries a usage object", type(usage).__name__,
                            held=False)])

    # ---- part ordering: does the server preserve where the media sat?
    a, how_a = render_paths(doc, root, key,
                            [{"role": "user", "content": [
                                {"type": "text", "text": "ALPHAMARKERZQX"},
                                _img_part(),
                                {"type": "text", "text": "OMEGAMARKERZQX"}]}],
                            {"enable_thinking": True})
    b, _ = render_paths(doc, root, key,
                        [{"role": "user", "content": [
                            _img_part(),
                            {"type": "text", "text": "ALPHAMARKERZQX"},
                            {"type": "text", "text": "OMEGAMARKERZQX"}]}],
                        {"enable_thinking": True})
    if a is None or b is None:
        doc.skip(["68"], "multimodal content-part ordering",
                 "no render path available for the ordering comparison",
                 code="MM_ORDER_NO_RENDER_PATH",
                 asserts=[A("both orderings render", {"a": a is not None,
                                                      "b": b is not None},
                            held=False)])
    elif a == b:
        doc.problem(["68"], "the assembled prompt is byte-identical whether "
                    "the image is sent before or after the text: content-part "
                    "ORDER IS DISCARDED, so prompts that place instructions "
                    "around an image do not reach the model that way",
                    "do not rely on part order; put positional instructions in "
                    "the text itself, and re-check any result that assumed the "
                    "model saw your arrangement",
                    code="MM_ORDER_DISCARDED",
                    asserts=[A("the two part orderings render differently",
                               "byte-identical", held=False)])
    else:
        doc.ok(["68"], "content-part order is preserved in the assembled "
               f"prompt (the two orderings render differently, via {how_a})",
               code="MM_ORDER_PRESERVED",
               asserts=[A("the two part orderings render differently",
                          {"a_chars": len(a), "b_chars": len(b),
                           "identical": False})])
        if "ALPHAMARKERZQXOMEGAMARKERZQX" in a.replace(" ", ""):
            doc.problem(["68"], "adjacent text parts are concatenated with "
                        "no separator in the assembled prompt: words run together",
                        "insert your own whitespace between adjacent text parts",
                        code="MM_TEXT_PARTS_GLUED",
                        asserts=[A("adjacent text parts are separated in the "
                                   "render", "markers adjacent", held=False)])

    # ---- error classification: is a caller mistake reported as a server fault?
    st2, _, body2 = chat(doc, base, key, doc.model,
                         [{"role": "user", "content": [
                             {"type": "text", "text": "Describe it."},
                             {"type": "image_url", "image_url": {
                                 "url": "file:///nonexistent/zqx-doctor-probe.png"}}]}],
                         max_tokens=16)
    if st2 is None:
        doc.skip(["72"], "media error classification", "probe request failed",
                 code="MM_ERROR_PROBE_FAILED",
                 asserts=[A("bad-media-path probe returned a status", st2,
                            held=False)])
    elif 500 <= st2 < 600:
        doc.problem(["72"], f"a media path that does not exist is reported "
                    f"as http {st2}, a server fault, not a 4xx caller error",
                    "retry logic keyed on 5xx will retry forever against a "
                    "permanently bad path; classify media-fetch failures "
                    "client-side before retrying, and do not page on them",
                    code="MM_ERROR_MISCLASSIFIED_5XX",
                    asserts=[A("a bad media path returns 4xx", st2, held=False)])
    elif 400 <= st2 < 500:
        doc.ok(["72"], f"a bad media path is correctly reported as http "
               f"{st2}, a caller error",
               code="MM_ERROR_CLASSIFIED_4XX",
               asserts=[A("a bad media path returns 4xx", st2)])
    else:
        doc.problem(["72"], f"a media path that does not exist returned "
                    f"http {st2} rather than an error at all",
                    "assert on media resolution client-side; this lane will "
                    "answer a prompt whose media never loaded",
                    code="MM_ERROR_NOT_REPORTED",
                    asserts=[A("a bad media path returns an error status", st2,
                               held=False)])

    # ---- say plainly what was NOT touched
    doc.skip(["mm-audio-video"], "audio and video channels",
             "this doctor sends a generated still image only. Audio and video "
             "paths, their decoders, their error classes and their token costs "
             "are NOT covered by any result above. On a lane that advertises "
             "them, treat the clean results here as scoped to text and images.",
             code="MM_AUDIO_VIDEO_NOT_PROBED",
             asserts=[A("audio or video was probed", "no audio or video request "
                        "is made by this tool", held=False)])


def check_reasoning_roundtrip_shape(doc, root, key):
    """Trap 63: cross field-name x preservation-gate render shape."""
    marker = "ZQX_ROUNDTRIP_63"
    base_messages = [
        {"role": "user", "content": "First turn."},
        {"role": "assistant", "content": "Answer one."},
        {"role": "user", "content": "Second turn."},
    ]
    arms = {}
    for field in ("reasoning", "reasoning_content"):
        for preserve in (False, True):
            messages = [dict(item) for item in base_messages]
            messages[1][field] = marker
            kwargs = {"enable_thinking": True}
            label = f"{field}:" + ("truncate_false" if preserve else "default")
            if preserve:
                kwargs["truncate_history_thinking"] = False
            rendered, how = render_paths(doc, root, key, messages, kwargs)
            if rendered is None:
                arms[label] = None
            else:
                arms[label] = marker in rendered
                doc.evidence.setdefault("trap63_render_path", how)
    doc.evidence["trap63_arms"] = arms
    available = {name: value for name, value in arms.items() if value is not None}
    if len(available) < 4:
        doc.skip(
            ["63"], "reasoning round-trip four-arm render",
            f"only {len(available)}/4 render arms were available; a four-way field/gate "
            "comparison is required before assigning this trap",
            code="ROUNDTRIP_RENDER_INCOMPLETE",
            asserts=[A("all four render arms returned", arms, held=False)])
        return
    hits = [name for name, value in available.items() if value]
    if len(hits) == 1:
        doc.problem(
            ["63"],
            f"reasoning round trip has exactly one working shape out of four: {hits[0]}",
            "Preserve and replay the exact working field+gate pair on every multi-turn call; "
            "do not port a field name or preservation-kwarg polarity from another family.",
            code="ROUNDTRIP_ONE_OF_FOUR",
            asserts=[A("more than one of the four field/gate arms preserves the marker",
                       {"arms": arms, "working": hits}, held=False)])
        return
    if not hits:
        doc.inconclusive(
            ["63"], "reasoning round-trip four-arm render",
            "none of the four published arms preserved the marker. This does not reproduce "
            "Trap 63's one-of-four shape, but it also does not establish a clean round trip; "
            "the lane may use a different preservation kwarg or field mapping.",
            code="ROUNDTRIP_ZERO_OF_FOUR",
            asserts=[A("at least one published field/gate arm preserves the marker",
                       arms, held=False)])
        return
    doc.ok(
        ["63"],
        f"reasoning round trip does not have the one-of-four failure shape: "
        f"{len(hits)}/4 arms preserve the marker ({', '.join(hits)})",
        code="ROUNDTRIP_NOT_ONE_OF_FOUR",
        asserts=[A("more than one of four field/gate arms preserves the marker",
                   {"arms": arms, "working": hits})])


def _apply_template_prompt(root, key, messages):
    st, txt = post(root + "/apply-template", {"messages": messages}, key, timeout=30)
    if st != 200:
        return st, None
    try:
        return st, json.loads(txt).get("prompt")
    except Exception:
        return st, None


def check_final_assistant_prefill(doc, root, key):
    """Trap 86: llama.cpp final assistant prefill bypasses normal delimiters."""
    if doc.stack != "llama.cpp":
        doc.skip(
            ["86"], "final-assistant prefill render",
            f"trap 86 is scoped to llama.cpp /apply-template; detected stack={doc.stack!r}",
            code="PREFILL_SCOPE_NOT_LLAMACPP",
            asserts=[A("detected stack is llama.cpp", doc.stack, held=False)])
        return
    mark = "ZQX_PREFILL_86"
    prefix = [
        {"role": "system", "content": "System."},
        {"role": "user", "content": "User one."},
    ]
    st_final, final = _apply_template_prompt(
        root, key, prefix + [{"role": "assistant", "content": mark}])
    st_mid, mid = _apply_template_prompt(
        root, key, prefix + [
            {"role": "assistant", "content": mark},
            {"role": "user", "content": "User two."},
        ])
    doc.evidence["trap86_status"] = {"final": st_final, "mid": st_mid}
    if final is None or mid is None or mark not in final or mark not in mid:
        doc.skip(
            ["86"], "final-assistant prefill render",
            f"/apply-template did not return both comparable renders "
            f"(final http {st_final}, mid http {st_mid})",
            code="PREFILL_RENDER_UNAVAILABLE",
            asserts=[A("both /apply-template arms contain the assistant marker",
                       {"final": st_final, "mid": st_mid}, held=False)])
        return

    def around(text):
        i = text.index(mark)
        return text[max(0, i - 16):i], text[i + len(mark):i + len(mark) + 16]

    final_ctx, mid_ctx = around(final), around(mid)
    doc.evidence["trap86_context"] = {"final": final_ctx, "mid": mid_ctx}
    if final_ctx != mid_ctx:
        doc.problem(
            ["86"],
            "the same assistant text is delimited differently when it is the final "
            "prefill turn versus a mid-conversation assistant turn",
            "Do not assume a final assistant prefill shares the same prompt prefix as "
            "the completed conversation. Diff the server render and qualify prefill "
            "behaviour separately.",
            code="FINAL_ASSISTANT_BYPASSES_TEMPLATE_BRANCH",
            asserts=[A("assistant delimiters are identical final vs mid conversation",
                       {"final": final_ctx, "mid": mid_ctx}, held=False)])
    else:
        doc.ok(
            ["86"],
            "final and mid-conversation assistant text use identical local delimiters "
            "around the probe marker on this llama.cpp lane",
            code="FINAL_ASSISTANT_DELIMITERS_MATCH",
            asserts=[A("assistant delimiters are identical final vs mid conversation",
                       {"final": final_ctx, "mid": mid_ctx})])


def check_llamacpp_slot_context(doc, root, key):
    """Trap 87: /props n_ctx may be per-slot rather than total context."""
    if doc.stack != "llama.cpp":
        doc.skip(
            ["87"], "llama.cpp /props context semantics",
            f"trap 87 is scoped to llama.cpp; detected stack={doc.stack!r}",
            code="PROPS_CONTEXT_SCOPE_NOT_LLAMACPP",
            asserts=[A("detected stack is llama.cpp", doc.stack, held=False)])
        return
    props = doc.evidence.get("props") or {}
    defaults = props.get("default_generation_settings") or {}
    params = defaults.get("params") if isinstance(defaults, dict) else {}
    props_ctx = None
    if isinstance(params, dict):
        props_ctx = params.get("n_ctx")
    if props_ctx is None:
        props_ctx = defaults.get("n_ctx") if isinstance(defaults, dict) else None
    total_slots = props.get("total_slots")
    st, txt = get(root + "/slots", key, timeout=15)
    try:
        payload = json.loads(txt) if st == 200 else None
    except Exception:
        payload = None
    slots = payload.get("slots") if isinstance(payload, dict) else payload
    if not isinstance(slots, list):
        slots = []
    slot_ctx = [row.get("n_ctx") for row in slots
                if isinstance(row, dict) and isinstance(row.get("n_ctx"), int)]
    doc.evidence["trap87_context"] = {
        "props_n_ctx": props_ctx, "total_slots": total_slots,
        "slots_status": st, "slot_n_ctx": slot_ctx,
        "endpoint_props": props.get("endpoint_props"),
    }
    if not isinstance(props_ctx, int) or not isinstance(total_slots, int) or total_slots < 2 or not slot_ctx:
        doc.skip(
            ["87"], "llama.cpp /props context semantics",
            "the check needs /props n_ctx, total_slots >= 2, and /slots n_ctx values; "
            f"observed props_n_ctx={props_ctx!r}, total_slots={total_slots!r}, "
            f"/slots http {st}, slot values={slot_ctx[:8]}",
            code="PROPS_CONTEXT_INCOMPLETE",
            asserts=[A("parallel llama.cpp lane publishes comparable /props and /slots context",
                       doc.evidence["trap87_context"], held=False)])
        return
    all_same = len(slot_ctx) == total_slots and all(value == props_ctx for value in slot_ctx)
    if all_same:
        doc.problem(
            ["87"],
            f"/props n_ctx={props_ctx} matches every one of {total_slots} slot n_ctx values: "
            "this is per-slot context, not the total context budget",
            "Treat /props n_ctx as per-slot on this lane. Do not compare it directly "
            "with a total -c launch value; multiply by slot count when reconstructing "
            "the total served KV budget.",
            code="PROPS_CONTEXT_IS_PER_SLOT",
            asserts=[A("/props n_ctx differs from each per-slot n_ctx when parallel>1",
                       doc.evidence["trap87_context"], held=False)])
    elif all(value != props_ctx for value in slot_ctx):
        doc.ok(
            ["87"],
            f"/props n_ctx={props_ctx} differs from all published per-slot values "
            f"{slot_ctx[:8]}; the specific per-slot-reporting failure is not present",
            code="PROPS_CONTEXT_NOT_PER_SLOT",
            asserts=[A("/props n_ctx differs from each per-slot n_ctx when parallel>1",
                       doc.evidence["trap87_context"])])
    else:
        doc.inconclusive(
            ["87"], "llama.cpp /props context semantics",
            f"mixed /slots context values {slot_ctx[:8]} cannot establish whether "
            f"/props n_ctx={props_ctx} is total or per-slot",
            code="PROPS_CONTEXT_MIXED",
            asserts=[A("/props and every /slots value have one unambiguous relation",
                       doc.evidence["trap87_context"], held=False)])


def check_kwarg_deadness(doc, base, root, key):
    """Trap 07: accepted-but-unread kwargs.

    Trap 07's own rule is that API acceptance proves nothing about effect. The
    only thing that turns acceptance into a verdict is reading the template. So
    when no template is readable, the honest answer is COULD NOT CHECK, not the
    CLEAN this used to emit. Likewise a rejection only means "dead knobs are
    loud here" if an otherwise identical request WITHOUT the kwargs succeeds;
    otherwise the rejection is about something else entirely.
    """
    tpl = (doc.evidence.get("props") or {}).get("chat_template") or ""
    st, choice, raw = chat(doc, base, key, doc.model,
                           [{"role": "user", "content": "Say OK."}],
                           max_tokens=16,
                           chat_template_kwargs={"bogus_kwarg_zzq": True,
                                                 "reasoning_effort": "high"})
    doc.evidence["kwarg_probe_status"] = st

    if st is None:
        doc.skip(["07"], "kwarg acceptance probe", "request failed",
                 code="KWARG_PROBE_FAILED",
                 asserts=[A("kwarg probe returned a status", st, held=False)])
        return

    if st == 200:
        if not tpl:
            doc.skip(["07"], "kwarg deadness (reasoning_effort and an invented name)",
                     "the server accepted chat_template_kwargs including an "
                     "invented name without error, and by trap 07's own rule "
                     "acceptance proves nothing about effect. No chat template "
                     "is readable on this stack (llama.cpp /props is the only "
                     "source this tool has), so whether ANY kwarg is actually "
                     "read could not be determined. Fetch the checkpoint's "
                     "chat_template.jinja and run "
                     "checks/preflight_template.py --template-file to settle it.",
                     code="KWARG_ACCEPTED_TEMPLATE_UNREADABLE",
                     asserts=[A("server accepted an invented chat_template_kwarg",
                                {"status": st}),
                              A("a chat template is readable, so acceptance can "
                                "be turned into a verdict", "no template source "
                                "on this stack", held=False)])
            return
        reads_effort = "reasoning_effort" in tpl
        accepted = ("server accepted chat_template_kwargs including an invented "
                    "name without error: acceptance proves nothing about effect")
        detail = (accepted + "; this template never mentions reasoning_effort "
                  "at all, so that knob is dead here")
        if reads_effort:
            # A substring hit means the template MENTIONS the name. It does not
            # mean the mention changes the rendered prompt: the name can sit in
            # a comment, in a branch never taken, or in a `set` that is never
            # used afterwards. This tool's own fixture template is exactly that
            # last shape. Trap 07's failure mode is a knob with no effect, and
            # "the name appears somewhere in the file" does not rule it out.
            doc.inconclusive(["07"], "reasoning_effort deadness",
                             accepted + "; this template MENTIONS "
                             "reasoning_effort, so the knob is REFERENCED"
                             ". A reference is not a read. The name appearing "
                             "in the template text is consistent with a live "
                             "knob, with a mention inside a comment, with a "
                             "branch that never runs, and with a variable that "
                             "is set and then never used. To settle it, render "
                             "the prompt twice through "
                             "checks/preflight_template.py --template-file with "
                             "the value changed and nothing else, and confirm "
                             "the two renders DIFFER. If they are identical the "
                             "knob is dead regardless of what the file mentions.",
                             code="KWARG_REFERENCED_BY_TEMPLATE",
                             asserts=[A("server accepted an invented "
                                        "chat_template_kwarg", {"status": st}),
                                      A("the served chat template mentions "
                                        "reasoning_effort",
                                        {"template_chars": len(tpl),
                                         "found": True}),
                                      A("changing reasoning_effort changes the "
                                        "rendered prompt",
                                        "this tool does not diff two renders; "
                                        "it greps the template text",
                                        held=False)])
        else:
            doc.problem(["07"], detail,
                        "before trusting any kwarg, grep the template for it; "
                        "diff accepted-vs-read in both directions",
                        code="KWARG_ACCEPTED_BUT_DEAD",
                        asserts=[A("server accepted an invented chat_template_kwarg",
                                   {"status": st}),
                                 A("the served chat template contains "
                                   "reasoning_effort",
                                   {"template_chars": len(tpl), "found": False},
                                   held=False)])
        return

    # Non-200. Before crediting the server for rejecting unknown kwargs, prove
    # the rejection is ABOUT the kwargs.
    cst, _cchoice, _craw = chat(doc, base, key, doc.model,
                                [{"role": "user", "content": "Say OK."}],
                                max_tokens=16)
    doc.evidence["kwarg_control_status"] = cst
    if cst != 200:
        doc.skip(["07"], "kwarg deadness (reasoning_effort and an invented name)",
                 f"the kwarg probe failed with http {st}, but so did an "
                 f"identical control request carrying no chat_template_kwargs "
                 f"(http {cst}). The rejection is not attributable to the "
                 f"kwargs, so it says nothing about how this lane handles them.",
                 code="KWARG_REJECTION_UNATTRIBUTABLE",
                 asserts=[A("a control request with no kwargs succeeds",
                            {"kwarg_probe": st, "control": cst}, held=False)])
        return

    bst, _b, _braw = chat(doc, base, key, doc.model,
                          [{"role": "user", "content": "Say OK."}],
                          max_tokens=16,
                          chat_template_kwargs={"bogus_kwarg_zzq": True})
    doc.evidence["kwarg_bogus_only_status"] = bst
    if bst != 200:
        doc.ok(["07"], f"server rejects an invented chat_template_kwarg on its own "
               f"(http {bst}) while an identical request without it succeeds "
               f"(http {cst}): dead knobs are loud here, which is the safe "
               f"direction of trap 07",
               code="KWARG_UNKNOWN_REJECTED",
               asserts=[A("control request with no kwargs succeeds", cst),
                        A("request with only the invented kwarg is rejected", bst)])
    else:
        doc.inconclusive(["07"], "kwarg deadness (reasoning_effort and an "
                         "invented name)",
                         f"the combined probe was rejected (http {st}) but the "
                         f"invented name ALONE was accepted (http {bst}), so the "
                         f"rejection came from reasoning_effort, not from unknown-"
                         f"kwarg strictness. This lane still accepts invented "
                         f"names silently, and whether reasoning_effort is read "
                         f"or merely validated cannot be told from a rejection. "
                         f"Read the template to settle it.",
                         code="KWARG_REJECTION_FROM_KNOWN_NAME",
                         asserts=[A("control request with no kwargs succeeds", cst),
                                  A("request with only the invented kwarg is "
                                    "rejected", bst, held=False)])


def check_tools(doc, base, key):
    """Traps 19 (structured vs prose), 26 (tool markup swallowed by reasoning).

    The old probe defined one tool, asked once, and called any absence of
    tool_calls a parser or template failure. Six states produce that same
    absence: the model elected not to call, the model cannot call, the template
    omits the tools block, the parser failed, the serve flags are missing, or
    the schema was rejected or transformed. This version separates
    MODEL_DID_NOT_CALL from TOOL_MARKUP_NOT_PARSED by forcing a call wherever
    tool_choice is supported, and downgrades its own confidence in writing
    where it cannot.
    """
    forced_choice_spec = {"type": "function", "function": {"name": "get_time"}}
    f_st, f_choice, f_raw = chat(doc, base, key, doc.model,
                                 [{"role": "user", "content":
                                   "What time is it in Tokyo?"}],
                                 max_tokens=256, tools=TOOLS,
                                 tool_choice=forced_choice_spec)
    forced_supported = (f_st == 200 and f_choice is not None)
    f_calls, f_text = [], ""
    if forced_supported:
        fc, frc, frr, f_calls, _ = msg_fields(f_choice)
        f_text = f"{fc}\n{frc}\n{frr}"
    doc.evidence["tool_choice_forced_status"] = f_st

    n_st, n_choice, n_raw = chat(doc, base, key, doc.model,
                                 [{"role": "user", "content":
                                   "What time is it in Tokyo? Use the tool."}],
                                 max_tokens=512, tools=TOOLS,
                                 chat_template_kwargs={"enable_thinking": True})
    doc.evidence["tool_natural_status"] = n_st
    if n_st != 200 or n_choice is None:
        if not forced_supported:
            doc.skip(["19", "26"], "tool-calling probe",
                     f"both the forced-call probe (http {f_st}) and the natural "
                     f"probe (http {n_st}) failed; if your server needs parser "
                     f"flags for tools, that absence is itself trap 19",
                     code="TOOL_PROBES_FAILED",
                     asserts=[A("at least one tools request returns 200",
                                {"forced": f_st, "natural": n_st}, held=False)])
            return
        n_calls, n_text = [], ""
    else:
        nc, nrc, nrr, n_calls, _ = msg_fields(n_choice)
        n_text = f"{nc}\n{nrc}\n{nrr}"

    # KNOWN LIMITATION, recorded rather than papered over. This detects one
    # hardcoded literal. It reached the right verdict on every lane tested so
    # far, and on at least one of them it did so by coincidence: the dialect
    # happened to use this tag. A checkpoint whose markup is a different tag
    # (a bare <function=...>, a [TOOL_CALL] form, or JSON with no wrapper)
    # leaves markup False, and the surrounding logic then reports
    # MODEL_DID_NOT_CALL rather than TOOL_MARKUP_NOT_PARSED. That is a
    # false-INCONCLUSIVE, which is safe, but the mirror case is not: a
    # checkpoint that emits this literal inside ordinary prose would set
    # markup True with no call, which is a latent false PROBLEM.
    #
    # Not fixed here, deliberately. A general detector needs the dialect, and
    # the registry's own trap 84 shows the dialect is a per-checkpoint property
    # that has to be read out of the template rather than guessed. Guessing
    # more tags would widen the false-PROBLEM surface, not narrow it.
    TOOL_MARKUP_LITERALS = ("<tool_call>",)
    markup = any(lit in f_text or lit in n_text for lit in TOOL_MARKUP_LITERALS)
    doc.evidence["tool_calls_seen"] = {"forced": len(f_calls),
                                       "natural": len(n_calls)}

    if f_calls or n_calls:
        who = "forced (tool_choice)" if f_calls else "natural prompt"
        got = (f_calls or n_calls)[0].get("function", {}).get("name")
        doc.ok(["19"], f"one tool defined, structured tool_calls returned on the "
               f"{who} probe (name={got})",
               code="TOOL_CALLS_RETURNED",
               asserts=[A("a tools request returns a structured tool_calls array",
                          {"forced": len(f_calls), "natural": len(n_calls),
                           "name": got})])
        if markup:
            # The assertion here used to read "no raw <tool_call> markup" and
            # record markup_seen=True beside it, held=True. The log said the
            # opposite of the claim and still counted as CLEAN.
            doc.problem(["26"], "structured tool_calls came back, but raw "
                        "<tool_call> markup ALSO appears in the content or "
                        "reasoning text: part of the tool traffic on this lane "
                        "is escaping the parser, so a multi-call turn can be "
                        "half parsed and half left as prose",
                        "on vLLM run a build past PR #35687; on llama.cpp use a "
                        "template that closes think before tool_call. Until "
                        "then, scan content and reasoning for leftover markup "
                        "before scoring any tool-using run",
                        code="TOOL_MARKUP_PARTIALLY_PARSED",
                        asserts=[A("no raw <tool_call> markup in content or "
                                   "reasoning", {"markup_seen": True},
                                   held=False)])
        else:
            doc.ok(["26"], "tool markup is parsed into tool_calls rather than "
                   "left as text inside the reasoning or content channel",
                   code="TOOL_MARKUP_PARSED",
                   asserts=[A("no raw <tool_call> markup in content or reasoning",
                              {"markup_seen": False})])
        if forced_supported and f_calls and not n_calls:
            doc.ok(["19"], "the model returns no call when merely asked, but "
                   "calls correctly when forced with tool_choice: this lane's "
                   "tool plumbing works and the empty natural response is a "
                   "model choice, NOT a parser or template fault",
                   code="MODEL_ELECTS_NOT_TO_CALL",
                   asserts=[A("forced probe calls while natural probe does not",
                              {"forced": len(f_calls), "natural": len(n_calls)})])
        return

    if markup:
        doc.problem(["26"], "tool markup produced but not parsed into tool_calls "
                    "(found inside the reasoning/content text): the parser is "
                    "eating your tool calls",
                    "on vLLM run a build past PR #35687; on llama.cpp use a "
                    "template that closes think before tool_call",
                    code="TOOL_MARKUP_NOT_PARSED",
                    asserts=[A("raw <tool_call> markup appears in text while "
                               "tool_calls is empty", {"markup": True,
                                                       "tool_calls": 0})])
        return

    if forced_supported:
        doc.problem(["19"], "no structured tool_calls even when the call was "
                    "FORCED with tool_choice, and no raw tool markup appeared "
                    "in the text either: this lane cannot emit a tool call at "
                    "all. It is not the model electing to answer in prose",
                    "check serve flags: --jinja and the model's native template "
                    "on llama.cpp, the model-specific tool parser on vLLM; then "
                    "confirm the template actually renders the tools block "
                    "(checks/preflight_template.py)",
                    code="TOOL_CALLING_UNAVAILABLE",
                    asserts=[A("server accepted tool_choice", {"status": f_st}),
                             A("a FORCED tool call returns tool_calls",
                               {"tool_calls": 0}, held=False),
                             A("raw tool markup appears anywhere in the text",
                               {"markup": False}, held=False)])
        return

    # tool_choice not supported: the ambiguity cannot be removed here, so say so
    doc.inconclusive(["19", "26"], "tool-calling capability",
                     f"no structured tool_calls and no raw tool markup with one "
                     f"tool defined, and this server did not accept a forced "
                     f"tool_choice (http {f_st}), so the deterministic control "
                     f"is unavailable. CONFIDENCE: LOW. At least six states "
                     f"produce this result and none were separated: (1) the "
                     f"model elected to answer in prose, (2) the model cannot "
                     f"call tools, (3) the chat template omits the tools block, "
                     f"(4) the server's tool parser is off or mismatched, "
                     f"(5) serve flags for tool parsing are missing, (6) the "
                     f"schema was rejected or silently transformed. Do NOT read "
                     f"this as a template or parser fault. To settle it: render "
                     f"the prompt with the tools attached and confirm the tools "
                     f"block appears (checks/preflight_template.py), then check "
                     f"your server's tool-parser flag.",
                     code="MODEL_DID_NOT_CALL",
                     asserts=[A("server accepts tool_choice, giving a "
                                "deterministic control", {"status": f_st},
                                held=False),
                              A("natural probe returns tool_calls",
                                {"tool_calls": 0}, held=False),
                              A("raw tool markup appears in the text",
                                {"markup": False}, held=False)])


def check_request_validation(doc, base, key):
    """Trap 77: is the request surface validated at all?

    The entry names this probe as its own fix, in its own words: "before you
    trust any new server with an arm of an experiment, send one deliberately
    misspelled parameter and see whether you get a 400. If you get a 200, the
    request surface is unvalidated, your own typos are silent too, and every
    parameter you send is a hypothesis rather than a setting." So this check
    is reading the entry, not inventing a test for it.

    Why it earns a place beside the behavioural toggle checks. Those ask "did
    thinking actually stop", which is the right question and an expensive one:
    it needs a reasoning observable, and on a lane that produces none the
    toggle map is uncharacterised and every arm skips. This asks the cheap
    structural question underneath it, which needs no observable at all: does
    a 200 on this lane carry ANY information about whether the server read
    what you sent? On a lane that answers no, every parameter in every other
    check is a hypothesis, and that is worth knowing before the expensive
    probes run rather than after.

    The CLEAN is paired, and it has to be. "The probe request returned 400" is
    satisfied by a lane that returns 400 for everything: a wrong model name,
    an expired key, a server still loading. That is the false-CLEAN shape this
    tool has produced four times. So the baseline goes first, and CLEAN
    requires an identical request WITHOUT the invented field to have returned
    200. The difference between the two is then attributable to the field.

    What the CLEAN does NOT rule out, stated here because it is the tempting
    over-read: a server that rejects an unknown field can still accept a
    known-but-unimplemented one and ignore it. Rejecting typos is a floor, not
    a guarantee that any particular parameter took effect. The behavioural
    question stays with traps 03 and 29, and the entry's own advice stands
    either way: assert on the response, never on the status code.
    """
    # A name no server implements and no server could plausibly add. Sent at
    # the top level, which is where trap 77 measured it; the entry records
    # that placement inside `options` behaved identically.
    probe_field = "__minefield_unvalidated_field_probe__"
    msgs = [{"role": "user", "content": "hi"}]

    base_st, _, base_txt = chat(doc, base, key, doc.model, msgs, max_tokens=16)
    if base_st != 200:
        doc.inconclusive(
            ["77"], "request-field validation",
            f"the baseline request (nothing invented, nothing unusual) did "
            f"not return 200 (http {base_st}), so a rejection of the probe "
            f"below would say nothing about field validation: a lane that "
            f"rejects everything rejects the probe too. Fix the lane, or the "
            f"model name or key, and re-run.",
            code="VALIDATION_NO_BASELINE",
            asserts=[A("a plain request succeeds",
                       {"status": base_st, "body": str(base_txt)[:160]},
                       held=False)])
        return

    probe_st, _, probe_txt = chat(doc, base, key, doc.model, msgs,
                                  max_tokens=16, **{probe_field: "minefield"})
    doc.evidence["unknown_field_probe_status"] = probe_st

    if probe_st != 200:
        doc.ok(["77"],
               f"the request surface is validated: an invented top-level "
               f"field was rejected (http {probe_st}) while the identical "
               f"request without it returned 200. A misspelled parameter on "
               f"this lane is loud rather than silent",
               code="VALIDATION_REJECTS_UNKNOWN_FIELD",
               asserts=[A("the baseline request succeeds",
                          {"status": base_st}),
                        A("the same request with an invented field is "
                          "rejected",
                          {"field": probe_field, "status": probe_st})])
        return

    doc.problem(
        ["77"],
        f"the request surface is unvalidated: an invented top-level field "
        f"({probe_field}) was accepted with http 200, exactly as the baseline "
        f"without it was. Nothing you send to this lane is confirmed by its "
        f"status code",
        "Treat every request parameter here as a hypothesis until you have "
        "checked the response. Two consequences, both of them cheap to get "
        "wrong: a thinking-off arm that sends a field this server does not "
        "implement is measured on whatever the lane's default is, which on a "
        "thinking-by-default lane means the entire arm is a number about the "
        "wrong configuration; and your own typos are silent, so a parameter "
        "you misspelled reads as a parameter that had no effect. Assert on "
        "the response per request, not per configuration: an arm you believe "
        "is thinking-off must show an absent or empty reasoning field on "
        "every request in it.",
        code="UNKNOWN_FIELD_ACCEPTED",
        asserts=[A("the baseline request succeeds", {"status": base_st}),
                 A("an invented field is rejected",
                   {"field": probe_field, "status": probe_st,
                    "body": str(probe_txt)[:160]}, held=False)])


def check_model_identity(doc, base, key):
    """Trap 141: does SGLang reject a deliberately wrong served-model name?

    Scope matters. Trap 141 is specifically the SGLang Python OpenAI chat
    route, so another stack cannot clear it. On SGLang the check is paired:
    the correctly named request must succeed first, then the same request is
    repeated with a model name that /v1/models did not advertise.
    """
    if doc.stack != "sglang":
        doc.skip(
            ["141"],
            "served-model identity validation",
            f"trap 141 is scoped to the SGLang Python OpenAI chat route; "
            f"detected stack={doc.stack!r}, so this run cannot clear or "
            f"confirm that SGLang-specific entry",
            code="MODEL_IDENTITY_SCOPE_NOT_SGLANG",
            asserts=[A("detected stack is SGLang",
                       {"stack": doc.stack}, held=False)])
        return

    msgs = [{"role": "user", "content": "Reply with OK."}]
    served_model = doc.model
    base_st, base_choice, base_raw = chat(
        doc, base, key, served_model, msgs, max_tokens=16)

    if base_st != 200 or base_choice is None:
        doc.inconclusive(
            ["141"],
            "served-model identity validation",
            f"the correctly named control request did not complete normally "
            f"(http {base_st}), so rejection of a wrong model name would not "
            f"be attributable to model-identity validation. Fix the lane and "
            f"re-run.",
            code="MODEL_IDENTITY_NO_BASELINE",
            asserts=[A("correctly named control request succeeds",
                       {"model": served_model, "status": base_st,
                        "body": str(base_raw)[:160]}, held=False)])
        return

    wrong_model = "__minefield_not_served_model__"
    wrong_st, wrong_choice, wrong_raw = chat(
        doc, base, key, wrong_model, msgs, max_tokens=16)
    doc.evidence["model_identity_probe"] = {
        "served_model": served_model,
        "wrong_model": wrong_model,
        "baseline_status": base_st,
        "wrong_model_status": wrong_st,
    }

    if wrong_st != 200:
        doc.ok(
            ["141"],
            f"SGLang rejected a deliberately wrong model name (http "
            f"{wrong_st}) while the correctly named control returned 200",
            code="WRONG_MODEL_REJECTED",
            asserts=[
                A("correctly named control request succeeds",
                  {"model": served_model, "status": base_st}),
                A("deliberately unserved model name is rejected",
                  {"model": wrong_model, "status": wrong_st}),
            ])
        return

    if wrong_choice is None:
        doc.inconclusive(
            ["141"],
            "wrong model name returned HTTP 200 but no parseable assistant choice",
            "HTTP 200 alone is not enough to claim the trap fired. Preserve "
            "the raw response and inspect the route before assigning the "
            "ordinary-content signature.",
            code="WRONG_MODEL_HTTP200_UNPARSEABLE",
            asserts=[
                A("correctly named control request succeeds",
                  {"model": served_model, "status": base_st}),
                A("wrong-name response contains a parseable assistant choice",
                  {"model": wrong_model, "status": wrong_st,
                   "body": str(wrong_raw)[:160]}, held=False),
            ])
        return

    content, reasoning_content, reasoning, tool_calls, _msg = msg_fields(wrong_choice)
    ordinary = bool(content.strip() or reasoning_content.strip()
                    or reasoning.strip() or tool_calls)
    if ordinary:
        doc.problem(
            ["141"],
            "SGLang answered a request naming a model it does not serve",
            "Do not trust the request model field as identity proof on this "
            "route. Resolve the served identity independently and fail closed "
            "on mismatches; upgrade/use a route that validates known model "
            "names before generation.",
            code="WRONG_MODEL_ACCEPTED",
            asserts=[
                A("correctly named control request succeeds",
                  {"model": served_model, "status": base_st}),
                A("deliberately unserved model name is rejected",
                  {"model": wrong_model, "status": wrong_st}, held=False),
                A("wrong-name request returned ordinary assistant output",
                  {"content_len": len(content),
                   "reasoning_len": len(reasoning_content) + len(reasoning),
                   "tool_calls": len(tool_calls)}),
            ])
        return

    doc.inconclusive(
        ["141"],
        "wrong model name returned HTTP 200 without ordinary assistant output",
        "The route accepted the wrong name at HTTP level, but this response "
        "does not reproduce Trap 141's ordinary-assistant-content signature. "
        "Inspect the raw response before assigning the trap.",
        code="WRONG_MODEL_ACCEPTANCE_INCONCLUSIVE",
        asserts=[
            A("correctly named control request succeeds",
              {"model": served_model, "status": base_st}),
            A("wrong-name request returned ordinary assistant output",
              {"status": wrong_st, "content_len": len(content),
               "reasoning_len": len(reasoning_content) + len(reasoning),
               "tool_calls": len(tool_calls)}, held=False),
        ])


def check_echo_logprobs(doc, base, key):
    """Trap 15: can this lane serve loglikelihood (multiple-choice) scoring?

    lm-eval scores multiple choice by sending echo=true plus logprobs to
    /v1/completions and reading per-token logprobs of each option. A lane that
    rejects the pair wedges the run; a lane that answers HTTP 200 with empty
    logprobs wedges it while looking healthy. This is the one request the
    entry itself names, and the verdict requires actual token_logprobs, not a
    200.
    """
    body = {"model": doc.model or "default", "prompt": "hi", "max_tokens": 1,
            "echo": True, "logprobs": 1, "temperature": 0}
    doc.consume_request()
    st, txt = post(base + "/completions", body, key)
    doc.evidence["echo_logprobs_probe"] = {"status": st, "body": str(txt)[:200]}
    probe = A("POST /completions with echo=true, logprobs=1",
              {"status": st, "body": str(txt)[:160]}, held=st == 200)
    if st is None:
        # A timeout or dropped connection says nothing about echo+logprobs.
        doc.skip(["15"], "echo+logprobs probe", "request failed before an HTTP status",
                 code="ECHO_LOGPROBS_PROBE_FAILED", asserts=[probe])
        return
    if st != 200:
        doc.problem(
            ["15"],
            f"this lane does not serve echo+logprobs completions (http {st}); "
            f"loglikelihood-scored multiple-choice tasks cannot run here",
            "Do not run lm-eval multiple-choice (loglikelihood) tasks against "
            "this lane, and never report their absence as a model score: mark "
            "them UNSUPPORTED and keep generative tasks separate.",
            code="ECHO_LOGPROBS_REJECTED", asserts=[probe])
        return
    try:
        choice = json.loads(txt)["choices"][0]
        token_logprobs = (choice.get("logprobs") or {}).get("token_logprobs")
    except Exception as exc:
        doc.inconclusive(
            ["15"], "echo+logprobs response could not be parsed",
            f"HTTP 200 but the body is not a completions response ({exc}); "
            f"inspect it before running loglikelihood tasks.",
            code="ECHO_LOGPROBS_UNPARSEABLE", asserts=[probe])
        return
    has = A("response carries non-empty token_logprobs",
            {"token_logprobs": str(token_logprobs)[:80]}, held=bool(token_logprobs))
    if not token_logprobs:
        doc.problem(
            ["15"],
            "echo+logprobs returned HTTP 200 with empty token_logprobs; "
            "lm-eval multiple choice will wedge or score zero while the lane "
            "looks healthy",
            "Treat loglikelihood tasks as UNSUPPORTED on this lane; a status-"
            "code check alone would have passed it.",
            code="ECHO_LOGPROBS_EMPTY_200", asserts=[probe, has])
        return
    doc.ok(["15"], "echo+logprobs completions return per-token logprobs; "
           "loglikelihood multiple-choice scoring is supported",
           code="ECHO_LOGPROBS_SUPPORTED", asserts=[probe, has])


def check_tool_choice_gate(doc, base, key):
    """Trap 78: tool_choice accepted and ignored, which fails OPEN.

    This is the first check in this tool for anything above trap 55, and it was
    chosen because it is the one with a real consequence: `tool_choice: "none"`
    is the standard way an agent framework says "answer in prose this turn, do
    not call anything". A server that accepts it and calls anyway does not
    produce an outage to investigate; it produces an agent that occasionally
    takes an action on a turn its author believed was read-only.

    The CLEAN here is worth stating carefully, because without a control it
    would be vacuous. "No tool call came back when I sent none" is satisfied by
    a model that simply did not want to call, which is the empty-set shape
    CONTRIBUTING names. So this runs a positive control FIRST: the same
    tool-inviting prompt with no tool_choice at all. Only if that control
    actually produces a call does the suppression in the none-arm mean
    anything, and only then can this emit CLEAN.
    """
    ctrl_st, ctrl_choice, _ = chat(
        doc, base, key, doc.model,
        [{"role": "user", "content": "What time is it in Tokyo? Use the tool."}],
        max_tokens=256, tools=TOOLS)
    if ctrl_st != 200 or ctrl_choice is None:
        doc.inconclusive(["78"], "tool_choice gate",
                         f"the control request (tools attached, no tool_choice) "
                         f"did not return a usable completion (http {ctrl_st}), "
                         f"so there is nothing to gate against.",
                         code="TOOL_CHOICE_NO_CONTROL",
                         asserts=[A("control returns a completion",
                                    {"status": ctrl_st}, held=False)])
        return
    _, _, _, ctrl_calls, _ = msg_fields(ctrl_choice)

    none_st, none_choice, _ = chat(
        doc, base, key, doc.model,
        [{"role": "user", "content": "What time is it in Tokyo? Use the tool."}],
        max_tokens=256, tools=TOOLS, tool_choice="none")
    doc.evidence["tool_choice_none_status"] = none_st

    if none_st != 200 or none_choice is None:
        # A server that REJECTS tool_choice:none is not this trap. It is loud,
        # which is the opposite failure and a safe one.
        doc.ok(["78"], f"tool_choice none is rejected outright (http {none_st}), "
                       f"so it cannot be silently ignored on this lane",
               code="TOOL_CHOICE_REJECTED",
               asserts=[A("tool_choice none is not silently accepted",
                          {"status": none_st})])
        return
    _, _, _, none_calls, _ = msg_fields(none_choice)

    if not ctrl_calls:
        doc.inconclusive(["78"], "tool_choice gate",
                         "the control request did not produce a tool call, so "
                         "an absence of calls under tool_choice none proves "
                         "nothing: the model may simply not have called either "
                         "way. Re-run with a prompt this model reliably calls "
                         "on, or force one with a named tool_choice first.",
                         code="TOOL_CHOICE_NO_CONTROL",
                         asserts=[A("control produces a tool call",
                                    {"tool_calls": len(ctrl_calls)}, held=False)])
        return

    if none_calls:
        doc.problem(
            ["78"],
            "tool_choice none was accepted and ignored: a control with tools "
            "and no tool_choice called a tool, and the identical request with "
            "tool_choice none called one too",
            "Do not rely on tool_choice to gate a turn on this lane. The only "
            "control that works everywhere is to omit the tools payload on "
            "turns where a call must not happen. This fails OPEN, so an agent "
            "loop with a side-effecting tool can act on a turn you believed "
            "was read-only.",
            code="TOOL_CHOICE_IGNORED",
            asserts=[A("control produces a tool call",
                       {"tool_calls": len(ctrl_calls)}),
                     A("tool_choice none suppresses the call",
                       {"tool_calls": len(none_calls)}, held=False)])
        return

    doc.ok(["78"],
           "tool_choice none binds: a control with tools and no tool_choice "
           "called a tool, and the identical request with tool_choice none did "
           "not, so the suppression is attributable to the parameter",
           code="TOOL_CHOICE_NONE_BINDS",
           asserts=[A("control produces a tool call",
                      {"tool_calls": len(ctrl_calls)}),
                    A("tool_choice none suppresses it",
                      {"tool_calls": len(none_calls)})])


def check_reasoning_effort_switch(doc, base, key):
    """Trap 58: top-level reasoning_effort can enable thinking and rewrite prompt."""
    messages = [{"role": "user", "content": "Hi. Reply briefly."}]
    arms = {}
    for name, extra in (
        ("baseline", {}),
        ("low", {"reasoning_effort": "low"}),
        ("max", {"reasoning_effort": "max"}),
    ):
        st, choice, raw = chat(doc, base, key, doc.model, messages,
                               max_tokens=16, **extra)
        if st != 200 or choice is None or not isinstance(raw, dict):
            arms[name] = {"status": st}
            continue
        content, rc, rr, _tc, _m = msg_fields(choice)
        usage = raw.get("usage") or {}
        arms[name] = {
            "status": st,
            "prompt_tokens": usage.get("prompt_tokens"),
            "reasoning_len": len(rc) + len(rr),
            "content_len": len(content),
        }
    doc.evidence["reasoning_effort_arms"] = arms
    base_arm, low_arm, max_arm = arms["baseline"], arms["low"], arms["max"]
    if base_arm.get("status") != 200:
        doc.skip(["58"], "reasoning_effort switch",
                 "baseline completion failed, so effort-arm behavior is not attributable",
                 code="EFFORT_NO_BASELINE",
                 asserts=[A("baseline completion succeeds", base_arm, held=False)])
        return
    if low_arm.get("status") != 200 and max_arm.get("status") != 200:
        doc.ok(["58"], "top-level reasoning_effort is rejected on this lane; it "
               "cannot silently enable reasoning or inject a hidden preamble",
               code="EFFORT_REJECTED",
               asserts=[A("both reasoning_effort probe values are rejected",
                          {"low": low_arm.get("status"), "max": max_arm.get("status")})])
        return
    base_reason = int(base_arm.get("reasoning_len") or 0)
    changed = []
    for name, arm in (("low", low_arm), ("max", max_arm)):
        if arm.get("status") != 200:
            continue
        if int(arm.get("reasoning_len") or 0) > base_reason:
            changed.append(f"{name}:reasoning")
        bpt, apt = base_arm.get("prompt_tokens"), arm.get("prompt_tokens")
        if isinstance(bpt, int) and isinstance(apt, int) and apt > bpt + 8:
            changed.append(f"{name}:prompt_tokens")
    if changed:
        doc.problem(
            ["58"],
            f"top-level reasoning_effort changes the served request ({', '.join(changed)}); "
            f"arms={arms}",
            "Treat reasoning_effort as a prompt/budget-changing switch on this lane. "
            "Strip it at the gateway unless deliberately qualified.",
            code="EFFORT_CHANGES_PROMPT_OR_REASONING",
            asserts=[A("reasoning_effort leaves reasoning state and prompt usage "
                       "unchanged from baseline", arms, held=False)])
    else:
        doc.inconclusive(
            ["58"], "reasoning_effort switch",
            f"the field was accepted but this bounded probe saw no visible reasoning "
            f"or prompt-token change: {arms}. Acceptance alone cannot prove it is inert.",
            code="EFFORT_ACCEPTED_NO_VISIBLE_EFFECT",
            asserts=[A("accepted field is proven inert by one bounded probe",
                       arms, held=False)])


def _cached_tokens(raw):
    if not isinstance(raw, dict):
        return None
    usage = raw.get("usage") or {}
    for key in ("cached_tokens", "cache_n"):
        value = usage.get(key)
        if isinstance(value, int):
            return value
    details = usage.get("prompt_tokens_details")
    if isinstance(details, dict):
        value = details.get("cached_tokens")
        if isinstance(value, int):
            return value
    return None


def check_cache_prompt_isolation(doc, base, key):
    """Trap 88: llama.cpp cache_prompt:false isolation is build-specific."""
    if doc.stack != "llama.cpp":
        doc.skip(["88"], "cache_prompt isolation",
                 f"trap 88 is scoped to llama.cpp; detected stack={doc.stack!r}",
                 code="CACHE_PROMPT_SCOPE_NOT_LLAMACPP",
                 asserts=[A("detected stack is llama.cpp", doc.stack, held=False)])
        return
    prefix = "shared-prefix " * 64
    messages = [{"role": "user", "content": prefix + "answer OK"}]
    arms = []
    for label, extra in (
        ("warm", {}),
        ("isolated", {"cache_prompt": False}),
        ("reuse_after", {}),
    ):
        st, choice, raw = chat(doc, base, key, doc.model, messages,
                               max_tokens=8, **extra)
        arms.append({"label": label, "status": st, "cached_tokens": _cached_tokens(raw)})
    doc.evidence["cache_prompt_arms"] = arms
    if any(row["status"] != 200 or row["cached_tokens"] is None for row in arms):
        doc.skip(["88"], "cache_prompt isolation",
                 f"all three requests must return a cached-token counter; observed {arms}",
                 code="CACHE_PROMPT_COUNTER_UNAVAILABLE",
                 asserts=[A("all three cache arms return cached-token counters",
                            arms, held=False)])
        return
    isolated, after = arms[1]["cached_tokens"], arms[2]["cached_tokens"]
    if isolated == 0 and after > 0:
        doc.ok(["88"],
               f"cache_prompt:false isolated the request (cached_tokens=0) and the "
               f"next default request still reused the prefix ({after} cached tokens)",
               code="CACHE_PROMPT_FALSE_ISOLATES",
               asserts=[A("isolated request has zero cached tokens and following "
                          "default request still has a cache hit", arms)])
    elif isolated > 0:
        doc.problem(["88"],
                    f"cache_prompt:false still reused {isolated} cached tokens on this "
                    "llama.cpp lane; trap 88's b9878 behavior does not generalize here",
                    "Treat cache isolation as build-specific and use the observed "
                    "cached-token counter, not the flag name, as proof.",
                    code="CACHE_PROMPT_FALSE_REUSED",
                    asserts=[A("cache_prompt:false request has zero cached tokens",
                               arms, held=False)])
    else:
        doc.inconclusive(["88"], "cache_prompt isolation",
                         f"the isolated arm was cold but the following default arm did "
                         f"not prove cache survival: {arms}",
                         code="CACHE_PROMPT_SURVIVAL_UNPROVEN",
                         asserts=[A("following default request reuses the warmed prefix",
                                    arms, held=False)])


def check_ceiling(doc, base, key):
    """Traps 12/16/22: empty content at cap, degeneration vs truncation."""
    st, choice, _ = chat(doc, base, key, doc.model,
                         [{"role": "user", "content":
                           "Write a python function that validates RFC3339 "
                           "timestamps without external libraries, with tests."}],
                         max_tokens=512,
                         chat_template_kwargs={"enable_thinking": True})
    if st != 200 or choice is None:
        doc.skip(["12", "16", "22"], "ceiling probe", f"request failed (http {st})",
                 code="CEILING_PROBE_FAILED",
                 asserts=[A("ceiling probe returns 200", st, held=False)])
        return
    # Trap 22 is a cross-size, cross-budget comparison: the conversion floor is
    # a DISTRIBUTION, and this tool sends one request at one budget to one
    # model. It is never settled here, in either direction, so say so once and
    # never tag a 22 verdict onto the single-probe finding below.
    doc.skip(["22"], "per-size budget floor",
             "trap 22 is a claim about where THIS model size converts reasoning "
             "into content, and a floor is a distribution, not a threshold: the "
             "registry's own production replication has a 27B convert 0/3 at "
             "8192 and only 2/3 at 16384, so it still fails 1 in 3 at a budget "
             "where it also succeeds. This tool sends ONE request at ONE budget "
             "(max_tokens=512) to ONE model, which cannot characterise a "
             "distribution and cannot compare sizes. Whatever the probe below "
             "reports, it is not a trap-22 result. Run the multi-budget, "
             "multi-sample procedure in the trap 22 entry against every size "
             "you serve.",
             code="BUDGET_FLOOR_NOT_CHARACTERISED",
             asserts=[A("the ceiling probe sweeps more than one token budget",
                        {"budgets_probed": [512], "samples_per_budget": 1},
                        held=False)])

    c, rc, rr, _t, _ = msg_fields(choice)
    fr = choice.get("finish_reason")
    reason = rc or rr
    has_content = bool(c.strip())
    if fr == "length" and not has_content:
        lines = [l for l in reason.splitlines() if l.strip()]
        uniq = len(set(lines)) / max(1, len(lines))
        z = len(zlib.compress(reason.encode())) / max(1, len(reason))
        degenerate = not (uniq > 0.5 and z > 0.2)
        kind = "possible degeneration loop" if degenerate else "honest truncation"
        doc.problem(["12"],
                    f"hard task at max_tokens=512: HTTP 200, finish=length, "
                    f"EMPTY content, {len(reason)} chars of reasoning "
                    f"({kind}: unique-line {uniq:.2f}, zlib {z:.2f}). If your "
                    f"harness scores this zero, it is measuring your budget",
                    "bucket cap-hits before scoring; find THIS model's "
                    "conversion floor (family advice does not transfer)",
                    code="EMPTY_CONTENT_AT_CAP",
                    asserts=[A("a cap-hitting response carries content",
                               {"finish_reason": fr, "content_chars": len(c)},
                               held=False)])
        if degenerate:
            # An annotation on the finding above, not a second verdict, and
            # deliberately not tagged onto trap 16: trap 16 is about scoring
            # finish_reason, which the PROBLEM above already covers.
            doc.inconclusive(["12"], "reasoning text at the cap looks repetitive",
                             f"the reasoning returned at the cap has "
                             f"unique-line {uniq:.2f} and zlib ratio {z:.2f}, "
                             f"which is the shape of a degeneration loop rather "
                             f"than an answer that ran out of room. This is a "
                             f"two-number heuristic over one sample and it does "
                             f"NOT establish degeneration: a genuinely "
                             f"repetitive task produces the same shape. Re-run "
                             f"at a higher budget and read the trace before "
                             f"concluding either way.",
                             code="CAP_REASONING_LOOKS_DEGENERATE",
                             asserts=[A("repetition was distinguished from a "
                                        "repetitive task by more than a "
                                        "two-number heuristic on one sample",
                                        {"unique_line_ratio": round(uniq, 2),
                                         "zlib_ratio": round(z, 2),
                                         "samples": 1}, held=False)])
    elif has_content and fr == "length":
        # The cap WAS reached and content came back anyway. That is the only
        # observation on this probe that rules the trap-12 failure mode out,
        # because the failure mode is specifically "cap hit, content empty".
        doc.ok(["12"], f"hard task at max_tokens=512: the cap WAS reached "
               f"(finish=length) and content came back anyway ({len(c)} chars), "
               f"so this lane converts reasoning into content at this budget. "
               f"Scoped to this budget and this one sample",
               code="CONTENT_PRESENT_AT_CAP_HIT",
               asserts=[A("the probe reached the token cap",
                          {"finish_reason": fr}),
                        A("a cap-hitting response carries content",
                          {"content_chars": len(c)})])
    elif has_content:
        # Content present, but the cap was never reached, so the empty-at-cap
        # failure mode was never exercised. The old code called this CLEAN.
        # A request that finished early is not a negative for a defect that
        # only appears when the budget runs out.
        doc.inconclusive(["12"], "empty content at the token ceiling",
                         f"the probe returned {len(c)} chars of content with "
                         f"finish_reason={fr!r}, so it never reached the cap at "
                         f"all. Trap 12's failure mode is content going EMPTY "
                         f"when the budget runs out, and a request that "
                         f"finished early does not exercise it. This is not a "
                         f"negative result, it is an untested one, and one "
                         f"sample at one budget could not settle it even if it "
                         f"had hit the cap: the registry's own data has a model "
                         f"fail 1 in 3 at a budget where it also passes. Run "
                         f"the multi-sample budget probe in the trap 12 entry "
                         f"before recording this lane as clean.",
                         code="CEILING_NOT_REACHED",
                         asserts=[A("the probe reached the token cap, so the "
                                    "empty-at-cap failure mode was exercised",
                                    {"finish_reason": fr,
                                     "content_chars": len(c)}, held=False)])
    else:
        # Empty content that did NOT hit the cap. The old code called this
        # clean because it only tested for finish=length. An empty answer is
        # never a clean result, and it is exactly the trap-16 shape: the exit
        # reason says nothing went wrong while nothing was produced.
        doc.inconclusive(["12", "16"], "empty content on the ceiling probe",
                         f"the response carried NO content ({len(reason)} chars "
                         f"of reasoning) yet finish_reason={fr!r}, not 'length'. "
                         f"This is not a cap hit and it is not a clean answer. "
                         f"Candidate causes this probe cannot separate: the "
                         f"answer landed entirely in the reasoning channel "
                         f"(trap 23), a stop string fired early, the parser "
                         f"consumed the answer, or the model genuinely returned "
                         f"nothing. A harness scoring this run would record a "
                         f"zero for a request the server called successful.",
                         code="EMPTY_CONTENT_NOT_AT_CAP",
                         asserts=[A("the ceiling probe returns non-empty content",
                                    {"finish_reason": fr, "content_chars": 0,
                                     "reasoning_chars": len(reason)}, held=False)])


# ------------------------------------------------------- huggingface configs

def hf_resolve_revision(repo, revision):
    """Resolve a revision (branch, tag, or sha) to an immutable commit sha.

    Without this the doctor always read `resolve/main`, so an operator serving
    a pinned older revision was compared against today's mutable main and told
    they had drift that does not exist on the checkpoint they are running.
    Returns (sha_or_None, note).
    """
    st, txt = get(f"{HF_BASE}/api/models/{repo}/revision/{revision}")
    if st == 200:
        try:
            sha = json.loads(txt).get("sha")
            if sha:
                return sha, f"resolved {revision!r} to commit {sha}"
        except Exception:
            pass
    return None, (f"could not resolve {revision!r} to a commit sha "
                  f"(hub API http {st}); files below were read at the mutable "
                  f"ref {revision!r}, which can change under you")


def check_configs(doc, hf_repo, hf_revision="main"):
    """Traps 21 (generation_config missing), 17 (defaults vs card), 10 (quant)."""
    props = doc.evidence.get("props")
    eff = None #always none unless props and p
    if props:
        p = (props.get("default_generation_settings") or {}).get("params", {})
        if p is not None:
            eff = {k: round(v, 3) if isinstance(v, float) else v
                   for k, v in p.items()
                   if k in ("temperature", "top_k", "top_p", "min_p", "presence_penalty")}
            doc.evidence["server_defaults"] = eff
    if not hf_repo:
        doc.skip(["21", "17", "10"], "generation_config / card-sampling / quant "
                 "scheme checks",
                 "pass --hf-repo org/name to compare against the checkpoint's "
                 "shipped configs (and --hf-revision if you serve a pinned "
                 "revision rather than main)",
                 code="NO_HF_REPO",
                 asserts=[A("--hf-repo supplied", None, held=False)])
        return

    sha, note = hf_resolve_revision(hf_repo, hf_revision)
    ref = sha or hf_revision
    pinned = bool(sha)
    doc.evidence["hf"] = {"repo": hf_repo, "requested_revision": hf_revision,
                          "resolved_commit": sha, "read_at_ref": ref,
                          "note": note}
    scope = (f"{hf_repo} @ {hf_revision}"
             + (f" (commit {sha[:12]})" if sha else " (UNRESOLVED ref)"))
    rev_assert = A("the requested revision resolved to an immutable commit",
                   {"requested": hf_revision, "resolved": sha}, held=pinned)
    if not pinned:
        doc.inconclusive(["21", "17", "10"], f"revision pinning for {hf_repo}",
                         note + ". Every config comparison below is against a "
                         "ref that can move, so a reported difference may be "
                         "drift in the hub rather than in your lane. Re-run "
                         "with --hf-revision <commit sha> to make the "
                         "comparison reproducible.",
                         code="HF_REVISION_UNRESOLVED",
                         asserts=[rev_assert])

    base_url = f"{HF_BASE}/{hf_repo}/resolve/{ref}"

    st, txt = get(f"{base_url}/generation_config.json")
    if st == 200:
        try:
            gc = json.loads(txt)
            doc.ok(["21"], f"generation_config.json exists on {scope} "
                   f"(keys: {sorted(gc.keys())[:6]})",
                   code="GENERATION_CONFIG_PRESENT",
                   asserts=[rev_assert,
                            A("generation_config.json is readable at the "
                              "compared revision", {"ref": ref, "status": st})])
            if eff:
                shared = [k for k in eff if k in gc]
                diffs = {k: (eff.get(k), gc.get(k)) for k in shared
                         if not _close(eff.get(k), gc.get(k))}
                if diffs:
                    doc.problem(["17"], f"server defaults differ from the "
                                f"generation_config shipped at {scope}: {diffs} "
                                f"(server, checkpoint)",
                                "set sampling explicitly per request; never "
                                "describe a run as 'model defaults' across stacks",
                                code="SAMPLING_DEFAULTS_DIFFER",
                                asserts=[rev_assert,
                                         A("server defaults equal the checkpoint's "
                                           "generation_config on every shared key",
                                           {"compared": shared, "diffs": diffs},
                                           held=False)])
                elif shared:
                    doc.ok(["17"], f"server defaults match the generation_config "
                           f"shipped at {scope} on every key both sides declare "
                           f"({', '.join(shared)}); keys only one side declares "
                           f"were not compared",
                           code="SAMPLING_DEFAULTS_MATCH",
                           asserts=[rev_assert,
                                    A("server defaults equal the checkpoint's "
                                      "generation_config on every shared key",
                                      {"compared": shared,
                                       "server_only": sorted(set(eff) - set(gc)),
                                       "checkpoint_only": sorted(
                                           k for k in gc if k in
                                           ("temperature", "top_k", "top_p",
                                            "min_p", "presence_penalty")
                                           and k not in eff)})])
                else:
                    doc.skip(["17"], "server defaults vs shipped generation_config",
                             f"the server publishes {sorted(eff)} and the "
                             f"checkpoint's generation_config declares "
                             f"{sorted(gc)}; the two sets do not overlap, so "
                             f"there is nothing to compare and no basis for "
                             f"calling the sampling aligned",
                             code="SAMPLING_NO_SHARED_KEYS",
                             asserts=[rev_assert,
                                      A("server and checkpoint declare at least "
                                        "one common sampling key",
                                        {"server": sorted(eff),
                                         "checkpoint": sorted(gc)}, held=False)])
            else:
                doc.skip(["17"], "server defaults vs shipped generation_config",
                         "this stack publishes no effective sampling defaults "
                         "(llama.cpp /props is the only source this tool has), "
                         "so the checkpoint's generation_config cannot be "
                         "compared against what your server will actually use",
                         code="SERVER_DEFAULTS_UNREADABLE",
                         asserts=[rev_assert,
                                  A("the server publishes its effective sampling "
                                    "defaults", None, held=False)])
        except Exception:
            doc.skip(["21", "17"], "generation_config parse", "unparseable JSON",
                     code="GENERATION_CONFIG_UNPARSEABLE",
                     asserts=[rev_assert,
                              A("generation_config.json parses as JSON", txt[:120],
                                held=False)])
    elif st == 404:
        detail = (f"{scope} ships NO generation_config.json: there is no such "
                  f"thing as 'model defaults' on this checkpoint")
        if eff:
            detail += f"; you are silently running your server's built-ins: {eff}"
        doc.problem(["21"], detail,
                    "take sampling from the card's prose, per mode, and set it "
                    "explicitly on every request",
                    code="NO_GENERATION_CONFIG",
                    asserts=[rev_assert,
                             A("the checkpoint ships generation_config.json",
                               {"ref": ref, "status": 404}, held=False)])
        doc.skip(["17"], "server defaults vs shipped generation_config",
                 "there is no shipped generation_config at this revision to "
                 "compare against",
                 code="SAMPLING_NO_BASELINE",
                 asserts=[rev_assert])
    else:
        doc.skip(["21", "17"], "generation_config fetch",
                 f"http {st} from the hub at {scope}",
                 code="GENERATION_CONFIG_FETCH_FAILED",
                 asserts=[rev_assert,
                          A("generation_config.json is readable at the compared "
                            "revision", {"ref": ref, "status": st}, held=False)])

    st, txt = get(f"{base_url}/config.json")
    if st == 200:
        try:
            cfg = json.loads(txt)
            qc = cfg.get("quantization_config")
            if qc:
                # A manifest proves the checkpoint is LABELLED. Trap 10's
                # failure mode is the engine taking a different kernel path
                # from the one the label implies, and no file on the hub can
                # rule that out. This used to be CLEAN while its own prose
                # said "the label is not the kernel path".
                doc.inconclusive(["10"], f"quantisation scheme at {scope}",
                                 f"config.json declares quantization_config: "
                                 f"method={qc.get('quant_method')}, ignore list "
                                 f"{'present' if qc.get('ignore') else 'ABSENT'}. "
                                 f"That establishes what the checkpoint is "
                                 f"LABELLED, and nothing more. Trap 10 is about "
                                 f"the engine taking a different kernel path "
                                 f"from the one the label implies, and this "
                                 f"check reads files on the hub, never your "
                                 f"running engine, so it cannot tell a fast "
                                 f"format-matched path from a slow fallback "
                                 f"wearing the same name. Settle it with a "
                                 f"RUNTIME tell: grep the engine's "
                                 f"backend-selection log for the kernel it "
                                 f"actually chose, or measure decode throughput "
                                 f"against an f16 baseline of the same model, or "
                                 f"compare GPU utilisation against power draw. "
                                 f"Until one of those runs, the kernel path is "
                                 f"UNKNOWN.",
                                 code="QUANT_IN_CONFIG_JSON",
                                 asserts=[rev_assert,
                                          A("config.json declares "
                                            "quantization_config",
                                            {"quant_method": qc.get("quant_method"),
                                             "has_ignore": bool(qc.get("ignore"))}),
                                          A("a runtime tell confirms the engine "
                                            "took the kernel path the label "
                                            "implies",
                                            "no runtime tell is read by this "
                                            "check; it reads hub files only",
                                            held=False)])
            else:
                # ModelOpt and several other producers keep the manifest in a
                # sibling file. Reporting "unquantized checkpoint" as a CLEAN
                # result for a 4-bit checkpoint is exactly the false negative
                # trap 10 exists to prevent, so look before concluding.
                st2, txt2 = get(f"{base_url}/hf_quant_config.json")
                if st2 == 200:
                    try:
                        hq = json.loads(txt2)
                        qc2 = hq.get("quantization") or hq
                        doc.inconclusive(
                            ["10"], f"quantisation scheme at {scope} "
                            f"(manifest outside config.json)",
                            f"quantisation is declared in "
                            f"hf_quant_config.json, NOT in config.json "
                            f"(quant_algo={qc2.get('quant_algo')}, "
                            f"producer={qc2.get('producer') or hq.get('producer')}). "
                            f"Locating that manifest is a real result: tooling "
                            f"that only reads config.json will call this "
                            f"checkpoint unquantized. It is still only the "
                            f"LABEL. Trap 10 is about the engine taking a "
                            f"different kernel path from the one the label "
                            f"implies, and this check reads hub files, never "
                            f"your running engine. A compressed-tensors "
                            f"NVFP4 or MXFP4 checkpoint routing to a slow "
                            f"marlin fallback carries exactly this manifest. "
                            f"Settle it with a RUNTIME tell: grep the engine's "
                            f"backend-selection log for the kernel it actually "
                            f"chose, or measure decode throughput against an "
                            f"f16 baseline of the same model, or compare GPU "
                            f"utilisation against power draw. Until one of "
                            f"those runs, the kernel path is UNKNOWN.",
                            code="QUANT_IN_HF_QUANT_CONFIG",
                            asserts=[rev_assert,
                                     A("the quantisation manifest was located",
                                       {"config.json": False,
                                        "hf_quant_config.json": True}),
                                     A("hf_quant_config.json declares the scheme",
                                       {"quant_algo": qc2.get("quant_algo")}),
                                     A("a runtime tell confirms the engine took "
                                       "the kernel path the label implies",
                                       "no runtime tell is read by this check; "
                                       "it reads hub files only", held=False)])
                    except Exception:
                        doc.skip(["10"], "hf_quant_config.json parse",
                                 "present but unparseable; quantisation scheme UNKNOWN",
                                 code="QUANT_MANIFEST_UNPARSEABLE",
                                 asserts=[rev_assert,
                                          A("hf_quant_config.json parses as JSON",
                                            txt2[:120], held=False)])
                else:
                    doc.skip(["10"], "quantisation scheme",
                             f"no quantization_config in config.json and no "
                             f"hf_quant_config.json either at {scope}. This may "
                             f"be an unquantized checkpoint, or the manifest may "
                             f"live somewhere this check does not look. UNKNOWN, "
                             f"not clean",
                             code="QUANT_SCHEME_UNKNOWN",
                             asserts=[rev_assert,
                                      A("config.json declares quantization_config",
                                        None, held=False),
                                      A("hf_quant_config.json exists",
                                        {"status": st2}, held=False)])
        except Exception:
            doc.skip(["10"], "config.json parse", "unparseable JSON",
                     code="CONFIG_JSON_UNPARSEABLE",
                     asserts=[rev_assert,
                              A("config.json parses as JSON", txt[:120], held=False)])
    else:
        doc.skip(["10"], "config.json fetch", f"http {st} at {scope}",
                 code="CONFIG_JSON_FETCH_FAILED",
                 asserts=[rev_assert,
                          A("config.json is readable at the compared revision",
                            {"ref": ref, "status": st}, held=False)])


def _close(a, b):
    try:
        return abs(float(a) - float(b)) < 1e-3
    except Exception:
        return a == b

# ------------------------------------------------------------------ coverage

def coverage(doc):
    """What this run actually touched, so a clean run cannot be read as a
    broad bill of health over the registry."""
    implemented = set(TRAP_PATHS)
    prob = doc.trap_ids("PROBLEM")
    clean = doc.trap_ids("OK") - prob
    unsure = (doc.trap_ids("INCONCLUSIVE") | doc.trap_ids("UNKNOWN")) - prob - clean
    executed = prob | clean
    return {
        "registry_total": REGISTRY_TRAP_COUNT,
        "implemented": sorted(implemented),
        "executed": sorted(executed),
        "clean": sorted(clean),
        "problems": sorted(prob),
        "inconclusive": sorted(unsure),
        "not_implemented_count": REGISTRY_TRAP_COUNT - len(implemented),
        "shared_heuristic": TRAPS_SHARED_HEURISTIC,
        "never_clean": TRAPS_NEVER_CLEAN,
        "advisory": sorted(ADVISORY_IDS),
        "need_hf_repo": sorted(TRAPS_NEED_HF_REPO),
        "need_render_path": sorted(TRAPS_NEED_RENDER_PATH),
        "core_total": sorted(CORE_TRAP_IDS),
        "core_implemented": sorted(CORE_TRAP_IDS & implemented),
        "core_executed": sorted(CORE_TRAP_IDS & executed),
        "core_not_implemented": sorted(CORE_TRAP_IDS - implemented),
    }


def coverage_line(cov):
    return (f"implemented {len(cov['implemented'])}/{cov['registry_total']} | "
            f"executed on this stack {len(cov['executed'])} | "
            f"clean {len(cov['clean'])} | problems {len(cov['problems'])} | "
            f"inconclusive {len(cov['inconclusive'])} | "
            f"not implemented {cov['not_implemented_count']}")

# ------------------------------------------------------------------ output

def emit(doc, args):
    def T(ns):
        out = []
        for n in ns:
            if n in TRAP_PATHS:
                out.append(f"[trap {n}]({trap(n)})")
            elif n in ADVISORY_IDS:
                # Not a numbered entry. Say so on the line itself, so nobody
                # goes looking for a trap file or a README row that does not
                # exist, and so an advisory PROBLEM is not mistaken for a
                # registry-backed one.
                out.append(f"{n} (advisory, not in the registry: "
                           f"{ADVISORY_IDS[n]})")
            else:
                out.append(f"[registry draft: {n}]({trap(n)})")
        return " ".join(out)
    print(f"\nminefield-doctor: {args.base_url}")
    print(f"stack={doc.stack} model={doc.model} build={doc.build or 'n/a'} "
          f"requests_made={doc.requests_made}\n")

    print(f"== PROBLEMS ({len(doc.problems)}) ==")
    for f in doc.problems:
        print(f"  ! {f['title']}\n    fix: {f['detail']}\n    see: {T(f['traps'])}")
    if not doc.problems:
        print("  none found by the checks that ran")

    print(f"\n== CHECKED AND CLEAN ({len(doc.clean)}) ==")
    for f in doc.clean:
        print(f"  + {f['title']}\n    see: {T(f['traps'])}")
    if not doc.clean:
        print("  nothing reached a clean verdict on this stack")

    print(f"\n== INCONCLUSIVE ({len(doc.unsure)}) ==")
    print("  (the probe ran, but the result is consistent with several "
          "materially\n   different states; this is NOT a clean result)")
    for f in doc.unsure:
        print(f"  ~ {f['title']}\n    why: {f['detail']}\n    see: {T(f['traps'])}")
    if not doc.unsure:
        print("  none")

    print(f"\n== COULD NOT CHECK ({len(doc.blocked)}) ==")
    for f in doc.blocked:
        print(f"  ? {f['title']}\n    why: {f['detail']}\n    see: {T(f['traps'])}")
    if not doc.blocked:
        print("  every check ran")

    cov = coverage(doc)
    print("\n== COVERAGE ==")
    print(f"  {coverage_line(cov)}")
    print(f"  counted over trap ids, against a registry of "
          f"{cov['registry_total']} numbered entries.")
    print(f"  executed = a trap id that received a CLEAN or PROBLEM verdict on "
          f"this run.")
    print(f"  implemented ids: {', '.join(cov['implemented'])}")
    if cov["problems"]:
        print(f"  problems on: {', '.join(cov['problems'])}")
    if cov["inconclusive"]:
        print(f"  inconclusive or unchecked: {', '.join(cov['inconclusive'])}")
    print(f"  Core tier ({len(cov['core_total'])} entries, see CORE.md): "
          f"implemented here {', '.join(cov['core_implemented'])}; "
          f"executed on this run "
          f"{', '.join(cov['core_executed']) or 'none'}.")
    print(f"    Core entries with NO check in this tool, and therefore yours "
          f"to run by hand: {', '.join(cov['core_not_implemented'])}. "
          f"Findings above are printed Core first within each bucket.")
    print("  caveats on the implemented count, so it is not read as depth:")
    for n, why in sorted(cov["shared_heuristic"].items()):
        print(f"    - {n}: {why}")
    for n, why in sorted(cov["never_clean"].items()):
        print(f"    - {n}: NEVER REACHES CLEAN. {why}")
    print(f"    - {', '.join(cov['need_hf_repo'])}: need --hf-repo; without it "
          f"they cannot run at all")
    print(f"    - {', '.join(cov['need_render_path'])}: need a render path; on a "
          f"stack with none they cannot run at all")
    print(f"  advisory checks, counted nowhere above because they are NOT "
          f"numbered registry entries: {', '.join(cov['advisory'])}. They can "
          f"report a PROBLEM or a CLEAN of their own, and there is no trap file "
          f"or README row behind any of them.")
    unaccounted = sorted(set(cov["implemented"])
                         - set(cov["executed"]) - set(cov["inconclusive"]))
    if unaccounted:
        print("  implemented but NOT exercised on this run, in either "
              "direction: " + ", ".join(unaccounted))
        print("    a check exists for these and this run gave them no verdict, "
              "clean or otherwise. They are not covered by anything above.")
    print(f"  the remaining {cov['not_implemented_count']} numbered traps have "
          f"no check in this tool. A clean run above is a statement about "
          f"{len(cov['clean'])} trap ids, not about the registry.")

    if args.report:
        print("\n== PASTE-READY REPORT (for an 'I hit a trap' issue) ==\n")
        print("```markdown")
        print("**What were you serving**")
        print(f"- stack: {doc.stack} ({doc.build or 'build unknown'})")
        print(f"- model: {doc.model}")
        print("- endpoint: (host redacted by doctor; add server flags yourself)")
        print(f"- doctor coverage: {coverage_line(cov)}")
        print(f"- doctor findings ({len(doc.problems)} problem(s)):")
        for f in doc.problems:
            print(f"  - {f['title']} (traps {', '.join(f['traps'])})")
        if doc.unsure:
            print(f"- inconclusive ({len(doc.unsure)}):")
            for f in doc.unsure:
                print(f"  - {f['title']} (traps {', '.join(f['traps'])})")
        print("\n**What broke / what you saw**\n<your words here>")
        print("\n**What fixed it**\n<if anything>")
        print("```")


# ------------------------------------------------------------------ probe catalog
# Executable Doctor probes with planning metadata for the reusable library API.
# Trap markdown remains documentation-only; these call first-party check_* fns.
# request_cost is the MAX chat completions a probe may issue (planning ceiling).

class ProbeSpec:
    __slots__ = (
        "id", "traps", "request_cost", "lite_eligible", "lite_priority",
        "requires", "invoke", "title",
    )

    def __init__(self, id, traps, request_cost, lite_eligible, lite_priority,
                 requires, invoke, title):
        self.id = id
        self.traps = tuple(traps)
        self.request_cost = int(request_cost)
        self.lite_eligible = bool(lite_eligible)
        self.lite_priority = int(lite_priority)
        self.requires = tuple(requires)
        self.invoke = invoke
        self.title = title


def _probe_generation_readiness(doc, base, root, args):
    check_generation_readiness(doc, base, args.api_key)


def _probe_toggle_conflict_routing(doc, base, root, args):
    check_toggle_conflict_routing(doc, base, args.api_key)


def _probe_parser_nonempty_rescue(doc, base, root, args):
    check_parser_nonempty_rescue(doc, base, args.api_key)


def _probe_thinking_json_schema(doc, base, root, args):
    check_thinking_json_schema(doc, base, args.api_key)


def _probe_output_token_accounting(doc, base, root, args):
    check_output_token_accounting(doc, base, root, args.api_key)


def _probe_post_tool_empty_reasoning_usage(doc, base, root, args):
    check_post_tool_empty_reasoning_usage(doc, base, args.api_key)


def _probe_tool_schema_render(doc, base, root, args):
    check_tool_schema_render(doc, root, args.api_key)


def _probe_python_encoder_role_welding(doc, base, root, args):
    check_python_encoder_role_welding(doc, root, args.api_key)


def _probe_reasoning_replay_visibility(doc, base, root, args):
    check_reasoning_replay_visibility(doc, root, args.api_key)


def _probe_clock_prompt_prefix(doc, base, root, args):
    check_clock_prompt_prefix(doc, root, args.api_key)


def _probe_ling_thinking_field_placement(doc, base, root, args):
    check_ling_thinking_field_placement(doc, base, args.api_key)


def _probe_structured_json_duplication(doc, base, root, args):
    check_structured_json_duplication(doc, base, args.api_key)


def _probe_unicode_tool_serialization(doc, base, root, args):
    check_unicode_tool_serialization(doc, root, args.api_key)


def _probe_declared_server_token_cap(doc, base, root, args):
    check_declared_server_token_cap(doc, base, args)


def _probe_thinking_budget_marker_ids(doc, base, root, args):
    check_thinking_budget_marker_ids(doc, root, args)


def _probe_prefix_slot_residency(doc, base, root, args):
    check_prefix_slot_residency(doc, base, args.api_key)


def _probe_ngram_async_scheduling(doc, base, root, args):
    check_ngram_async_scheduling(doc, root, args.api_key)


def _probe_prompt_target_tokens(doc, base, root, args):
    check_prompt_target_tokens(doc, root, args.api_key, args)


def _probe_cache_hit_answer_consistency(doc, base, root, args):
    check_cache_hit_answer_consistency(doc, base, args.api_key)


def _probe_greedy_repetition_screen(doc, base, root, args):
    check_greedy_repetition_screen(doc, base, args.api_key)


def _probe_device_memory_reporting(doc, base, root, args):
    check_device_memory_reporting(doc, root, args.api_key)


def _probe_kv_cache_pressure(doc, base, root, args):
    check_kv_cache_pressure(doc, root, args.api_key)


def _probe_compilation_flag_resolution(doc, base, root, args):
    check_compilation_flag_resolution(doc, root, args.api_key)


def _probe_cudagraph_capture_clamp(doc, base, root, args):
    check_cudagraph_capture_clamp(doc, root, args.api_key)


def _probe_execution_concurrency_evidence(doc, base, root, args):
    check_execution_concurrency_evidence(doc, root, args.api_key)


def _probe_minicpm_short_answer_channel(doc, base, root, args):
    check_minicpm_short_answer_channel(doc, base, args.api_key)


def _probe_minicpm_processor_metadata(doc, base, root, args):
    check_minicpm_processor_metadata(doc, args)


def _probe_request_validation(doc, base, root, args):
    check_request_validation(doc, base, args.api_key)


def _probe_model_identity(doc, base, root, args):
    check_model_identity(doc, base, args.api_key)


def _probe_reasoning_fields(doc, base, root, args):
    check_reasoning_fields(doc, base, args.api_key)


def _probe_streaming(doc, base, root, args):
    check_streaming(doc, base, args.api_key)


def _probe_in_text_thinking_toggle(doc, base, root, args):
    check_in_text_thinking_toggle(doc, root, args.api_key)


def _probe_history_object_repr(doc, base, root, args):
    check_history_object_repr(doc, root, args.api_key)


def _probe_inline_system_role(doc, base, root, args):
    check_inline_system_role(doc, root, args.api_key)


def _probe_thinking_string_false(doc, base, root, args):
    check_thinking_string_false(doc, root, args.api_key)


def _probe_default_system_replacement(doc, base, root, args):
    check_default_system_replacement(doc, root, args.api_key)


def _probe_template_owned_think_open(doc, base, root, args):
    check_template_owned_think_open(doc, root, args.api_key)


def _probe_tool_argument_dialect(doc, base, root, args):
    check_tool_argument_dialect(doc, root, args.api_key)


def _probe_minor_template_boundaries(doc, base, root, args):
    check_minor_template_boundaries(doc, root, args.api_key)


def _probe_thinking_kwarg_type_gate(doc, base, root, args):
    check_thinking_kwarg_type_gate(doc, root, args.api_key)


def _probe_shared_endpoint_contention(doc, base, root, args):
    check_shared_endpoint_contention(doc, root, args.api_key)


def _probe_baked_default_system(doc, base, root, args):
    check_baked_default_system(doc, root, args.api_key)


def _probe_tool_roundtrip_followup(doc, base, root, args):
    check_tool_roundtrip_followup(doc, root, args.api_key)


def _probe_system_prompt_relocation(doc, base, root, args):
    check_system_prompt_relocation(doc, root, args.api_key)


def _probe_history_assembly(doc, base, root, args):
    check_history_assembly(doc, root, args.api_key)


def _probe_reasoning_roundtrip_shape(doc, base, root, args):
    check_reasoning_roundtrip_shape(doc, root, args.api_key)


def _probe_final_assistant_prefill(doc, base, root, args):
    check_final_assistant_prefill(doc, root, args.api_key)


def _probe_llamacpp_slot_context(doc, base, root, args):
    check_llamacpp_slot_context(doc, root, args.api_key)


def _probe_kwarg_deadness(doc, base, root, args):
    check_kwarg_deadness(doc, base, root, args.api_key)


def _probe_multimodal(doc, base, root, args):
    check_multimodal(doc, base, root, args.api_key)


def _probe_tools(doc, base, root, args):
    check_tools(doc, base, args.api_key)


def _probe_tool_choice_gate(doc, base, root, args):
    check_tool_choice_gate(doc, base, args.api_key)


def _probe_reasoning_effort_switch(doc, base, root, args):
    check_reasoning_effort_switch(doc, base, args.api_key)


def _probe_cache_prompt_isolation(doc, base, root, args):
    check_cache_prompt_isolation(doc, base, args.api_key)


def _probe_ceiling(doc, base, root, args):
    check_ceiling(doc, base, args.api_key)


def _probe_echo_logprobs(doc, base, root, args):
    check_echo_logprobs(doc, base, args.api_key)


def _probe_configs(doc, base, root, args):
    check_configs(doc, args.hf_repo, args.hf_revision)


# Order matches historical run(): validation first, then behavioural probes.
PROBE_SPECS = (
    ProbeSpec(
        "request_validation", ("77",), 2, True, 100, (),
        _probe_request_validation,
        "request-field validation (unknown field acceptance)",
    ),
    ProbeSpec(
        "toggle_conflict_routing", ("64",), 2, False, 30, (),
        _probe_toggle_conflict_routing,
        "answer field lost after /no_think text-marker conflict",
    ),
    ProbeSpec(
        "parser_nonempty_rescue", ("65",), 2, False, 15, (),
        _probe_parser_nonempty_rescue,
        "force_nonempty_content parser rescue at a demonstrated cap",
    ),
    ProbeSpec(
        "thinking_json_schema", ("149",), 2, False, 31, (),
        _probe_thinking_json_schema,
        "paired strict JSON schema on/off thinking controls",
    ),
    ProbeSpec(
        "output_token_accounting", ("156",), 1, False, 14, (),
        _probe_output_token_accounting,
        "retokenized text versus low completion usage at cap",
    ),
    ProbeSpec(
        "post_tool_empty_reasoning_usage", ("158",), 1, False, 13, (),
        _probe_post_tool_empty_reasoning_usage,
        "post-tool empty thought-channel token accounting",
    ),
    ProbeSpec("tool_schema_render", ("24",), 0, True, 21, (),
              _probe_tool_schema_render, "tool schema fields in served prompt"),
    ProbeSpec("python_encoder_role_welding", ("56",), 0, True, 21, (),
              _probe_python_encoder_role_welding, "inline system role concatenation"),
    ProbeSpec("reasoning_replay_visibility", ("59",), 0, True, 21, (),
              _probe_reasoning_replay_visibility, "reasoning replay visibility"),
    ProbeSpec("clock_prompt_prefix", ("93",), 0, False, 12, (),
              _probe_clock_prompt_prefix, "structural clock-prefix stability"),
    ProbeSpec("ling_thinking_field_placement", ("126",), 2, False, 18, (),
              _probe_ling_thinking_field_placement, "Ling thinking-off answer routing"),
    ProbeSpec("structured_json_duplication", ("138",), 1, False, 18, (),
              _probe_structured_json_duplication, "structured JSON content parsing"),
    ProbeSpec("unicode_tool_serialization", ("148",), 0, True, 20, (),
              _probe_unicode_tool_serialization, "Unicode tool schema serialization"),
    ProbeSpec("declared_server_token_cap", ("32",), 1, False, 13, (),
              _probe_declared_server_token_cap, "user-declared maximum token cap"),
    ProbeSpec("thinking_budget_marker_ids", ("153",), 0, False, 11, (),
              _probe_thinking_budget_marker_ids, "processor/tokenizer marker IDs"),
    ProbeSpec("prefix_slot_residency", ("155",), 3, False, 10, (),
              _probe_prefix_slot_residency, "bounded prefix slot cache screen"),
    ProbeSpec("ngram_async_scheduling", ("157",), 0, False, 10, (),
              _probe_ngram_async_scheduling, "reported ngram async scheduler state"),
    ProbeSpec("prompt_target_tokens", ("49",), 0, False, 19, (),
              _probe_prompt_target_tokens, "declared target versus served tokenize count"),
    ProbeSpec("cache_hit_answer_consistency", ("60",), 2, False, 18, (),
              _probe_cache_hit_answer_consistency, "cold/warm cache-reported output consistency"),
    ProbeSpec("greedy_repetition_screen", ("91",), 2, False, 17, (),
              _probe_greedy_repetition_screen, "serial greedy repeatability screening"),
    ProbeSpec("device_memory_reporting", ("96",), 0, False, 16, (),
              _probe_device_memory_reporting, "device free-versus-total memory arithmetic"),
    ProbeSpec("kv_cache_pressure", ("106",), 0, False, 15, (),
              _probe_kv_cache_pressure, "KV occupancy and preemption gauge snapshot"),
    ProbeSpec("compilation_flag_resolution", ("117",), 0, False, 14, (),
              _probe_compilation_flag_resolution, "fused GEMM requested/resolved config"),
    ProbeSpec("cudagraph_capture_clamp", ("130",), 0, False, 13, (),
              _probe_cudagraph_capture_clamp, "CUDA graph requested and effective shape"),
    ProbeSpec("execution_concurrency_evidence", ("135",), 0, False, 12, (),
              _probe_execution_concurrency_evidence, "running request admission versus execution"),
    ProbeSpec(
        "minicpm_short_answer_channel", ("162",), 2, False, 24, (),
        _probe_minicpm_short_answer_channel,
        "MiniCPM thinking-on stop-finished answer in reasoning field",
    ),
    ProbeSpec(
        "minicpm_processor_metadata", ("163",), 0, False, 23, ("hf_repo",),
        _probe_minicpm_processor_metadata,
        "pinned MiniCPM processor auto_map module inventory",
    ),
    ProbeSpec(
        "generation_readiness", ("112",), 1, True, 99, (),
        _probe_generation_readiness,
        "authenticated model identity plus bounded real generation",
    ),
    ProbeSpec(
        "model_identity", ("141",), 2, False, 95, (),
        _probe_model_identity,
        "SGLang served-model identity validation",
    ),
    ProbeSpec(
        "reasoning_fields", ("01", "02", "03", "29"), 2, True, 80, (),
        _probe_reasoning_fields,
        "reasoning field / thinking toggle map",
    ),
    ProbeSpec(
        "streaming", ("23", "80"), 1, True, 90, ("streaming",),
        _probe_streaming,
        "streaming content deltas",
    ),
    ProbeSpec(
        "history_assembly", ("04", "20", "25"), 0, True, 70, (),
        _probe_history_assembly,
        "history / empty-think shell render inspection",
    ),
    ProbeSpec(
        "in_text_thinking_toggle", ("66",), 0, True, 64, (),
        _probe_in_text_thinking_toggle,
        "literal thinking-marker substrings in rendered user paths",
    ),
    ProbeSpec(
        "history_object_repr", ("67",), 0, True, 63, (),
        _probe_history_object_repr,
        "Python content-part representations in rendered history",
    ),
    ProbeSpec(
        "inline_system_role", ("113",), 0, False, 20, (),
        _probe_inline_system_role,
        "inline system-role placement or instruction loss",
    ),
    ProbeSpec(
        "default_system_replacement", ("30",), 0, True, 25, (),
        _probe_default_system_replacement,
        "omitted/empty/explicit system role replacement matrix",
    ),
    ProbeSpec(
        "template_owned_think_open", ("38",), 0, True, 24, (),
        _probe_template_owned_think_open,
        "template-owned opening thinking marker in generation prefill",
    ),
    ProbeSpec(
        "tool_argument_dialect", ("43",), 0, True, 23, (),
        _probe_tool_argument_dialect,
        "tool argument object-versus-JSON-string replay render",
    ),
    ProbeSpec(
        "minor_template_boundaries", ("69",), 0, True, 19, (),
        _probe_minor_template_boundaries,
        "unrequested empty system and tool-first role-markup checks",
    ),
    ProbeSpec(
        "thinking_kwarg_type_gate", ("85",), 0, False, 18, (),
        _probe_thinking_kwarg_type_gate,
        "llama.cpp unused thinking kwarg string-type rejection",
    ),
    ProbeSpec(
        "shared_endpoint_contention", ("110",), 0, False, 17, (),
        _probe_shared_endpoint_contention,
        "read-only Prometheus request-contention snapshot",
    ),
    ProbeSpec(
        "thinking_string_false", ("57",), 0, True, 68, (),
        _probe_thinking_string_false,
        'rendered boolean false versus string "false" thinking control',
    ),
    ProbeSpec(
        "system_prompt_relocation", ("82",), 0, True, 67, (),
        _probe_system_prompt_relocation,
        "multi-turn system-marker placement in the rendered prompt",
    ),
    ProbeSpec(
        "baked_default_system", ("83",), 0, True, 22, (),
        _probe_baked_default_system,
        "omitted versus explicit-empty system-role render comparison",
    ),
    ProbeSpec(
        "tool_roundtrip_followup", ("84",), 0, False, 21, (),
        _probe_tool_roundtrip_followup,
        "llama.cpp tool-result then next user /apply-template",
    ),
    ProbeSpec(
        "reasoning_roundtrip_shape", ("63",), 0, True, 69, (),
        _probe_reasoning_roundtrip_shape,
        "reasoning history field x preservation-gate render matrix",
    ),
    ProbeSpec(
        "final_assistant_prefill", ("86",), 0, False, 18, (),
        _probe_final_assistant_prefill,
        "llama.cpp final-assistant prefill delimiter comparison",
    ),
    ProbeSpec(
        "llamacpp_slot_context", ("87",), 0, False, 17, (),
        _probe_llamacpp_slot_context,
        "llama.cpp /props versus /slots context semantics",
    ),
    ProbeSpec(
        "kwarg_deadness", ("03", "29"), 3, False, 40, (),
        _probe_kwarg_deadness,
        "thinking kwarg acceptance vs behavioural effect",
    ),
    ProbeSpec(
        "multimodal", ("68", "72", "73"), 2, False, 20, ("multimodal",),
        _probe_multimodal,
        "multimodal image probe (traps 68, 72, 73)",
    ),
    ProbeSpec(
        "tools", ("19", "26"), 2, True, 50, ("tools",),
        _probe_tools,
        "tool-call surface",
    ),
    ProbeSpec(
        "tool_choice_gate", ("19",), 2, False, 30, ("tools",),
        _probe_tool_choice_gate,
        "tool_choice=none gate",
    ),
    ProbeSpec(
        "reasoning_effort_switch", ("58",), 3, False, 25, (),
        _probe_reasoning_effort_switch,
        "top-level reasoning_effort prompt/reasoning effect",
    ),
    ProbeSpec(
        "cache_prompt_isolation", ("88",), 3, False, 16, (),
        _probe_cache_prompt_isolation,
        "llama.cpp cache_prompt=false isolation",
    ),
    ProbeSpec(
        "ceiling", ("12", "16", "22"), 1, True, 60, (),
        _probe_ceiling,
        "output ceiling / empty content at cap",
    ),
    ProbeSpec(
        "echo_logprobs", ("15",), 1, False, 45, (),
        _probe_echo_logprobs,
        "echo+logprobs completions (lm-eval multiple choice)",
    ),
    ProbeSpec(
        "configs", ("10", "17", "21"), 0, False, 10, ("hf_repo",),
        _probe_configs,
        "checkpoint config checks (requires --hf-repo)",
    ),
)


def iter_probe_specs(only_ids=None):
    """Yield ProbeSpec entries, optionally filtered by id (order preserved)."""
    if only_ids is None:
        for spec in PROBE_SPECS:
            yield spec
        return
    wanted = set(only_ids)
    for spec in PROBE_SPECS:
        if spec.id in wanted:
            yield spec


def run(doc, base, root, args, only_ids=None):
    """Every selected check, in catalog order.

    Split out of main() so the regression suite can drive a full run against a
    fixture server without going through argv. ``only_ids`` selects a subset
    for the reusable library API (None = full Doctor catalogue order).
    """
    # First probe remains request_validation when included: cheapest qualifier
    # for whether parameters are hypotheses vs settings.
    for spec in iter_probe_specs(only_ids):
        spec.invoke(doc, base, root, args)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True,
                    help="OpenAI-compatible base, e.g. http://localhost:8000/v1")
    ap.add_argument("--benchmark-target-tokens", type=int, default=None,
                    help="target number of served tokens for the supplied benchmark prompt")
    ap.add_argument("--benchmark-prompt-text", default=None,
                    help="exact benchmark prompt to check via the local /tokenize route")
    ap.add_argument("--server-max-tokens", type=int, default=None,
                    help="operator-known serve --max-tokens setting; enables Trap 32 check")
    ap.add_argument("--thinking-budget-marker-ids", default=None,
                    help="two processor start/end marker token IDs, e.g. 151667,151668")
    ap.add_argument("--model", default=None)
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--hf-repo", default=None,
                    help="org/name of the checkpoint, enables config checks")
    ap.add_argument("--hf-revision", default="main",
                    help="branch, tag or commit sha of the checkpoint you are "
                         "actually serving. Defaults to main, which is MUTABLE: "
                         "if you serve a pinned revision, pass it here or the "
                         "comparison is against a checkpoint you do not run.")
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--json", default=None)
    args = ap.parse_args()
    base = args.base_url.rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    root = base[:-3].rstrip("/")
    doc = Doc()
    if not detect_stack(doc, base, root, args.api_key):
        print(f"unreachable: {base}/models did not answer", file=sys.stderr)
        sys.exit(1)
    if args.model:
        doc.model = args.model
    run(doc, base, root, args)
    emit(doc, args)
    if args.json:
        cov = coverage(doc)
        with open(args.json, "w") as f:
            json.dump({"stack": doc.stack, "model": doc.model,
                       "requests_made": doc.requests_made,
                       "coverage": cov,
                       "coverage_line": coverage_line(cov),
                       "findings": doc.findings,
                       "problems": [(f["traps"], f["title"], f["detail"])
                                    for f in doc.problems],
                       "clean": [(f["traps"], f["title"]) for f in doc.clean],
                       "inconclusive": [(f["traps"], f["title"], f["detail"])
                                        for f in doc.unsure],
                       "could_not_check": [(f["traps"], f["title"], f["detail"])
                                           for f in doc.blocked],
                       "evidence": doc.evidence}, f, indent=1, default=str)

if __name__ == "__main__":
    main()
