# TabbyAPI and ExLlamaV2 / ExLlamaV3

**Measured here:** yes, ExLlamaV3 only (one first-party ExLlamaV3 evaluation
lane; no first-party TabbyAPI server run)


**Two entries name ExLlamaV3 or TabbyAPI as the stack that was run**, and one
of them was measured here:

| Entry | What it says | Status |
|---|---|---|
| [156](../traps/evaluation/156-exllamav3-requeue-undercounts-output-tokens.md) | Repeated ExLlamaV3 requeues can under-report `completion_tokens`, and TabbyAPI's tok/s inherits it | contributor-measured, conditions as reported |
| [171](../traps/evaluation/171-unpaired-intervals-hide-a-real-sub-percent-delta.md) | On ExLlamaV3 BF16, a derivative's real +0.31% bits-per-byte delta was invisible to unpaired intervals and clear to a paired one | measured here, raw not published |

Trap [137](../traps/evaluation/137-kernel-selector-return-is-not-process-exit-status.md)
is a contributor measurement of one ExLlamaV3 native-extension contract, not a
server run. ExLlamaV2 and EXL2 have no entry anywhere. Absence means nobody
has reported to us, not that the stack is clean.

**One distinction on this page matters more than the counts.** Several
entries name **EXL3** as a **quantization format** in a hybrid build served
from a container, not as ExLlama-the-runtime behind TabbyAPI: traps
[02](../traps/template/02-orphaned-think-close-tag.md),
[03](../traps/reasoning/03-enable-thinking-default-drift.md),
[04](../traps/template/04-history-reasoning-stripping.md),
[10](../traps/quantization/10-quant-label-is-not-the-kernel-path.md),
[30](../traps/template/30-default-system-message-silently-replaced.md) and the
DeepSeek-V4.1-Flash EXL3 lanes under TensorFold in
[169](../traps/evaluation/169-plain-greedy-decode-speedup-does-not-transfer.md),
[170](../traps/evaluation/170-cap-hit-retry-at-a-bigger-budget-is-mostly-a-second-loop.md)
and [172](../traps/evaluation/172-agent-wall-time-per-call-is-not-decode-speed.md).
Reading those as TabbyAPI coverage would be the exact error trap
[10](../traps/quantization/10-quant-label-is-not-the-kernel-path.md) is about:
the format label is not the serving path.

## The three checks to run first

**1. Count output tokens yourself on long replies.** Retokenize the returned
reasoning and content with the served tokenizer and compare with
`usage.completion_tokens`. A `finish_reason=length` with a reported count far
below `max_tokens` is the signature of
[trap 156](../traps/evaluation/156-exllamav3-requeue-undercounts-output-tokens.md),
and every tok/s figure derived from that count is wrong with it.

**2. Compare a derivative with its base paired, not unpaired.** ExLlamaV3's
BF16 path scored the same 315 documents bit-identically on a repeat run, which
makes it a good regression gate: keep per-document results and bootstrap the
per-document difference
([trap 171](../traps/evaluation/171-unpaired-intervals-hide-a-real-sub-percent-delta.md)).
Run the scorer twice before trusting a small delta; if the repeat is not
identical on your build, that noise floor is your minimum detectable effect.

**3. Quote speculative-decoding gains per output class.** ExLlamaV3 and
TabbyAPI can run a draft model (including DFlash-style drafters on recent
builds). Measure prose, JSON, tool calls and reasoning traces separately at
served settings, and read accepted and drafted counts from the engine, not
from client timing
([trap 169](../traps/evaluation/169-plain-greedy-decode-speedup-does-not-transfer.md),
[trap 105](../traps/evaluation/105-acceptance-estimator-unnamed.md)).

## Why the gap

Our early EXL3 work arrived as one arm of a quantization comparison rather
than as a serving stack we operate, and the comparison was run through a
container we already had. The first-party ExLlamaV3 lane since then is an
evaluation lane (bits per byte), not a TabbyAPI server. TabbyAPI itself has
still not been stood up here.

## Which of our mechanism classes most likely apply, and why

Hypotheses, each naming the measured entry the class comes from. Two of these
are sharpened by things the mining round found and this registry did **not**
publish, for want of a source good enough, they are noted as such.

**The quant label is not the kernel path**: trap
[10](../traps/quantization/10-quant-label-is-not-the-kernel-path.md), head of a
four-entry family. EXL2 and EXL3 are the strongest candidates in the registry
for this class because their headline number, **bits per weight, is an
average**. Two checkpoints labelled the same bpw from different publishers can
differ in per-layer allocation and in the calibration set used to choose it.
The label is not even claiming to name a kernel path; it is naming a budget.
Trap 10's fix, find a runtime tell rather than trusting the label, applies
directly.

**Speculative decoding has a sharp peak, and the drafter must match**: traps
[11](../traps/runtime/11-speculative-depth-peak-and-collapse.md) and
[62](../traps/runtime/62-spec-decode-garble-under-wrong-drafter-config.md).
Trap 62 is token garbling from a drafter configuration, measured here on a
different stack. A draft model whose tokenizer or vocabulary does not match the
target is the canonical way into that, and it is a documented requirement on
this stack rather than a subtle one.

**The template you selected is not the model's template**: traps
[19](../traps/tools/19-missing-jinja-breaks-tool-parsing.md),
[24](../traps/template/24-official-template-breaks-cpp-jinja.md) and
[56](../traps/template/56-checkpoint-ships-no-chat-template.md), and
[U03](../upstream/U03-ollama-bundled-template-diverges.md) and
[U09](../upstream/U09-vllm-mistral-chat-template-ignored.md). Where a server
selects a prompt format **by name from a configuration file** rather than
reading the checkpoint's own template, choosing the wrong name is a
configuration typo with a quality-shaped symptom. U09 is the version of this
where the template you supplied was ignored entirely, with a warning nobody
saw.

**Long-uptime state corruption.** This one has **no entry behind it** and is
listed as an open question rather than a hypothesis with support. The mining
round surfaced a community report of a server producing degrading output after
long uptime until restarted; it rests on a single forum comment and was closed
as too weak to publish *(private evidence archived)*.
It is recorded here because a soak is expensive, nobody has run one, and if the
effect is real it is the kind that never gets caught by a short test. Treat it
as unverified folklore until somebody logs it.

## How you would test for these

1. **Run the [doctor](../doctor/) against the endpoint.** One stdlib file,
   any OpenAI-compatible server, and it has never met this one.
2. **For the bpw class**, the decisive comparison is two checkpoints at the
   **same nominal bpw from different publishers**, on one fixed probe set, with
   sampling held identical across both. Report the calibration details if the
   publisher states them. Equalising sampling and template is what makes this a
   measurement rather than trap
   [17](../traps/evaluation/17-per-arm-recommended-sampling-confound.md), which
   is the most common way an A/B result turns out never to have existed.
3. **For the template class**, serve one checkpoint twice under two different
   prompt-format names and compare outputs on identical prompts. The failure is
   quality-shaped, not an error, so read the assembled prompt if the server
   exposes it.
4. **For the drafter class**, pair a target with a draft model from a different
   family and record whether you get a clean refusal, a crash, or **output**.
   Output is the interesting answer; trap 62 is what that looks like.
5. **If you run a long-lived instance**, log a fixed canary prompt at
   temperature 0 hourly and diff the outputs. That is the only way the
   long-uptime question gets settled, and it costs nothing on a server you were
   running anyway.

## How to report a finding

Open an ["I hit a trap" issue](../../issues/new?template=report-a-trap.yml).
Data format guidance is in
[CONTRIBUTING](../CONTRIBUTING.md#sending-measurement-data). Negatives are
welcome and are worth as much as positives on a stack at zero.
