# Playbook: Agentic research integrity

Minefield is about **serving failures and measurement integrity**. This playbook
covers a related class: failures of the **research stack** (agents, harnesses,
scorers, evidence packaging) that investigates those systems.

It is not a generic agent framework, bounty platform, or claim that private
security findings are “validated.” It keeps TARGET BUG and RESEARCH-STACK BUG
distinct.

## Lifecycle

```
DISCOVERY → TRIAGE → REPRODUCTION → EVIDENCE PREFLIGHT
  → FALSIFICATION → ADJUDICATION → PROMOTION
```

| Stage | Must not |
|-------|----------|
| DISCOVERY / TRIAGE | Promote evidence or allocate trap numbers |
| REPRODUCTION | Rely on narrative alone; leave identities unpinned |
| EVIDENCE PREFLIGHT | Treat `UNKNOWN` as `PASS` |
| FALSIFICATION | Be anchored by proposer confidence/verdict |
| ADJUDICATION | Certify without raw evidence |
| PROMOTION | Silently strengthen the claim |

## Roles (conceptual)

| Role | May | Must not |
|------|-----|----------|
| SCOUT | Discover candidates | Promote |
| REPRODUCER | Pin identities; preserve raw artifacts | Skip hashing |
| FALSIFIER | Run controls / alternatives | Need proposer confidence |
| ADJUDICATOR | Set evidence status + claim boundary (Minefield vocabulary) | Use summary only |
| PUBLISHER | Registry / generated surfaces under normal governance | Upgrade claims |

One human may hold multiple roles. Solo contribution remains possible via
explicit waiver or “not required for this disposition.”

## Principle

`NO_MODEL_CERTIFIES_ITS_OWN_WORK` for **agent-driven** high-confidence or
numbered promotion. Record one of:

- `INDEPENDENT_REVIEW_PASS`
- `INDEPENDENT_REVIEW_NOT_AVAILABLE` (blocks agent promotion without waiver)
- `INDEPENDENT_REVIEW_WAIVED_WITH_REASON` (reason required)
- `INDEPENDENT_REVIEW_NOT_REQUIRED_FOR_THIS_DISPOSITION`

## Existing vocabularies (do not replace)

| Concern | Source |
|---------|--------|
| Evidence status | `skills/.../evidence-status.md` |
| Diagnosis levels | `docs/DIAGNOSIS_CONTRACT.md` |
| Failure cause codes | `docs/failure-cause-taxonomy.md` |
| Readiness states | trap 112 + endpoint readiness probe |

Preflight terminal states `PASS`/`HOLD`/`FAIL`/`UNKNOWN` are **packet
validation** outcomes only, not evidence status.

## Prove the implementation path ran

An agent-written `PASS`, a benchmark table, and a clean reference result do not
prove that the proposed implementation was built or called. Before accepting a
claim about a new kernel, backend, transport, or optimization, require all of:

1. **Build proof** - the build graph and resulting artifact name the target.
2. **Import/load proof** - the test loads that artifact and fails closed if it
   is absent; fallback is not a passing outcome.
3. **Call proof** - instrumentation or an equivalent discriminator shows the
   target function ran for the measured cases.
4. **Output proof** - target output is compared with an independent reference
   under a preregistered tolerance.
5. **Negative control** - disabling, renaming, or deliberately breaking the
   target makes the test fail. If the same `PASS` survives, the test did not
   establish target execution.
6. **Timing identity** - the timed region belongs to the target call, not setup,
   reference computation, fallback, or a different function.

Adjudicate from artifacts and executable controls, not the implementer's prose
verdict. A measured reference-only path can validate the oracle, but it cannot
validate or benchmark an implementation it never invoked.

## Commands

```bash
python3 checks/evidence_packet_preflight.py --packet packet.json
python3 -m minefield evidence-preflight --packet packet.json
python3 -m minefield blind-review --packet full.json --out blind.json
python3 -m minefield promotion-receipt --receipt receipt.json
python3 -m minefield upstream-triage --changes changed-paths.txt
```

Schema: `docs/evidence-packet.schema.json`.
No trap number is promised for a contribution; dispositions include
corroboration, extension, check, mining, draft, upstream-tier, reject.


## LLM-judge base rates: a stress test, a classifier and production history are different estimands

A contributor audit in [issue #155](https://github.com/Blackwellboy/model-serving-minefield/issues/155) produced three superficially comparable rates for unrequested agent actions: 71% in an intentionally impossible stress probe, 3.9% from a small-model judge over production history, and 0.08% after every flag was re-read plus an orthogonal operator-objection search.

The gap was not model drift. The three instruments were answering different questions, and the cheap judge also produced structural false positives: empty final replies, interrupted turns, compaction/system notes, scheduled-job sentinels, and batches where it repeated the same rationale without reading the row. It also missed real incidents when the action and the user's objection occurred in different turns.

For agent-history measurement:

- label a stress-test rate as a **stress rate**, never a production base rate;
- hand-review every positive from a cheap judge before publishing a prevalence number;
- explicitly bucket interrupted, empty-final, compaction and sentinel turns rather than forcing them into behavioral labels;
- treat long runs of identical judge rationales as an instrument failure;
- add an orthogonal detector that spans turns, such as operator corrections/objections;
- sample judge-negative rows too, so a clean positive review does not hide false negatives.

An LLM judge is evidence-producing code. Its labels are not ground truth merely because they are structured.
